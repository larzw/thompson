#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <string.h>
#include <time.h>

#include "ctis_config.h"

#define PROGNAME "gen_test_data"

// Bounds (upper and lower) on the random numbers generated for the 
// test data.
#define F_BOUND   256
#define H_BOUND   256

// Starting column to output for the H matrix
#define H_START_COL 0

// The original H matrix is rather holey. This parameter controls
// how densly we populate our test matrix.
#define H_SPARSITY  20

void generate_fvector(CTIS_Config *cfg);
void generate_Hmatrix(CTIS_Config *cfg);

//-----------------------------------------------------------------------------
//
// usage_exit - Splash the help screen then bail
//
void usage_exit()
{
     fprintf(stderr, "usage: %s conf_file\n", PROGNAME);
     fprintf(stderr, " Generate test CTIS data\n");
     fprintf(stderr, " Oputput: H matrix, f vector\n");
     fprintf(stderr, " conf_file = configuration file to use\n");
     exit(EXIT_FAILURE);
}

int main(int argc, const char *argv[])
{
     CTIS_Config cfg;

     if(argc < 2)
          usage_exit();

     parse_config(&cfg, argv[1]);
     //print_config(stdout, &cfg);
     
     srand48(time(NULL));

     generate_fvector(&cfg);
     generate_Hmatrix(&cfg);

     return 0;
}

double get_random(long bound)
{
     //long l = mrand48() % bound;
     //return l * drand48();
     return drand48()*bound;
}

void generate_fvector(CTIS_Config *cfg)
{
     FILE *fout;
     int i;

     if((fout = fopen(cfg->f_fname, "w")) == NULL)
     {
	  fprintf(stderr, "Unable to open \'%s\' for writing: %s\n",
		  cfg->f_fname, strerror(errno));
	  exit(EXIT_FAILURE);
     }

     for(i=0; i < cfg->m; i++)
	  fprintf(fout, "%f\n", get_random(F_BOUND));
     
     fclose(fout);
     fprintf(stdout, "Wrote test vector to %s\n", cfg->f_fname);
}

void generate_Hmatrix(CTIS_Config *cfg)
{
     FILE *fout;
     
     int i, j;
     int col = H_START_COL;
     int col_stride = cfg->a;
     int sparse_switch;

     //H_SPARSITY
     
     if((fout = fopen(cfg->Hmatrix_fname, "w")) == NULL)
     {
          fprintf(stderr, "Unable to open \'%s\' for writing: %s\n",
                  cfg->f_fname, strerror(errno));
          exit(EXIT_FAILURE);
     }
     
     for(i=0; i < cfg->w*cfg->alpha; i++)
     {
	  fprintf(fout, "col %d\n", col);
	  for(j=0; j < cfg->n; j++)
	  {
	       sparse_switch = lrand48();
	       if(sparse_switch%H_SPARSITY == 0)
		    fprintf(fout, "%d %f\n", j, get_random(H_BOUND));
	  }
	  col += col_stride;
     }
     fprintf(stdout, "Wrote test matrix to %s\n", cfg->Hmatrix_fname);
}
