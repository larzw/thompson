#ifndef _FFT_INTERFACE_H
#define _FFT_INTERFACE_H

#include "fftw3.h"
#define FFTW_WISDOM_CACHE "fftw_wisdom.cache"
#define FFTWF_WISDOM_CACHE "fftwf_wisdom.cache"
#define FFTWL_WISDOM_CACHE "fftwl_wisdom.cache"

// Adopt FFTW's name mangling convention for switching
// between double or single precision versions
#define CONCAT(prefix, name) prefix ## name
#define X(foo) CONCAT(fftw_, foo)

// FFT Function Definitions
#define FFTW_EXEC X(execute)
#define FFTW_EXEC_R2C X(execute_dft_r2c)
#define FFTW_EXEC_C2R X(execute_dft_c2r)
#define FFTW_PLAN_R2C X(plan_dft_r2c_1d)
#define FFTW_PLAN_C2R X(plan_dft_c2r_1d)
#define FFTW_PLAN X(plan)
#define FFTW_DESTROY_PLAN X(destroy_plan)

#define FFT_MODE FFTW_MEASURE

#endif //_FFT_INTERFACE_H
