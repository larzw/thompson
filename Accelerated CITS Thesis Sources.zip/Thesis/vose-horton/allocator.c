#include <stdlib.h>
#include "cell_util.h"

#define HUGE_PAGES 8
#define HUGE_PAGE_SIZE (16384*1024)
#define HUGE_BUFFER_SIZE HUGE_PAGES*HUGE_PAGE_SIZE
#define CELL_ALIGNMENT   128

static int   using_huge_pages;
static int   buffer_loc = 0;
static char *mem_buffer = 0;

void alloc_init(int use_huge_pages)
{
     using_huge_pages = use_huge_pages;
     
     if(!using_huge_pages)
	  return;

     mem_buffer = huge_alloc(HUGE_BUFFER_SIZE);

     if(mem_buffer == NULL)
     {
	  fprintf(stderr, "Unable to allocate huge page buffer\n");
	  exit(EXIT_FAILURE);
     }
}

void* alloc_vector(size_t size)
{
     char *b;
     
     if(!using_huge_pages)
	  return cell_malloc(size);
     
     // Pull from our first unused memory block
     b = (mem_buffer+buffer_loc);
     
     // Increment by the amount requested
     buffer_loc += size;

     // Check for overflow
     if(buffer_loc > HUGE_BUFFER_SIZE)
     {
	  fprintf(stderr, "Insufficient space for allocation\n");
	  exit(EXIT_FAILURE);
     }

     // Ensure that the next allocation is optimally aligned
     buffer_loc += CELL_ALIGNMENT-(buffer_loc % CELL_ALIGNMENT);
     
     return b;
}

void free_vector(void *p)
{
     if(!using_huge_pages)
	  cell_free(p);

     // Since we only free memory at program end, we don't need to be
     // too fancy here. Just release the whole huge buffer the first
     // time vector free is called.
     if(mem_buffer != 0)
	  huge_free(mem_buffer);
}

