#include "ctis.h"
#include "ctis_bench.h"

ppu_timer benchmark_timer;
ppu_timer kernel_timer;

void check_ctis_answer(CTIS_Config *cfg, CTIS_Workspace *work)
{
     int i;
     double max, min, sum;
     double diff;

     max = min = sum = 0;

     diff = abs(work->f[0] - work->f_est[0]);
     max = min = sum = diff;

     for(i=1; i < cfg->m; i++)
     {
          diff = abs(work->f[i] - work->f_est[i]);

          if(diff < min)
               min = diff;

          if(diff > max)
               max = diff;

          sum += diff;
     }

     fprintf(stdout, " CTIS solution error (average, min, max): (%f, %f, %f)\n",
             sum/cfg->m, min, max);
}
