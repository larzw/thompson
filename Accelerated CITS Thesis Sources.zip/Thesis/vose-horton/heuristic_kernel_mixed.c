#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <complex.h>

#include "ctis_mixed.h"
#include "ctis_config.h"
#include "fft_interface.h"
#include "blas_interface.h"

#define ZERO_DC(x) (x[0] = 0)

void heuristic_kernel(CTIS_Config *cfg,  CTIS_Workspace *work)
{
     // Config aliases
     int n = cfg->n;
     int w = cfg->w;
     double  mu = cfg->mu;
     double  muInv = cfg->muInv;     
     double complex zmuInv = muInv;
     int zlen = cfg->zlen;

     // Data aliases
     double complex *eta = work->eta;
     double complex *Fck = work->Fck;
     float complex *eta_f = work->eta_f;
     int32_t *ZPattern   = work->ZPattern;
     float *f_est       = work->f_est;

     // Overlays for use with real and complex types
     float complex *cv   = (float complex *) work->v;
     float complex *cv1  = (float complex *) work->v1;
     float complex *cv2  = (float complex *) work->v2;
     float complex *cv3  = (float complex *) work->v3;

     double complex *zv1  = (double complex *) work->v1;
     double complex *zv2  = (double complex *) work->v2;
     double complex *zv3  = (double complex *) work->v3;

     float *rv   = (float *) work->v;
     float *rv1  = (float *) work->v1;
     float *rv2  = (float *) work->v2;
     float *rv3  = (float *) work->v3;

     // Local Variables
     int i;
          
     // cv = fft(v)
     fftwf_execute_dft_r2c(work->fft_ip, rv, cv);
     //ZERO_DC(cv);
     
     // cv3 = 0;
     cell_zero(zlen*sizeof(double complex), zv3);
     
     // v = mult_sHTranspose( Fck, v, w);
     for(i=0; i < w; i++)
     {
	  ///// <DOUBLE_PRECISION> /////
	  // cv2 = cv * conj(Fck)
	  cell_zmultc_mixed(zlen, &Fck[i*zlen], cv, zv2);
	  
	  // cv1 = cv2 * conj(eta)
	  cell_zmultc(zlen, &eta[i*zlen], zv2, &zv1[i*zlen]);
	  
	  // cv3 = cv3 + cv1
	  cell_zaxpy(zlen, 1, &zv1[i*zlen], zv3, zv3);
	  
	  // cv1 = (1/mu)*cv2
	  cell_zscal(zlen, zmuInv, zv2, &zv1[i*zlen]);
     }

     // v1 = mult_PTranspose * mult_P
     for(i=0; i < w; i++)
     {
	  // cv2 = cv3*eta
	  cell_zmult(zlen, &eta[i*zlen], zv3, zv2);

	  // cv2 = cv1-cv2
	  cell_zsxpy_mixed(zlen, 1, &zv1[i*zlen], zv2, &cv[i*zlen]);
	  cell_ccopy(zlen, &cv[i*zlen], cv2);

	  ///// </DOUBLE_PRECISION> /////

	  // rv = ifft(v2)
	  fftwf_execute_dft_c2r(work->ifft_ip, cv2, rv2);
	  
	  cell_sscal(n, (float)1/n, rv2,  &rv[i*n]);
     }

     // cv1 = 0;
     cell_zero(zlen*sizeof(float complex), cv1);
     
     for(i=0; i < w; i++)
     {
	  // rv2 = ZPrimePattern * rv
	  cell_smask(n, 1, &rv[n*i], rv2, 1, ZPattern);
	  
	  // fcv2 = fft(frv2)
	  fftwf_execute_dft_r2c(work->fft_ip, rv2, cv2);

	  // cv2 = cv2 * conj(eta)
	  cell_cmultc(zlen, &eta_f[i*zlen], cv2, cv2);
	  
	  //cv1 = cv3 + cv2
	  cell_caxpy(zlen, 1, cv2, cv1, cv1);
     }
     
     fftwf_execute_dft_c2r(work->ifft_ip, cv1, rv1);

     cell_sscal(n*w, (float)1/n, rv1, rv1);

     /////////////////////// Conjugate Gradient //////////////////////////     
     // In use: x, v, v1

     // v2 = conjugate_gradient()
     conjugate_gradient(cfg, work);
     
     fftwf_execute_dft_r2c(work->fft_ip, rv2, cv2);
     
     for(i=0; i < w; i++)
     {
	  // cv3 = v2 * eta
	  cell_cmult(zlen, &eta_f[i*zlen], cv2, cv3);
	  
	  // v3 = fft(v3)
	  fftwf_execute_dft_c2r(work->ifft_ip, cv3, rv3);
	  
	  //rv1 = (1/n)*rv3 + rv
	  cell_saxpy(n, (float)1/n, rv3, &rv[i*n], &rv1[i*n]);
     }
     
     // v2 = 0
     cell_zero(zlen*sizeof(float complex), cv2);
     
     for(i=0; i < w; i++)
     {
	  cell_smask(n, 1, &rv1[n*i], rv3, 1, ZPattern);
	  
	  // v3 = fft(v3)
	  fftwf_execute_dft_r2c(work->fft_ip, rv3, cv3);

	  // v3 = conj(eta) * v3
	  cell_cmultc(zlen, &eta_f[i*zlen], cv3, cv3);
	  
	  // v2 = v2 + v3
	  cell_caxpy(zlen, 1, cv3, cv2, cv2);
     }
     
     for(i=0; i < w; i++)
     {
	  // v3 = eta * v2
	  cell_cmult(zlen, &eta_f[i*zlen], cv2, cv3);
	  
	  // v3 = ifft(v3)
	  fftwf_execute_dft_c2r(work->ifft_ip, cv3, rv3);
	  
	  // rv[i*n] += rv3*(((double)1/n)*mu)
	  cell_saxpy(n, ((float)1/n)*mu, rv3, &rv[i*n], &rv[i*n]);
     }

     RunZReduce(f_est, rv2, rv, ZPattern, n, w);
}

void conjugate_gradient(CTIS_Config *cfg, CTIS_Workspace *work)
{
     int i;
     int pass;
     float lastE, dotR;
     float ca, e;

     // Namespace aliases
     int n = cfg->n;
     int w = cfg->w;
     float  muInv = cfg->muInv;
     int zlen = cfg->zlen;

     float complex *eta_f = work->eta_f;
     int32_t *ZPattern   = work->ZPattern;

     float complex *cv2  = (float complex *) work->v2;
     float complex *cv3  = (float complex *) work->v3;

     float *rv1  = (float *) work->v1;
     float *rv2  = (float *) work->v2;
     float *rv3  = (float *) work->v3;
     
     float *cg_x        = work->cg_x;
     float *cg_r        = work->cg_r;
     float *cg_p        = work->cg_p;
     float *cg_v        = work->cg_v;

     /////////////////////// Conjugate Gradient //////////////////////////
     
     // cg_x = 0;
     cell_zero(sizeof(float)*n, cg_x);

     // cg_r = rv1
     cell_scopy(n, rv1, cg_r);
	  
     //cg_p = cg_r
     cell_scopy(n, cg_r, cg_p);
     
     // e = dot(cg_r, cg_r)
     e = cell_sdot(n, cg_r, cg_r);

     pass = 0;	  
     while(e > cfg->CG_EPSILON && pass < cfg->CG_ITERS)
     {
	  pass++;

	  lastE = e;
	  
	  //cg_v = 0
	  cell_zero(zlen*sizeof(float complex), cg_v);
	  
	  // cfv2 = fft(cg_p)
	  fftwf_execute_dft_r2c(work->fft_oop, cg_p, cv2);

	  for(i=0; i < w; i++)
	  {
	       // v3 = v2 * eta
	       cell_cmult(zlen, &eta_f[i*zlen], cv2, cv3);
	       
	       // v3 = ifft(v3)
	       fftwf_execute_dft_c2r(work->ifft_ip, cv3, rv3);

	       // v3 = ZPrimePattern * v3
	       cell_smask(n, (float)1/n, rv3, rv3, 1, ZPattern);
	       
	       // v3 = fft(v3)
	       fftwf_execute_dft_r2c(work->fft_ip, rv3, cv3);

	       // v3 = conj(eta) * v3
	       cell_cmultc(zlen, &eta_f[i*zlen], cv3, cv3);
	       
	       // cg_v = cg_v + v3
	       cell_caxpy(zlen, 1, cv3, (float complex*)cg_v, 
			  (float complex*)cg_v);
	  }
	  
	  fftwf_execute_dft_c2r(work->ifft_ip, 
				(float complex*)cg_v, cg_v);
	  
	  cell_sscal(n, (float)1/n, cg_v, cg_v);
	  
	  // cg_v = (cg_p*muInv) - cg_v
	  cell_ssxpy(n, muInv, cg_p, cg_v, cg_v);

	  ca = e/cell_sdot(n, cg_p, cg_v);

	  //cg_r = -ca*cg_v + cg_r
	  cell_saxpy(n, -ca, cg_v, cg_r, cg_r);

	  dotR = cell_sdot(n, cg_r, cg_r);
	  
	  if(lastE < dotR)
	       break;
	  
	  cell_saxpy(n, ca, cg_p, cg_x, cg_x);
	  ca = dotR;
	  
	  // cg_p = cg_r + (a/e)*cg_p
	  cell_saxpy(n, (ca/e), cg_p, cg_r, cg_p);

	  e = ca;	 
     }
     
     // v2 = cg_x
     cell_scopy(n, cg_x, rv2);

     fprintf(stdout, "CG Passes: %d, e: %f\n", pass, e);
}

void calculate_residual(CTIS_Config *cfg, CTIS_Workspace *work)
{
     int n = cfg->n;
     int w = cfg->w;
     int zlen = cfg->zlen;
     
     float *f_est = work->f_est;
     float *x     = work->x;
     float complex *Fck_f = work->Fck_f;
     int32_t *ZPattern   = work->ZPattern;
     
     float *rv   = (float *) work->v;
     float *rv1  = (float *) work->v1;
     float *rv2  = (float *) work->v2;
     float *rv3  = (float *) work->v3;

     float complex *cv3  = (float complex *) work->v3;

     // Local Variables
     int i;
     float ls;
          
     // rv1 = 0;
     cell_zero(n*sizeof(float), rv1);
     
     for(i=0; i < w; i++)
     {
	  // rv3 = fft(rv2)
	  fftwf_execute_dft_r2c(work->fft_oop, &rv2[i*n], cv3);

	  // cv3 = cv3*Fck
	  cell_cmult(zlen, &Fck_f[i*zlen], cv3, cv3);
	  
	  // rv3 = ifft(cv3)
	  fftwf_execute_dft_c2r(work->ifft_ip, cv3, rv3);
	  
	  // rv1 = rv1 + rv3
	  cell_saxpy(n, (float)1/n, rv3, rv1, rv1);
     }
     
     ls = cell_sdot(n, rv1, x)/cell_sdot(n, rv1, rv1);
     
     /////// Recalculate v ////////////
     RunLSAdjust(rv1, f_est, ls, ZPattern, n, w);

     // frv = 0
     cell_zero(n*sizeof(float), rv);

     for(i=0; i < w; i++)
     {
	  // rv3 = fft(rv3)
	  fftwf_execute_dft_r2c(work->fft_oop, &rv1[i*n], cv3);
	  
	  // cv3 = cv3*Fck
	  cell_cmult(zlen, &Fck_f[i*zlen], cv3, cv3);

	  // rv3 = ifft(cv3)
	  fftwf_execute_dft_c2r(work->ifft_ip, cv3, rv3);
	  
	  // rv = rv + rv3
	  cell_saxpy(n, (float)1/n, rv3, rv, rv);
     }

     // v = x-v
     cell_ssxpy(n, 1, x, rv, rv);
}


void RunZReduce(float *f, float *v2, float *v, int32_t *mask, int n, int w)
{
     int i, j, wPos, bPos, z;
     int k;

     k = 0;
     for(i=0; i < w; i++)
     {
          wPos = bPos = 0 ;
          for(j=0; j < n; j++)
          {
               z = mask[wPos] & 1 << (31-bPos);
               if(z)
               {
                    f[k] = v[(i*n)+j]+f[k];
                    v2[(i*n)+j] = f[k];
                    k++;
               }
               else
                    v2[(i*n)+j] = 0.0;

               bPos++;
               if(bPos == 32)
               {
                    bPos = 0;
                    wPos++;
               }
          }
     }
}


void RunLSAdjust(float *v1, float *f, float lse, int32_t *mask, int n, int w)
{
     int i, j, wPos, bPos, z;
     int k;

     k = 0;
     for(i=0; i < w; i++)
     {
          wPos = bPos = 0 ;
          for(j=0; j < n; j++)
          {
               z = mask[wPos] & 1 << (31-bPos);
               if(z)
               {
                    v1[(i*n)+j] = f[k]*lse;
                    k++;
               }
               else
                    v1[(i*n)+j] = 0.0;

               bPos++;
               if(bPos == 32)
               {
                    bPos = 0;
                    wPos++;
               }
          }
     }
}


