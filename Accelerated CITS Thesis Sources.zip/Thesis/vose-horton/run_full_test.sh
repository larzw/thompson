#!/bin/sh

if [ $# -lt 1 ]; then
    echo "usage: run_test config_file"
    exit 1
fi

config=$1

echo "Creating test data"
./gen_test_data $config

echo "Pre-processing matrix"
./pre_matrix $config

echo "Multiplying matrix with test vector"
./multHf $config

echo "Solving for test vector with double precision"
./ctis_double $config

echo "Solving for test vector with mixed precision"
./ctis_mixed $config
