#include <stdlib.h>
#include <stdio.h>
#include <errno.h>
#include <string.h>
#include <math.h>
#include <complex.h>

#include "cell_util.h"
#include "blas_interface.h"
#include "fft_interface.h"
#include "ctis_config.h"

#define PROGNAME "pre_matrix"

static void* (*vector_alloc)(size_t size) = NULL;
static void (*vector_free)(void *p) = NULL;

long double* read_H_columns(CTIS_Config *cfg);
long double complex* compute_Fck(CTIS_Config *cfg, long double *CkV);
long double complex* compute_eta(CTIS_Config *cfg, long double complex *Fck);
void write_ZPattern(CTIS_Config *cfg);

//-----------------------------------------------------------------------------
//
// usage_exit - Splash the help screen then bail
//
void usage_exit()
{
     fprintf(stderr, "usage: %s conf_file\n", PROGNAME);
     fprintf(stderr, " CTIS Matrix pre-processor\n");
     fprintf(stderr, " Output: eta & Fck vectors, ZPattern\n");
     fprintf(stderr, " conf_file =  configuration file to use\n");
     exit(EXIT_FAILURE);
}

int main(int argc, const char *argv[])
{
     FILE *wiz_file;
     CTIS_Config cfg;
     long double *CkV;
     long double complex *Fck;
     long double complex *eta;
     int zlen;

     if(argc < 2)
	  usage_exit();

     // If we want to tune this, we could
     // put in the option for huge pages...
     vector_alloc = cell_malloc;
     vector_free  = cell_free;

     parse_config(&cfg, argv[1]);
     //print_config(stdout, &cfg);
     
     //init_fft_library();
     if((wiz_file = fopen(FFTWL_WISDOM_CACHE, "r")) != NULL)
     {
          printf("Importing FFT wisdom from %s\n", FFTWL_WISDOM_CACHE);
          fftwl_import_wisdom_from_file(wiz_file);
          fclose(wiz_file);
     }
     
     init_blas_library();
     
     CkV = read_H_columns(&cfg);
     
     // Precompute Fck and eta
     zlen = (cfg.n/2+1)*cfg.w;
     Fck = compute_Fck(&cfg, CkV);
     eta = compute_eta(&cfg, Fck);

     zl_write(cfg.Fck_fname, Fck, zlen);
     printf("Wrote %s\n", cfg.Fck_fname);
     zl_write(cfg.eta_fname, eta, zlen);
     printf("Wrote %s\n", cfg.eta_fname);

     vector_free(eta);
     vector_free(Fck);
     vector_free(CkV);

     write_ZPattern(&cfg);
     printf("Wrote %s\n", cfg.ZPattern_fname);
     
     close_blas_library();

     //close_fft_library();
     if((wiz_file = fopen(FFTWL_WISDOM_CACHE, "w")) != NULL)
     {
          printf("Saving fft wisdom to %s...\n", FFTWL_WISDOM_CACHE);
          fftwl_export_wisdom_to_file(wiz_file);
     }

     fftwl_forget_wisdom();
     
     return 0;
}

//-----------------------------------------------------------------------------
// 
// Read the principal columns of the H matrix from file.
//
// Due to assumption 2 in the Vose-Horton CTIS paper, we get away with
// only reading in the primary partition columns.
//
long double* read_H_columns(CTIS_Config *cfg)
{
     FILE *fin;
     long double *CkV;
     char buf[1024], *cptr;
     int Hlen = cfg->w*cfg->n;
     int row, col, idx;
     int col_selector = cfg->a*cfg->alpha;

     if((fin = fopen(cfg->Hmatrix_fname, "r")) == NULL)
     {
          fprintf(stderr, "Unable to open \'%s\' for reading: %s\n",
                  cfg->Hmatrix_fname, strerror(errno));
          exit(EXIT_FAILURE);
     }
     
     // Allocate a zero initialized vector to hold our matrix
     CkV = vector_alloc(Hlen*sizeof(long double));
     
     row = col = idx = -1;
     while(fgets(buf, 1024, fin) != NULL)
     {
	  buf[1023] = 0;
	  	  
	  if(isString(buf, "\n"))
	       continue;
	  
	  cptr = strtok(buf, " ");
	  if(isString(cptr, "col"))
	  {
	       cptr = strtok(NULL, " ");
	       col = atoi(cptr);
	  }
	  else
	  {
	       if(col % col_selector == 0 && col > 0) 
	       {
		    row = atoi(cptr);
		    
		    // Okay, confession time: this is cheating.
		    // Folding the rest of the matrix data in this column
		    // back into itself is certainly NOT the right thing.
		    // However, due to the sparcity of the H matrix, this
		    // folds some numbers into the column for us to work 
		    // with. Without them, parts of the data vector are
		    // irrevocably zeroed. 
		    //
		    // If you remove this and run against the real matrix,
		    // you'll be hard pressed to get your data back.
		    row = row%cfg->n;

		    if(row < cfg->n)
		    {
			 cptr = strtok(NULL, " ");
			 idx = (((col/(cfg->a*cfg->alpha))-1)*cfg->n) + row;
			 CkV[idx] = strtold(cptr, NULL);
		    }
	       }
	  }
     }
     fclose(fin);
     return CkV;
}

long double complex* compute_Fck(CTIS_Config *cfg, long double *CkV)
{
     long double complex *Fck;
     int i;
     fftwl_plan fft_plan;
     
     int n = cfg->n;
     int w = cfg->w;
     int clen = (n/2+1);
     int zlen = clen*w;
     
     Fck = vector_alloc(sizeof(long double complex) * zlen);

     // Let the FFT planner have it's way with our new storage
     fft_plan = fftwl_plan_dft_r2c_1d(n, (long double*) CkV, (long double complex*) Fck,  FFT_MODE);

     cell_zero(sizeof(long double complex)*zlen, Fck);
     
     for(i=0; i < w; i++)
	  fftwl_execute_dft_r2c(fft_plan, &CkV[i*n], &Fck[i*clen]);
     
     return Fck;
}

long double complex* compute_eta(CTIS_Config *cfg, long double complex *Fck)
{
     long double complex *sumK, *fck, *eta;
     long double complex scalar;
     int i;
     
     int n = cfg->n;
     int w = cfg->w;
     int clen = (n/2+1);
     int zlen = (n/2+1)*w;
     
     sumK = vector_alloc(sizeof(long double complex)*clen);
     fck = vector_alloc(sizeof(long double complex)*clen);
     eta = vector_alloc(sizeof(long double complex)*zlen);

     for(i=0; i < w; i++)
     {
	  //sumK = sumK + (fck.*conj(fck))
	  cell_jcopy(clen, &Fck[i*clen], 1, fck, 1);
	  cell_jmultc(clen, fck, 1, fck, 1);
	  cell_jaxpy(clen, 1, fck, 1, sumK, 1);
     }

     //sumK = n+(n/mu)*sumK;
     scalar = (n/cfg->mu);     
     cell_jscale(clen, scalar, sumK, 1);
     
     for(i=0; i<clen; i++)
     {
	  sumK[i] = sumK[i] + n; 
     }
     
     // sumK = sumK^-1/2
     cell_jpow(clen, (-0.5), sumK, 1);
     
     for(i=0; i < w; i++)
     {
	  cell_jcopy(clen, sumK, 1, &eta[i*clen], 1);
	  cell_jmultc(clen, &Fck[i*clen], 1, &eta[i*clen], 1);
     }
     scalar = sqrt(n)/cfg->mu;
     cell_jscale(zlen, scalar, eta, 1);

     // Cleanup
     vector_free(fck);
     vector_free(sumK);
     
     return eta;
}

void write_ZPattern(CTIS_Config *cfg)
{
     FILE *fout;
     int i, j;

     if((fout = fopen(cfg->ZPattern_fname, "w")) == NULL)
     {
          fprintf(stderr, "Unable to open file for writing \'%s\' : %s\n",
                  cfg->ZPattern_fname, strerror(errno));
          exit(EXIT_FAILURE);
     }

     for(i=0; i < cfg->alpha; i++)
     {
	  for(j=0; j < cfg->a; j++)
	       fprintf(fout, "1\n");
	  
	  for(j=0; j < (cfg->g - cfg->a); j++)
	       fprintf(fout, "0\n");
     }
     
     for(i=0; i < (cfg->n - (cfg->alpha * cfg->g)); i++)
	  fprintf(fout, "0\n");
     
     fclose(fout);
}
