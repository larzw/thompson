#ifndef _CTIS_H
#define _CTIS_H

#include <stdio.h>    //: FILE
#include <inttypes.h>
#include <complex.h>  //: complex float
#include "fft_interface.h"
#include "ctis_config.h"

#define PROGNAME            "ctis"

typedef struct {

     // Problem Data
     double *f;
     double *x;
     double complex *eta;
     double complex *Fck;
     int32_t *ZPattern;

     // Scratch space
     double complex *v;
     double complex *v1;
     double complex *v2;
     double complex *v3;
     double *cg_x;
     double *cg_r;
     double *cg_p;
     double *cg_v;

     // FFTW Plans
     fftw_plan fft_ip_double;
     fftw_plan ifft_ip_double;
     fftw_plan fft_oop_double;
     fftw_plan ifft_oop_double;

     // The answer
     double *f_est;

} CTIS_Workspace;


void load_CTIS_Workspace(CTIS_Config *cfg, CTIS_Workspace *work);
void release_CTIS_Workspace(CTIS_Workspace *work);

void setup_fft_plans(CTIS_Config *cfg, CTIS_Workspace *work);

// Solve f = H\x
void solve_f_heuristic(CTIS_Config *cfg,  CTIS_Workspace *work);
void heuristic_kernel(CTIS_Config *cfg,   CTIS_Workspace *work);
void calculate_residual(CTIS_Config *cfg, CTIS_Workspace *work);
void conjugate_gradient(CTIS_Config *cfg, CTIS_Workspace *work);

void RunLSAdjust(double *v1, double *f, double lse, int32_t *mask, int n, int w);
void RunZReduce(double *f, double *v2, double *v, int32_t *mask, int n, int w);

#endif // _CTIS_H
