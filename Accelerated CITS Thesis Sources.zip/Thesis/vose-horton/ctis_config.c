#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <errno.h>
#include "ctis_config.h"

#define CONF_VALUE_LEN 128
#define CONF_LINE_LEN  1024

typedef struct{
     char name[CONF_VALUE_LEN];
     char value[CONF_VALUE_LEN];
}ConfigParam;

int isString(const char *s1, const char *s2)
{
     return(strcmp(s1, s2) == 0);
}

// Rather brute, but it works...
static void split_config_line(ConfigParam *p, const char *conf_line, int n)
{
     int i;
     int valueFlag = 0;
     int x;
     
     x = 0;
     memset(p->name, 0, CONF_VALUE_LEN);
     memset(p->value, 0, CONF_VALUE_LEN);

     for(i=0; i < n; i++)
     {
	  // Trim whitespace
	  if(!isspace(conf_line[i]))
	  {
	       if(conf_line[i] == '=')
	       {
		    valueFlag = 1;
                    x = 0;
	       }
	       else if(conf_line[i] == '#')
	       {
		    // Ignore comments
		    return;
	       }
	       else if(valueFlag == 0)
	       {
		    p->name[x] = conf_line[i];
		    x++;
	       }
	       else
	       {
		    p->value[x] = conf_line[i];
                    x++;
	       }
	       
	       if(x >= CONF_VALUE_LEN-1)
	       {
		    fprintf(stderr, "Configuration value too long: '%s'\n", conf_line);
		    exit(EXIT_FAILURE);
	       }
	  }
     }
}

void parse_config(CTIS_Config *cfg, const char *conf_file)
{
     FILE *fin;
     ConfigParam p;
     char line[CONF_LINE_LEN];
     
     if((fin = fopen(conf_file, "r")) == NULL)
     {
	  fprintf(stderr, "Unable to open configuration file \'%s\' : %s\n",
		  conf_file, strerror(errno));
	  exit(EXIT_FAILURE);
     }
     
     while(fgets(line, CONF_LINE_LEN, fin) != NULL)
     {
	  line[CONF_LINE_LEN-1] = 0;
	  split_config_line(&p, line, strlen(line));
	  
	  //DPRINT(("Config name[%s] value[%s]\n", p.name, p.value));

          if(isString(p.name, "n"))
               cfg->n = atol(p.value);
          else if(isString(p.name, "m"))
               cfg->m = atol(p.value);
          else if(isString(p.name, "w"))
               cfg->w = atol(p.value);
          else if(isString(p.name, "alpha"))
               cfg->alpha = atol(p.value);
          else if(isString(p.name, "a"))
               cfg->a = atol(p.value);
          else if(isString(p.name, "g"))
               cfg->g = atol(p.value);
          else if(isString(p.name, "mu"))
          {
               cfg->mu = (double)strtod(p.value, NULL);
               cfg->muInv = 1/cfg->mu;
          }
	  else if(isString(p.name, "MAX_CTIS_ITERS"))
               cfg->MAX_CTIS_ITERS = atoi(p.value);
          else if(isString(p.name, "CG_EPSILON"))
               cfg->CG_EPSILON = (double) strtod(p.value, NULL);
          else if(isString(p.name, "CG_ITERS"))
               cfg->CG_ITERS = atoi(p.value);
	  else if(isString(p.name, "Hmatrix"))
	       cfg->Hmatrix_fname = strdup(p.value);
	  else if(isString(p.name, "x"))
	       cfg->x_fname = strdup(p.value);
	  else if(isString(p.name, "f"))
	       cfg->f_fname = strdup(p.value);
	  else if(isString(p.name, "f_out"))
	       cfg->f_out = strdup(p.value);
	  else if(isString(p.name, "eta"))
	       cfg->eta_fname = strdup(p.value);
	  else if(isString(p.name, "Fck"))
	       cfg->Fck_fname = strdup(p.value);
	  else if(isString(p.name, "ZPattern"))
	       cfg->ZPattern_fname = strdup(p.value);
     }
     
     // Derived constants
     cfg->muInv = 1/cfg->mu;
     cfg->zlen  = (cfg->n/2)+1;
}

void print_config(FILE *out, const CTIS_Config *cfg)
{
     fprintf(out, "# CTIS Configuration:\n");
     fprintf(out, "n              = %ld\n", cfg->n);
     fprintf(out, "m              = %ld\n", cfg->m);
     fprintf(out, "w              = %ld\n", cfg->w);
     fprintf(out, "alpha          = %ld\n", cfg->alpha);
     fprintf(out, "a              = %ld\n", cfg->a);
     fprintf(out, "g              = %ld\n", cfg->g);
     fprintf(out, "mu             = %lf\n", cfg->mu);
     fprintf(out, "muInv          = %lf\n", cfg->muInv);
     fprintf(out, "MAX_CTIS_ITERS = %d\n",  cfg->MAX_CTIS_ITERS);
     fprintf(out, "CG_EPSILON     = %lf\n", cfg->CG_EPSILON);
     fprintf(out, "CG_ITERS       = %d\n",  cfg->CG_ITERS);
     fprintf(out, "Hmatrix        = %s\n",  cfg->Hmatrix_fname);
     fprintf(out, "x              = %s\n",  cfg->x_fname);
     fprintf(out, "f              = %s\n",  cfg->f_fname);
     fprintf(out, "f_out          = %s\n",  cfg->f_out);
     fprintf(out, "eta            = %s\n",  cfg->eta_fname);
     fprintf(out, "Fck            = %s\n",  cfg->Fck_fname);
     fprintf(out, "ZPattern       = %s\n",  cfg->ZPattern_fname);
}
