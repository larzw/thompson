#ifndef _BLAS_INTERFACE_H
#define _BLAS_INTERFACE_H

#include "blasx.h"

void init_blas_library();
void close_blas_library();

// Misc
#define cell_zero   blasx_zero
#define cell_s2d    blasx_s2d
#define cell_d2s    blasx_d2s
#define cell_c2z    blasx_c2z
#define cell_z2c    blasx_z2c

#ifndef WITH_SPES

// mixed
#define cell_zmultc_mixed blasx_zmultc_mixed
#define cell_zsxpy_mixed blasx_zsxpy_mixed

// single 
#define cell_scopy  blasx_scopy
#define cell_sscal  blasx_sscale
#define cell_saxpy  blasx_saxpy
#define cell_ssxpy  blasx_ssxpy
#define cell_sdot   blasx_sdot
#define cell_smask  blasx_smask

// single complex
#define cell_ccopy  blasx_ccopy
#define cell_caxpy  blasx_caxpy
#define cell_csxpy  blasx_csxpy
#define cell_cscal  blasx_cscale
#define cell_cmult  blasx_cmult
#define cell_cmultc blasx_cmultc

// double 
#define cell_dcopy  blasx_dcopy
#define cell_dscal  blasx_dscale
#define cell_daxpy  blasx_daxpy
#define cell_dsxpy  blasx_dsxpy
#define cell_ddot   blasx_ddot
#define cell_dmask  blasx_dmask

// double complex 
#define cell_zcopy  blasx_zcopy
#define cell_zaxpy  blasx_zaxpy
#define cell_zsxpy  blasx_zsxpy
#define cell_zscal  blasx_zscale
#define cell_zmult  blasx_zmult
#define cell_zmultc blasx_zmultc

#else // WITH_SPES

#define cell_zmultc_mixed blasx_cell_zmultc_mixed
#define cell_zsxpy_mixed blasx_cell_zsxpy_mixed
//#define cell_zsxpy_mixed blasx_zsxpy_mixed

// single
#define cell_scopy  blasx_cell_scopy
#define cell_sscal  blasx_cell_sscale
#define cell_saxpy  blasx_cell_saxpy
#define cell_ssxpy  blasx_cell_ssxpy
#define cell_sdot   blasx_cell_sdot
#define cell_smask  blasx_smask

// single complex
#define cell_ccopy  blasx_cell_ccopy
#define cell_caxpy  blasx_cell_caxpy
#define cell_csxpy  blasx_cell_csxpy
#define cell_cscal  blasx_cell_cscale
#define cell_cmult  blasx_cell_cmult
#define cell_cmultc blasx_cell_cmultc

// double
#define cell_dcopy  blasx_cell_dcopy
#define cell_dscal  blasx_cell_dscale
#define cell_daxpy  blasx_cell_daxpy
#define cell_dsxpy  blasx_cell_dsxpy
#define cell_ddot   blasx_cell_ddot
#define cell_dmask  blasx_dmask

// double complex
#define cell_zcopy  blasx_cell_zcopy
#define cell_zaxpy  blasx_cell_zaxpy
#define cell_zsxpy  blasx_cell_zsxpy
#define cell_zscal  blasx_cell_zscale
#define cell_zmult  blasx_cell_zmult
#define cell_zmultc blasx_cell_zmultc

#endif // WITH_SPES

//-----------------------------------------------------------------------------
// The extended precision functions are only used in the pre-computation 
// programs and have not been optimized.
//-----------------------------------------------------------------------------

// long double
#define cell_laxpy  blasx_laxpy
#define cell_lscale blasx_lscale

// long double complex 
#define cell_jmult  blasx_jmult
#define cell_jmultc blasx_jmultc
#define cell_jscale blasx_jscale
#define cell_jaxpy  blasx_jaxpy
#define cell_jpow   blasx_jpow
#define cell_jcopy  blasx_jcopy

#endif /* _BLAS_INTERFACE_H */
