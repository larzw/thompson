#ifndef _ALLOCATOR_H_
#define _ALLOCATOR_H_

#include <stdlib.h>

void  alloc_init(int use_huge_pages);
void* alloc_vector(size_t size);
void  free_vector(void *p);

#endif //_CTIS_ALLOCATOR_H_
