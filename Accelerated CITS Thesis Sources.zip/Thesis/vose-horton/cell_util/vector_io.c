#define _ISOC99_SOURCE  //: vfscanf
#include <stdlib.h>     //: exit
#include <stdio.h>      //: fprintf
#include <complex.h>    //: complex
#include <errno.h>      //: perror
#include <string.h>     //: strerror
#include <stdarg.h>     //: va_list, va_start, va_end

#include "cell_util.h"

//--------------------------------------------------------------------------------
//
// Print Functions 
//
// [in] fout - an open file ready to write
// [in] name - a string to prefix to the output
// [in] v    - vector to write
// [in] N    - length of the vector
//
// Returns: None
//

void s_print(FILE *fout, const char *name, const float *v, const size_t N)
{
     size_t i;
     if(name)
	  fprintf(fout, "%s:\n", name);
     for(i=0; i < N; i++)
          fprintf(fout, "%+.7e\n", v[i]);
}

void d_print(FILE *fout, const char *name, const double *v, const size_t N)
{
     size_t i;
     if(name)
	  fprintf(fout, "%s:\n", name);
     for(i=0; i < N; i++)
          fprintf(fout, "%+.16e\n", v[i]);
}

void dl_print(FILE *fout, const char *name, const long double *v, const size_t N)
{
     size_t i;
     if(name)
	  fprintf(fout, "%s:\n", name);
     for(i=0; i < N; i++)
          fprintf(fout, "%+.16Le\n", v[i]);
}

void c_print(FILE *fout, const char *name, const float complex *v, const size_t N)
{
     size_t i;
     if(name)
	  fprintf(fout, "%s:\n", name);
     for(i=0; i < N; i++)
          fprintf(fout, "%+.7e %+.7e\n", crealf(v[i]), cimagf(v[i]) );
}


void z_print(FILE *fout, const char *name, const double complex *v, const size_t N)
{
     size_t i;
     if(name)
	  fprintf(fout, "%s:\n", name);
     for(i=0; i < N; i++)
	  fprintf(fout, "%+.16e %+.16e\n", creal(v[i]), cimag(v[i]) );
}

void zl_print(FILE *fout, const char *name, const long double complex *v, const size_t N)
{
     size_t i;
     if(name)
	  fprintf(fout, "%s:\n", name);
     for(i=0; i < N; i++)
	  fprintf(fout, "%+.16Le  %+.16Le\n", creall(v[i]), cimagl(v[i]) );
}

//--------------------------------------------------------------------------------
//
// Read Functions 
//
// [in] file_name - fully qualified filename to read
// [in] N  - length of the vector to read from the file
//
// Returns: A pointer to the new vector (allocated on the heap)
//

static FILE* check_read_open(const char *file_name)
{
     FILE *fin;
     if((fin = fopen(file_name, "r")) == NULL)
     {
          fprintf(stderr, "Unable to open data file \'%s\' : %s\n",
                  file_name, strerror(errno));
          exit(EXIT_FAILURE);
     }

     return fin;
}

static void checked_scanf(FILE *fin, const char* s, ...)
{
     va_list ap;
     va_start(ap, s);
     
     if(vfscanf(fin, s, ap) == EOF)
     {
	  perror("unable to read vector from file: %s");
	  exit(EXIT_FAILURE);
     }
     va_end(ap);
}

float* s_read(const char *file_name, size_t N, vector_allocator alloc)
{
     float *v; 
     size_t i;
     FILE *fin;

     fin = check_read_open(file_name);
     
     if(alloc == NULL)
	  alloc = cell_malloc;

     v = (float *) alloc(N*sizeof(float));
     
     for(i=0; i < N; i++)
	  checked_scanf(fin, "%f", &v[i]);
     
     fclose(fin);

     return v;
}

double* d_read(const char *file_name, size_t N, vector_allocator alloc)
{
     double *v; 
     size_t i;
     FILE *fin;

     fin = check_read_open(file_name);

     if(alloc == NULL)
	  alloc = cell_malloc;

     v = (double *) alloc(N*sizeof(double));
     
     for(i=0; i < N; i++)
	  checked_scanf(fin, "%lf", &v[i]);
     
     fclose(fin);

     return v;
}

long double* dl_read(const char *file_name, size_t N, vector_allocator alloc)
{
     long double *v;
     size_t i;
     FILE *fin;

     fin = check_read_open(file_name);

     if(alloc == NULL)
	  alloc = cell_malloc;

     v = (long double *) alloc(N*sizeof(long double));

     for(i=0; i < N; i++)
          checked_scanf(fin, "%Lf", &v[i]);

     fclose(fin);

     return v;
}

float complex* c_read(const char *file_name, size_t N, vector_allocator alloc)
{
     float complex *v; 
     float r;
     size_t i, flip_flop;
     FILE *fin;
     float *tmask;

     fin = check_read_open(file_name);

     if(alloc == NULL)
	  alloc = cell_malloc;

     v = (float complex *) alloc(N*sizeof(float complex));
     
     flip_flop = 0;
     for(i=0; i < N*2; i++)
     {
	  checked_scanf(fin, "%f", &r);
	  tmask = (float *) &v[i/2];
	  tmask[flip_flop] = r;
	  flip_flop = (flip_flop+1)%2;
     }

     fclose(fin);

     return v;
}

double complex* z_read(const char *file_name, size_t N, vector_allocator alloc)
{
     double complex *v; 
     double r;
     size_t i, flip_flop;
     FILE *fin;
     double *tmask;

     fin = check_read_open(file_name);

     if(alloc == NULL)
	  alloc = cell_malloc;

     v = (double complex *) alloc(N*sizeof(double complex));
     
     flip_flop = 0;
     for(i=0; i < N*2; i++)
     {
	  checked_scanf(fin, "%lf", &r);
	  tmask = (double *) &v[i/2];
	  tmask[flip_flop] = r;
	  flip_flop = (flip_flop+1)%2;
     }

     fclose(fin);

     return v;
}

long double complex* zl_read(const char *file_name, size_t N, vector_allocator alloc)
{
     long double complex *v;
     double r;
     size_t i, flip_flop;
     FILE *fin;
     long double *tmask;

     fin = check_read_open(file_name);

     if(alloc == NULL)
	  alloc = cell_malloc;

     v = (long double complex *) alloc(N*sizeof(long double complex));

     flip_flop = 0;
     for(i=0; i < N*2; i++)
     {
          checked_scanf(fin, "%Lf", &r);
          tmask = (long double *) &v[i/2];
          tmask[flip_flop] = r;
          flip_flop = (flip_flop+1)%2;
     }

     fclose(fin);

     return v;
}

int32_t* bitvector_read(const char *file_name, size_t N, vector_allocator alloc)
{
     FILE *fin;
     int32_t *vec;
     int nWords, tmp;
     size_t i;
     int wPos, bPos;

     nWords = N/32 + (N%32 ? 1 : 0);

     if(alloc == NULL)
	  alloc = cell_malloc;

     vec = (int32_t *) alloc(sizeof(int32_t)*nWords);
     fin = check_read_open(file_name);

     wPos = bPos = 0;
     for(i=0; i < N; i++)
     {
	  checked_scanf(fin, "%d", &tmp);
	  
          vec[wPos] ^= tmp << (31-bPos);
          bPos++;

          if(bPos == 32)
          {
               bPos = 0;
               wPos++;
          }
     }

     fclose(fin);
     return vec;
}

//--------------------------------------------------------------------------------
//
// Write Functions 
//
// [in] file_name - fully qualified filename to write
// [in] N  - length of the vector to read from the file
//

static FILE* check_write_open(const char *file_name)
{
     FILE *fout;
     if((fout = fopen(file_name, "w")) == NULL)
     {
          fprintf(stderr, "Unable to open file for writing \'%s\' : %s\n",
                  file_name, strerror(errno));
          exit(EXIT_FAILURE);
     }
     
     return fout;
}

void s_write(const char *file_name, const float *v, const size_t N)
{
     FILE *fout = check_write_open(file_name);
     s_print(fout, NULL, v, N);
     fclose(fout);
}

void d_write(const char *file_name, const double *v, const size_t N)
{
     FILE *fout = check_write_open(file_name);
     d_print(fout, NULL, v, N);
     fclose(fout);
}

void dl_write(const char *file_name, const long double *v, const size_t N)
{
     FILE *fout = check_write_open(file_name);
     dl_print(fout, NULL, v, N);
     fclose(fout);
}

void c_write(const char *file_name, const float complex *v, const size_t N)
{
     FILE *fout = check_write_open(file_name);
     c_print(fout, NULL, v, N);
     fclose(fout);
}

void z_write(const char *file_name, const double complex *v, const size_t N)
{
     FILE *fout = check_write_open(file_name);
     z_print(fout, NULL, v, N);
     fclose(fout);
}

void zl_write(const char *file_name, const long double complex *v, const size_t N)
{
     FILE *fout = check_write_open(file_name);
     zl_print(fout, NULL, v, N);
     fclose(fout);
}
