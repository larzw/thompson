#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <sys/mman.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <string.h>
#include <limits.h>
#include <assert.h>
#include <mntent.h>
//#include <asm/page.h>
#include <errno.h>
#include <error.h>
#include <inttypes.h>
#include <string.h>

#include "cell_util.h"

//--------------------------------------------------------------------------------
//--------------------------------------------------------------------------------
//
// This file implements a memory allocator which maps memory from huge TLB pages.
// Using large TLB pages helps to keep from thrashing in the translation lookaside
// buffer when dealing with large data sets. For example, 32 MB of data will 
// consume 8192 4k pages (the normal memory page size), but only 2 huge 16MB pages. 
// This difference can be substantial when traversing several such datasets.
//
// The htlb_alloc and htlb_free functions are designed to emulate malloc and free
// so that they could conceivably be used interchangeably. However, memory 
// allocated with htlb_alloc must be freed with htlb_free. Futhermore, this library
// is not re-entrant.
//
//--------------------------------------------------------------------------------
//--------------------------------------------------------------------------------

//--------------------------------------------------------------------------------
// Definitions
//

#define NUM_HTLB_BLOCKS 16
#define HTLB_PAGE_SIZE  (16384*1024)

#define MOUNT_QUERRY_TRIES   3
#define HTLB_UNINITIALIZED  (void*)(NULL)
#define HTLB_UNAVAILABLE    (void*)(-1)
#define HTLB_FILE_SUFFIX    "/hmap.XXXXXX"

//--------------------------------------------------------------------------------
//
// Local bookkeeping 
//

typedef struct
{
     int    fd;
     void*  addr;
     size_t length;
}HTLB_block;

static char *htlb_mount_path = HTLB_UNINITIALIZED;
static int  mount_path_len = 0;
static HTLB_block  block_list[NUM_HTLB_BLOCKS];

static void init_htlb_allocator();	  
static int locate_htlb_mount();
static int create_htlb_map(HTLB_block *b, size_t size);
static int remove_htlb_map(HTLB_block *b);


//--------------------------------------------------------------------------------
//
// huge_alloc - allocate a block of memory from the huge TLB filesystem
//
// Returns:
//    If the allocation was sucessful, a pointer to a memory mapped file on the
//    hugetlbfs is returned, otherwise NULL is returned.
// 
//    To try to be as consistent as possible with malloc, errno is set to
//    ENOMEM on failure.
//
void* huge_alloc(size_t size)
{
     int rc = 0;
     int i, tIdx;

     // Check parameter
     if(size <= 0)
	  return NULL;
     
     // If this is the first call unto this library, then we need to 
     // do some things to setup.
     if(htlb_mount_path == HTLB_UNINITIALIZED)
	  init_htlb_allocator();	  
	  
     // Check to make sure we HAVE a hugt TLB fs
     if(htlb_mount_path == HTLB_UNAVAILABLE)
     {
	  errno = ENOMEM;
	  return NULL;
     }

     // Adjust size to the size of a whole page
     DPRINT(("Requested allocation size: %d\n", size));
     DPRINT(("(HTBL page size %d)\n", HTLB_PAGE_SIZE));
     if(size % HTLB_PAGE_SIZE)
	  size += HTLB_PAGE_SIZE - (size % HTLB_PAGE_SIZE);
     
     DPRINT(("Aligned allocation size: %d\n", size));

     // Okay, at this point we know we have a hugetlbfs, and valid size
     // Find an emptry entry in our memory table
     tIdx = -1;
     for(i=0; i < NUM_HTLB_BLOCKS; i++)
     {
	  if(block_list[i].length == 0)
	  {
	       tIdx = i;
	       break;
	  }
     }
     
     // If there were no blocks available, then we're done
     if(tIdx < 0)
     {
	  DPRINT(("Out of HTLB blocks\n"));
	  errno = ENOMEM;
	  return NULL;
     }

     // We have an unused block. Let's allocate it:
     rc = create_htlb_map(&block_list[tIdx], size);
     if(rc != 0)
     {
	  // If we couldn't map the block, we need to clear it back out
	  memset(&block_list[tIdx], 0, sizeof(HTLB_block));
	  
	  errno = ENOMEM;
	  return NULL;
     }

     DPRINT(("memory allocated @ 0x%x\n", (size_t) block_list[tIdx].addr ));
     
     // We've got a valid block, send it's address on back
     errno = 0;
     return block_list[tIdx].addr;
}


//--------------------------------------------------------------------------------
//
// htlb_free - Release the memory mapped file associated with this address
//
void huge_free(void *m)
{
     int i;

     // Can't do anything with NULL
     if(m == NULL)
	  return;

     // Try to find the address in our block list
     for(i=0; i < NUM_HTLB_BLOCKS; i++)
     {
	  if(block_list[i].addr == m)
	  {
	       // Found the block! De-allocate it...
	       remove_htlb_map(&block_list[i]);
	       memset(&block_list[i], 0, sizeof(HTLB_block));
	       break;
	  }
     }
}

//--------------------------------------------------------------------------------
//
// init_htlb_allocator - One time call to initialize the htlb allocator
//
static void init_htlb_allocator()
{
     int rc;

     // Initialize the block list
     memset(block_list, 0, sizeof(block_list));

     rc = locate_htlb_mount();
     
     if(rc != 0)
	  fprintf(stderr,"Unable to locate htlb mount point: %s\n", strerror(rc));
}

//--------------------------------------------------------------------------------
//
// mmap_htlb - Create and mmap a huge TLB memory file
//
// Returns:
//        0 - on success
//    errno - on failure
//
static int create_htlb_map(HTLB_block *b, size_t size)
{     
     char  file_name[PATH_MAX+1];
     
     strncpy(file_name, htlb_mount_path, PATH_MAX);
     strcat(file_name, HTLB_FILE_SUFFIX);
     
     if((b->fd = mkstemp(file_name)) < 0)
     {
	  DPRINT(("Unable to create temporary file (%s): %s\n", file_name, strerror(errno)));
	  return errno;
     }

     // Clean the file up (it's not needed for mapping)
     unlink(file_name);

     // Memory map the file
     b->addr = mmap(0, size, PROT_READ|PROT_WRITE, MAP_SHARED, b->fd, 0);
     if (b->addr == MAP_FAILED)
     {
	  DPRINT(("Unable to mmap file: %s\n", strerror(errno)));
	  return errno;
     }
   
     b->length = size;

     return 0;
}


//--------------------------------------------------------------------------------
//
// remove_htlb_map - Remove an htlb mapping
//
// Returns - errno if munmap or close fails
//
static int remove_htlb_map(HTLB_block *b)
{
     int rc = 0;

     if(munmap((void*)b->addr, b->length) != 0)
	  rc = errno;
     
     // Even if munmap fails, we'll still try to close
     // the file descriptor
     if(close( b->fd ) != 0)
	  rc = errno;
     
     return rc;
}


//--------------------------------------------------------------------------------
//
// locate_htlb_mount - locate the mountpoint of the huge TLB filesystem 
//
// Returns:
//    0      - successfully found the HTLB mount path
//    ENOENT - unable to locate the mount path
//    errno  - Unable to open the mount table
//
static int locate_htlb_mount()
{
     FILE*           mtable;
     struct mntent*  mentry;
     int retries = 0;
     int rc = 0;
     int total_len = 0;

     // Assume we can't find the mount path
     htlb_mount_path = HTLB_UNAVAILABLE;

     // Try to open the mount table (with retries if its locked)
     while((mtable = setmntent(_PATH_MOUNTED, "r")) == NULL)
     {
	  rc = errno;

	  // If we couldnt open the mount table, it's possible that it's in use and 
	  // has been locked:
	  if (rc == EACCES  ||  rc == EAGAIN || rc == ENFILE) 
	       retries++;
	  else 
	       retries = MOUNT_QUERRY_TRIES;
	  
	  if(retries >= MOUNT_QUERRY_TRIES)
	       return rc;
	  
	  sleep(1);
     }

     // Scan the mount table
     rc = 0;
     while((mentry = getmntent(mtable))) 
     {
	  // When we find the huge TLB filesystem, copy its mount path out
	  if (strcmp(mentry->mnt_type, "hugetlbfs") == 0) 
	  {
	       htlb_mount_path = strdup(mentry->mnt_dir);
	       
	       // Check to make sure we have enough room in the path to make temporary files
	       mount_path_len = strlen(htlb_mount_path);
	       total_len = mount_path_len + strlen(HTLB_FILE_SUFFIX);
	       
	       if(total_len > PATH_MAX)
	       {
		    // If the path is too long then we won't have room 
		    // in the name to create temporary files
		    rc = ENAMETOOLONG;
		    free(htlb_mount_path);
	       }

	       endmntent(mtable);
	       return rc; 
	  }
     }
     
     endmntent(mtable);
     
     // If we get here, then we weren't able to find a path to the huge TLB filesystem :(
     return ENOENT;
}
