#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include "cell_timer.h"

static long timebase = -1;

static void get_timebase()
{
     FILE *f;
     char buf[256];
     char *tok;

     if (!(f = fopen("/proc/cpuinfo", "r")))
     {
          perror("unable to read processor information");
          return;
     }

     while(fgets(buf, 255, f))
     {
          buf[255] = 0;
          tok = strtok(buf, ":");
          if(strncmp(tok, "timebase", strlen("timebase")) == 0)
          {
               tok = strtok(NULL, ":");
	       timebase = atol(tok);
	       break;
          }
     }

     fclose(f);

     if(timebase < 0)
	  fprintf(stderr, "Unable to acquire CPU timebase from /proc/cpuinfo");
}

void init_ppu_timer(ppu_timer *t)
{
     if(timebase < 0)
	  get_timebase();     
     
     t->time_base = timebase;
     t->start_time = t->end_time = 0;
     t->elapsed_ticks = 0;
     t->elapsed_sec = 0;
}
