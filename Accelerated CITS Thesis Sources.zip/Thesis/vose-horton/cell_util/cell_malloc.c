#include <string.h>  //: memset
#include <malloc.h>  //: memalign

#include "cell_util.h"

//--------------------------------------------------------------------------------
//
// cell_malloc - memory allocator
//
// [in] size - number of bytes to allocate
//
// Returns: a void pointer to the allocated memory. If memory cannot be allocated
//          cell_malloc will print an error and terminate the program
//
void* cell_malloc(size_t size)
{
     void *p;

     // No longer do we use memory with just any ole alignment.
     // We need at least 16 byte alignment for transferring data to the SPU.
     
     posix_memalign((void*)&p, 16, size);

     if(!p)
     {
          perror("cell_malloc_error");
          exit(EXIT_FAILURE);
     }

     //Clear p
     memset(p, 0, size);

     return p;
}

//--------------------------------------------------------------------------------
//
// cell_free - free memory allocated by cell_malloc
//
// [in] p -  pointer to memory to be deallocated
//
void cell_free(void *p)
{
     free(p);
}
