#ifndef __PPU_TIMER_H__
#define __PPU_TIMER_H__

#include <ppu_intrinsics.h>   // : __mftb()

typedef struct
{
     unsigned long long time_base;
     unsigned long long start_time;
     unsigned long long end_time;

     long long elapsed_ticks;
     double elapsed_sec;
}ppu_timer;

void init_ppu_timer(ppu_timer *t);

#define start_timer(t)   ((t)->start_time = __mftb())
#define stop_timer(t)							\
     do{								\
	  (t)->end_time = __mftb();					\
	  (t)->elapsed_ticks += (t)->end_time - (t)->start_time;	\
	  (t)->elapsed_sec = (double)(t)->elapsed_ticks/(t)->time_base;	\
     }while(0)

/*
static __attribute__((always_inline)) void start_timer(ppu_timer *t)
{
     t->start_time = __mftb();
}


static __attribute__((always_inline)) void stop_timer(ppu_timer *t)
{
     t->end_time = __mftb();

     t->elapsed_ticks += t->end_time - t->start_time;
     t->elapsed_sec = (double)t->elapsed_ticks/t->time_base;
}
*/
#endif // __PPU_TIMER_H__
