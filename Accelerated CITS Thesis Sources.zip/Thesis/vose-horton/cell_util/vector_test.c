#include "cell_util.h"

void RSVrandomize(float *v, size_t N)
{
     size_t i;

     for(i=0; i < N; i++)
          v[i] = (float)drand48();
}

void RDVrandomize(double *v, size_t N)
{
     size_t i;

     for(i=0; i < N; i++)
          v[i] = drand48();
}
