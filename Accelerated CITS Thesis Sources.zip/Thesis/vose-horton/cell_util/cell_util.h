#ifndef __CELL_UTILS_H__
#define __CELL_UTILS_H__

#include <stdlib.h>   //: size_t
#include <stdio.h>    //: FILE
#include <complex.h>  //: complex
#include <inttypes.h>  //: int32_t

#include "cell_timer.h"

//-----------------------------------------------------------------------------
// Memory Alignment
//-----------------------------------------------------------------------------
#define ALIGN16  __attribute__((aligned (16)))
#define ALIGN128 __attribute__((aligned (128)))

//-----------------------------------------------------------------------------
// Checked Malloc
//-----------------------------------------------------------------------------
void* cell_malloc(size_t size);
void cell_free(void *p);


//-----------------------------------------------------------------------------
// Huge Pages (HTLB)
//-----------------------------------------------------------------------------

// HTLB Page information can be found in /proc/meminfo

void* huge_alloc(size_t size);
void  huge_free(void *m);

//-----------------------------------------------------------------------------
// Debug
//-----------------------------------------------------------------------------

void _elocprint(const char* file, const char *function, int line);
void _errmsg(const char* msg, ...);

#ifdef DEBUG
   #define DPRINT(txt)                                        \
        do{                                                   \
	     ( _elocprint( __FILE__ , __FUNCTION__ , __LINE__ ));	\
	     ( _errmsg txt );						\
        }while(0)
#else
   #define DPRINT(txt)
#endif

//-----------------------------------------------------------------------------
// Vector Utilities
//-----------------------------------------------------------------------------

// Allocator function pointer template
typedef  void* (*vector_allocator)(size_t size);

void s_print(FILE *fout, const char *name, const float *v, const size_t N);
void d_print(FILE *fout, const char *name, const double *v, const size_t N);
void dl_print(FILE *fout, const char *name, const long double *v, const size_t N);
void c_print(FILE *fout, const char *name, 
	     const float complex *v, const size_t N);
void z_print(FILE *fout, const char *name, 
	     const double complex *v, const size_t N);
void zl_print(FILE *fout, const char *name, 
	      const long double complex *v, const size_t N);

float* s_read(const char *file_name, size_t N, vector_allocator alloc);
double* d_read(const char *file_name, size_t N, vector_allocator alloc);
long double* dl_read(const char *file_name, size_t N, vector_allocator alloc);
float complex* c_read(const char *file_name, size_t N, vector_allocator alloc);
double complex* z_read(const char *file_name, size_t N, vector_allocator alloc);
long double complex* zl_read(const char *file_name, size_t N, vector_allocator alloc);
int32_t* bitvector_read(const char *file_name, size_t N, vector_allocator alloc);

void s_write(const char *file_name, const float *v, const size_t N);
void d_write(const char *file_name, const double *v, const size_t N);
void dl_write(const char *file_name, const long double *v, const size_t N);
void c_write(const char *file_name, const float complex *v, const size_t N);
void zl_write(const char *file_name, const long double complex *v, const size_t N);

void RSVrandomize(float *v, size_t N);
void RDVrandomize(double *v, size_t N);

#endif //__CELL_UTILS_H__
