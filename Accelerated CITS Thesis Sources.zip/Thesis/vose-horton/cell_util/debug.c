#include <stdio.h>   //: fprintf, fflush
#include <stdarg.h>  //: valist

//--------------------------------------------------------------------------------
//
// Debugging support functions
//

void _elocprint( const char* file, const char* function, int line)
{
     fprintf(stderr,"%s(%u):%s: ",file, line, function);
     fflush(stderr);
     return;
}

void _errmsg( const char *msg, ... )
{
     va_list ap;
     va_start( ap, msg );
     vfprintf(stderr, msg, ap);
     va_end(ap);

     // Force the output OUT
     fflush(stderr);
     return;
}
