#ifndef _CTIS_BENCH_H
#define _CTIS_BENCH_H

#include "cell_util.h"

extern ppu_timer benchmark_timer;
extern ppu_timer kernel_timer;

void check_ctis_answer(CTIS_Config *cfg, CTIS_Workspace *work);

#endif  //_CTIS_BENCH_H
