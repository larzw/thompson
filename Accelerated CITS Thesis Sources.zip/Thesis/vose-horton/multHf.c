#include <stdlib.h>
#include <stdio.h>
#include <errno.h>
#include <string.h>
#include <math.h>
#include <complex.h>

#include "cell_util.h"
#include "blas_interface.h"
#include "fft_interface.h"
#include "ctis_config.h"
#include "allocator.h"

#define PROGNAME "multHf"

long double *mult_H_f(CTIS_Config *cfg, long double *f, long double complex *Fck, int32_t *ZPattern);

//-----------------------------------------------------------------------------
//
// usage_exit - Splash the help screen then bail
//
void usage_exit()
{
     fprintf(stderr, "usage: %s conf_file\n", PROGNAME);
     fprintf(stderr, " Multipy H matrix by f and write the result\n");
     fprintf(stderr, " Output: x\n");
     fprintf(stderr, " conf_file =  configuration file to use\n");
     exit(EXIT_FAILURE);
}

int main(int argc, const char *argv[])
{
     FILE *wiz_file;
     CTIS_Config cfg;
     long double *f;
     long double *x;
     long double complex *Fck;
     int32_t *ZPattern;
     int zlen;

     if(argc < 2)
	  usage_exit();
     
     parse_config(&cfg, argv[1]);
     //print_config(stdout, &cfg);

     //init_fft_library();
     if((wiz_file = fopen(FFTWL_WISDOM_CACHE, "r")) != NULL)
     {
          printf("Importing FFT wisdom from %s\n", FFTWL_WISDOM_CACHE);
          fftwl_import_wisdom_from_file(wiz_file);
          fclose(wiz_file);
     }
     
     init_blas_library();

     zlen = (cfg.n/2+1)*cfg.w;

     Fck = zl_read(cfg.Fck_fname, zlen, alloc_vector);
     f = dl_read(cfg.f_fname, cfg.m, alloc_vector);
     ZPattern = bitvector_read(cfg.ZPattern_fname, cfg.n, alloc_vector);
     
     x = mult_H_f(&cfg, f, Fck, ZPattern);
     dl_print(stdout, "x", x, 5);
     dl_write(cfg.x_fname, x, cfg.n);
     printf("Wrote %s\n", cfg.x_fname);
     
     free_vector(x);
     free_vector(Fck);
     free_vector(f);
     free_vector(ZPattern);
     
     close_blas_library();

     //close_fft_library();
     if((wiz_file = fopen(FFTWL_WISDOM_CACHE, "w")) != NULL)
     {
          printf("Saving fft wisdom to %s...\n", FFTWL_WISDOM_CACHE);
          fftwl_export_wisdom_to_file(wiz_file);
     }

     fftwl_forget_wisdom();
     
     return 0;
}

void Zexpand(long double *out, long double *in, int32_t *mask, int n, int w)
{
     int i, j, wPos, bPos, z;
     int k;

     k = 0;
     for(i=0; i < w; i++)
     {
          wPos = bPos = 0 ;
          for(j=0; j < n; j++)
          {
               z = mask[wPos] & 1 << (31-bPos);
               if(z)
               {
                    out[(i*n)+j] = in[k];
                    k++;
               }
               else
                    out[(i*n)+j] = 0.0;

               bPos++;
               if(bPos == 32)
               {
                    bPos = 0;
                    wPos++;
               }
          }
     }
}

long double *mult_H_f(CTIS_Config *cfg, long double *f, long double complex *Fck, int32_t *ZPattern)
{
     long double *x;
     long double *v1;
     long double complex *v2;
     long double scalar;
     int n = cfg->n;
     int w = cfg->w;
     int clen = (n/2+1);
     int i;
     fftwl_plan forward_plan;
     fftwl_plan backward_plan;

     x = alloc_vector(sizeof(long double)*n);
     v1 = alloc_vector(sizeof(long double)*n*w);
     v2 = alloc_vector(sizeof(long double complex)*n);

     forward_plan = fftwl_plan_dft_r2c_1d(n, (long double*) v1, (long double complex*) v2,  FFT_MODE);
     backward_plan = fftwl_plan_dft_c2r_1d(n, (long double complex*) v2, (long double*) v1,  FFT_MODE);

     Zexpand(v1, f, ZPattern, n, w);
     
     for(i=0; i < w; i++)
     {
	  fftwl_execute_dft_r2c(forward_plan, &v1[i*n], v2);	  
	  
	  cell_jmult(clen, &Fck[i*clen], 1, v2, 1);
	  fftwl_execute_dft_c2r(backward_plan, v2, &v1[i*n]);
	  cell_laxpy(n, 1, &v1[i*n], 1, x, 1);
     }
     
     scalar = (long double)1/(long double)n;
     cell_lscale(n, scalar, x, 1);

     free_vector(v1);
     free_vector(v2);

     return x;
}
