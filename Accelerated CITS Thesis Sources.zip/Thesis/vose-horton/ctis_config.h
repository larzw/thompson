#ifndef _CTIS_CONFIG_H
#define _CTIS_CONFIG_H

#include <stdio.h>

typedef struct {
     long n;
     long m;
     long w;
     long alpha;
     long a;
     long g;
     double mu;
     double muInv;
     long zlen;
     
     // Iterative Parameters
     int    MAX_CTIS_ITERS;
     double CG_EPSILON;
     int    CG_ITERS;
     
     char *Hmatrix_fname;
     char *x_fname;
     char *f_fname;
     char *f_out;
     char *eta_fname;
     char *Fck_fname;
     char *ZPattern_fname;
} CTIS_Config;
    
void parse_config(CTIS_Config *cfg, const char *conf_file);
void print_config(FILE *out, const CTIS_Config *cfg);
int isString(const char *s1, const char *s2);

#endif /* _CTIS_CONFIG_H */
