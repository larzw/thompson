#include <stdlib.h>          // : exit, strtod, strtoll
#include <stdio.h>           // : fopen, fclose
#include <unistd.h>          // : getopt
#include <inttypes.h>        // : int64_t
#include <errno.h>           // : errno, ERANGE
#include <string.h>          // : strcmp
#include <math.h>            // : fabs
#include <complex.h>

#include "ctis_mixed.h"
#include "ctis_config.h"
#include "fft_interface.h"
#include "cell_util.h"
#include "blas_interface.h"
#include "allocator.h"

ppu_timer benchmark_timer;
ppu_timer kernel_timer;

void check_ctis_answer(CTIS_Config *cfg, CTIS_Workspace *work)
{
     int i;
     double d;
     double abs_sum, rel_sum;
     double max_diff, rel_max;
     double x_hat, x;
     double relative;

     abs_sum = rel_sum = rel_max = max_diff = 0;

     for(i=1; i < cfg->m; i++)
     {
          x     = work->f[i];
          x_hat = work->f_est[i];

          d = fabs(x - x_hat);

          // Largest difference element
          if(d > max_diff)
               max_diff = d;

          if(x != 0)
               relative = d/fabs(x);
          else
               relative = d;

          rel_sum += relative;

          if(rel_max < relative)
                rel_max = relative;

          abs_sum += d;
     }

     fprintf(stdout, " CTIS solution error (AbsAvg, AbsMax, RelAvg, RelMax): (%.2e, %.2e, %.2e, %.2e)\n",
             abs_sum/cfg->m, max_diff, rel_sum/cfg->m, rel_max);
}

void solve_f_heuristic(CTIS_Config *cfg, CTIS_Workspace *work)
{
     // Local aliases
     int n        = cfg->n;     
     float *x     = work->x;
     float *frv   = (float *) work->v;
     
     // Local Variables
     int iters;
     
     iters = 0;
     
     // v = x
     cell_scopy(n, x, frv);

     while(iters < cfg->MAX_CTIS_ITERS)
     {
	  // Only time the core kernel, not the status and feedback routines.
	  init_ppu_timer(&kernel_timer);
	  
	  start_timer(&kernel_timer);
	  start_timer(&benchmark_timer);

	  heuristic_kernel(cfg, work);
	  calculate_residual(cfg, work);
	  
	  stop_timer(&benchmark_timer);
	  stop_timer(&kernel_timer);
	  
	  iters++;
	  
	  fprintf(stdout, " CTIS iteration %d: Kernel Time (%lld ticks, %lf sec), "
		  "Total Time (%lld ticks, %lf sec)\n",
		  iters, kernel_timer.elapsed_ticks, kernel_timer.elapsed_sec, 
		  benchmark_timer.elapsed_ticks, benchmark_timer.elapsed_sec);
	  
          check_ctis_answer(cfg, work);
     }
}

void setup_fft_plans(CTIS_Config *cfg, CTIS_Workspace *work)
{
     DPRINT(("Setting up FFTW plans...\n"));
     
     long n = cfg->n;
     
     // Create plans for both in-place, and out of place transforms
     
     work->fft_ip  = fftwf_plan_dft_r2c_1d(n, (float*) work->v, (float complex*) work->v,  FFT_MODE);
     work->ifft_ip = fftwf_plan_dft_c2r_1d(n, (float complex*) work->v, (float*) work->v, FFT_MODE);
     
     work->fft_oop  = fftwf_plan_dft_r2c_1d(n, (float*) work->v, (float complex*) work->v1,  FFT_MODE);
     work->ifft_oop = fftwf_plan_dft_c2r_1d(n, (float complex*) work->v, (float*) work->v1, FFT_MODE);
}

void load_CTIS_Workspace(CTIS_Config *cfg, CTIS_Workspace *work)
{
     long n, m, w, zlen;

     n = cfg->n;
     m = cfg->m;
     w = cfg->w;
     zlen = (n/2+1)*w;
     
     // Load data vectors
     DPRINT(("Loading data vectors\n"));
     work->ZPattern = bitvector_read(cfg->ZPattern_fname, n, alloc_vector);
     work->Fck = z_read(cfg->Fck_fname, zlen, alloc_vector);
     work->eta = z_read(cfg->eta_fname, zlen, alloc_vector);
     work->x   = s_read(cfg->x_fname, n, alloc_vector);
     work->f   = s_read(cfg->f_fname, m, alloc_vector);

     // Setup single precision versions of Fck and eta
     work->eta_f = (float complex *) alloc_vector(sizeof(float complex)*zlen);
     cell_z2c(zlen, work->eta, work->eta_f);

     work->Fck_f = (float complex *) alloc_vector(sizeof(float complex)*zlen);
     cell_z2c(zlen, work->Fck, work->Fck_f);

     //c_print(stdout, "Fck_f", work->Fck_f, 10);
     //c_print(stdout, "eta_f", work->eta_f, 10);
     //s_print(stdout, "x", work->x, 10);
     //s_print(stdout, "f", work->f, 10);

     // Allocate workspace vectors
     work->f_est = (float *) alloc_vector(sizeof(float)*m);
     
     DPRINT(("Allocating complex workspace vectors, size %u elements\n", zlen));
     work->v = (double complex *) alloc_vector(sizeof(double complex)*zlen);
     work->v1 = (double complex *) alloc_vector(sizeof(double complex)*zlen);
     work->v2 = (double complex *) alloc_vector(sizeof(double complex)*zlen);
     work->v3 = (double complex *) alloc_vector(sizeof(double complex)*zlen);
     
     zlen = (n*w);
     DPRINT(("Allocating real workspace vectors, size %u elements\n", zlen));

     work->cg_x = (float *) alloc_vector(sizeof(float)*zlen);
     work->cg_r = (float *) alloc_vector(sizeof(float)*zlen);
     work->cg_p = (float *) alloc_vector(sizeof(float)*zlen);
     work->cg_v = (float *) alloc_vector(sizeof(float)*zlen);

     DPRINT(("All workspace allocation complete\n"));
};

void release_CTIS_Data(CTIS_Workspace *work)
{
     DPRINT(("Freeing resources\n"));
     
     // Release allocated memory
     free_vector(work->Fck);
     free_vector(work->eta);
     free_vector(work->x);
     free_vector(work->v);
     free_vector(work->v1);
     free_vector(work->v2);
     free_vector(work->v3);
     free_vector(work->cg_x);
     free_vector(work->cg_r);
     free_vector(work->cg_p);
     free_vector(work->cg_v);
}

//-----------------------------------------------------------------------------
//
// usage_exit - Splash the help screen then bail
//
void usage_exit()
{
     fprintf(stderr, "usage: %s [-h] conf_file\n", PROGNAME);
     fprintf(stderr, " CTIS Vose-Horton Solver\n");
     fprintf(stderr, "  -h        =  Use huge TLB pages for memory allocation"\
	             "(if available)\n");
     fprintf(stderr, "  conf_file =  configuration file to use\n");
     exit(EXIT_FAILURE);
}

void init_fftwf_library()
{
     FILE *wiz_file;

     fftwf_cell_set_nspe(4);
     
     if((wiz_file = fopen(FFTWF_WISDOM_CACHE, "r")) != NULL)
     {
          printf("Importing FFT wisdom from %s\n", FFTWF_WISDOM_CACHE);
          fftwf_import_wisdom_from_file(wiz_file);
          fclose(wiz_file);
     }
}

void close_fftwf_library()
{
     FILE *wiz_file;

     if((wiz_file = fopen(FFTWF_WISDOM_CACHE, "w")) != NULL)
     {
          printf("Saving fft wisdom to %s...\n", FFTWF_WISDOM_CACHE);
          fftwf_export_wisdom_to_file(wiz_file);
     }

     fftwf_forget_wisdom();
}

//-----------------------------------------------------------------------------
//
// main - PPU application entry point
//
int main(int argc, char **argv)
{
     CTIS_Config cfg;
     CTIS_Workspace work;
     int c;
     int huge_pages = 0;

     while((c = getopt(argc, argv, ":h")) != -1)
     {
          switch(c)
          {

          case 'h':
               huge_pages = 1;
               break;

          case '?':
          default:
               usage_exit();
          }
     }

     if(optind >= argc)
          usage_exit();

     alloc_init(huge_pages);

     parse_config(&cfg, argv[optind]);
     print_config(stdout, &cfg);

     init_fftwf_library();
     init_blas_library();

     load_CTIS_Workspace(&cfg, &work);

     setup_fft_plans(&cfg, &work);

     init_ppu_timer(&benchmark_timer);
     
     fprintf(stdout, "Running CTIS solver...\n");
     solve_f_heuristic(&cfg, &work);
     
     fprintf(stdout, "\n-------------------------------------------------------------\n");
     fprintf(stdout, " CTIS solution final execution time: (%lld ticks, %lf sec)\n",
             benchmark_timer.elapsed_ticks, benchmark_timer.elapsed_sec);
     
     check_ctis_answer(&cfg, &work);

     s_write(cfg.f_out, work.f_est, cfg.m);

     release_CTIS_Data(&work);

     close_blas_library();
     close_fftwf_library();

     return 0;
}
