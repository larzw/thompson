#include "blas_interface.h"

#ifndef WITH_SPES

// Without SPE support, no initialization is needed for the blasx library

void init_blas_library()
{
     // NO-OP
}

void close_blas_library()
{
     // NO-OP
}

#else

void init_blas_library()
{
     limit_blasx_spes(2);
     init_blasx_library();
}

void close_blas_library()
{
     close_blasx_library();
}

#endif


