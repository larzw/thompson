#ifndef _CTIS_H
#define _CTIS_H

#include <stdio.h>    //: FILE
#include <inttypes.h>
#include <complex.h>  //: complex float
#include "fft_interface.h"
#include "ctis_config.h"

#define PROGNAME            "ctis"

typedef struct {

     // Problem Data
     float *f;
     float *x;
     double complex *eta;
     double complex *Fck;
     float complex *eta_f;
     float complex *Fck_f;
     int32_t *ZPattern;

     // Scratch space
     double complex *v;
     double complex *v1;
     double complex *v2;
     double complex *v3;
     float *cg_x;
     float *cg_r;
     float *cg_p;
     float *cg_v;

     // FFTW Plans
     fftwf_plan fft_ip;
     fftwf_plan ifft_ip;
     fftwf_plan fft_oop;
     fftwf_plan ifft_oop;

     // The answer
     float *f_est;
     
} CTIS_Workspace;

void load_CTIS_Workspace(CTIS_Config *cfg, CTIS_Workspace *work);
void release_CTIS_Workspace(CTIS_Workspace *work);

void setup_fft_plans(CTIS_Config *cfg, CTIS_Workspace *work);

// Solve f = H\x
void solve_f_heuristic(CTIS_Config *cfg,  CTIS_Workspace *work);
void heuristic_kernel(CTIS_Config *cfg,   CTIS_Workspace *work);
void calculate_residual(CTIS_Config *cfg, CTIS_Workspace *work);
void conjugate_gradient(CTIS_Config *cfg, CTIS_Workspace *work);

void RunLSAdjust(float *v1, float *f, float lse, int32_t *mask, int n, int w);
void RunZReduce(float *f, float *v2, float *v, int32_t *mask, int n, int w);

#endif // _CTIS_H
