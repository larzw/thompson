#include <complex.h>
#include <math.h>

//-----------------------------------------------------------------------------
// long double
//-----------------------------------------------------------------------------
void blasx_laxpy(const int N, const long double alpha,
                 const long double *X,
                 const int incX, long double *Y,
                 const int incY)
{
     int i;
     for(i=0; i < N; i++)
          Y[i*incY] = (X[i*incX]*(alpha)) + Y[i*incY];
}

void blasx_lscale(const int N, const long double alpha,
                  long double *X, const int incX)
{
     int i;
     for(i=0; i < N; i++)
          X[i*incX] = X[i*incX] * (alpha);
}

//-----------------------------------------------------------------------------
// long double complex
//-----------------------------------------------------------------------------
void blasx_jscale(const int N, const long double complex alpha,
                  long double complex *X, const int incX)
{
     int i;
     for(i=0; i < N; i++)
          X[i*incX] = X[i*incX] * alpha;
}

void blasx_jmultc(const int N, const long double complex *X,
                  const int incX, long double complex *Y, const int incY)
{
     int i;
     for(i=0; i < N; i++)
          Y[i*incY] = conjl(X[i*incX]) * Y[i*incY];
}

void blasx_jaxpy(const int N, const long double complex alpha,
                 const long double complex *X,
                 const int incX, long double complex *Y,
                 const int incY)
{
     int i;
     for(i=0; i < N; i++)
          Y[i*incY] = (X[i*incX]*alpha) + Y[i*incY];
}

void blasx_jpow(const int N, const long double complex alpha,
                long double complex *X, const int incX)
{
     int i;
     for(i=0; i < N; i++)
          X[i*incX] = cpowl(X[i*incX], alpha);
}

void blasx_jcopy(const int N, const long double complex *X,
                 const int incX, long double complex *Y, const int incY)
{
     int i;
     for(i=0; i < N; i++)
          Y[i*incY] = X[i*incX];
}


void blasx_jmult(const int N, const long double complex *X, const int incX,
                 long double complex *Y, const int incY)
{
     int i;
     for(i=0; i < N; i++)
          Y[i*incY] = X[i*incX] * Y[i*incY];
}
