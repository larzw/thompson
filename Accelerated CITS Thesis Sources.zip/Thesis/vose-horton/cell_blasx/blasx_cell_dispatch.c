#include <stdlib.h>
#include <inttypes.h>
#include <complex.h>
#include <math.h>
#include <string.h>

#include "blasx_cell_common.h"
#include "blasx_cell.h"
#include "blasx.h"

//-----------------------------------------------------------------------------
// single
//-----------------------------------------------------------------------------
double map_scopy(const int N, 
		 const double alpha_real NOT_USED,
                 const double alpha_imag NOT_USED,
                 const void *X, 
		 const void *Y           NOT_USED, 
		 void *Z)
{
     blasx_scopy(N, X, Z);
     return 0;
}

void blasx_cell_scopy(const int N, const float *X, float *Z)
{
     blasx_spe_vec(BSC_scopy, N, 0, 0, X, NULL, Z, map_scopy);
}

//-----------------------------------------------------------------------------

double map_sscale(const int N, 
		  const double alpha_real,
                  const double alpha_imag NOT_USED,
                  const void *X, 
		  const void *Y           NOT_USED, 
		  void *Z)
{
     blasx_sscale(N, (float)alpha_real, X, Z);
     return 0;
}

void blasx_cell_sscale(const int N, const float alpha, const float *X, float *Z)
{
     blasx_spe_vec(BSC_sscale, N, alpha, 0, X, NULL, Z, map_sscale);
}

//-----------------------------------------------------------------------------

double map_saxpy(const int N, 
		 const double alpha_real,
                 const double alpha_imag NOT_USED,
                 const void *X, 
		 const void *Y, 
		 void *Z)
{
     blasx_saxpy(N, (float)alpha_real, X, Y, Z);
     return 0;
}

void blasx_cell_saxpy(const int N, const float alpha, const float *X,
		      const float *Y, float *Z)
{
     blasx_spe_vec(BSC_saxpy, N, alpha, 0, X, Y, Z, map_saxpy);
}

//-----------------------------------------------------------------------------

double map_ssxpy(const int N, 
		 const double alpha_real,
                 const double alpha_imag NOT_USED,
                 const void *X, 
		 const void *Y, 
		 void *Z)
{
     blasx_ssxpy(N, (float)alpha_real, X, Y, Z);
     return 0;
}

void blasx_cell_ssxpy(const int N, const float alpha, const float *X,
                 const float *Y, float *Z)
{
     blasx_spe_vec(BSC_ssxpy, N, alpha, 0, X, Y, Z, map_ssxpy);
}

//-----------------------------------------------------------------------------

double map_sdot(const int N, 
		const double alpha_real NOT_USED,
                const double alpha_imag NOT_USED,
                const void *X, 
		const void *Y, 
		void *Z                 NOT_USED)
{
     return blasx_sdot(N, X, Y);
}

double blasx_cell_sdot(const int N, const float *X, const float *Y)
{
     return blasx_spe_vec(BSC_sdot, N, 0, 0, X, Y, NULL, map_sdot);
}


//-----------------------------------------------------------------------------
// single complex
//-----------------------------------------------------------------------------

double map_ccopy(const int N, 
		 const double alpha_real NOT_USED,
		 const double alpha_imag NOT_USED,
		 const void *X, 
		 const void *Y           NOT_USED,
		 void *Z)
{
     blasx_ccopy(N, X, Z);
     return 0;
}

void blasx_cell_ccopy(const int N, const float complex *X, float complex *Z)
{
     blasx_spe_vec(BSC_ccopy, N, 0, 0, X, NULL, Z, map_ccopy);
}

//-----------------------------------------------------------------------------

double map_caxpy(const int N,
                 const double alpha_real,
                 const double alpha_imag,
                 const void *X,
                 const void *Y,
                 void *Z)
{
     float complex alpha = alpha_real + alpha_imag * I;
     
     blasx_caxpy(N, alpha, X, Y, Z);

     return 0;
}

void blasx_cell_caxpy(const int N, const float complex alpha,
                 const float complex *X, const float complex *Y,
                 float complex *Z)
{
     blasx_spe_vec(BSC_caxpy, N, crealf(alpha), cimag(alpha), X, Y, Z, map_caxpy);
}

//-----------------------------------------------------------------------------

double map_csxpy(const int N,
                 const double alpha_real,
                 const double alpha_imag,
                 const void *X,
                 const void *Y,
                 void *Z)
{
     float complex alpha = alpha_real + alpha_imag * I;
     blasx_csxpy(N, alpha, X, Y, Z);
     return 0;
}

void blasx_cell_csxpy(const int N, const float complex alpha,
                 const float complex *X, const float complex *Y,
                 float complex *Z)
{
     blasx_spe_vec(BSC_csxpy, N, crealf(alpha), cimag(alpha), X, Y, Z, map_csxpy);
}

//-----------------------------------------------------------------------------


double map_cscale(const int N,
		  const double alpha_real,
		  const double alpha_imag,
		  const void *X,
		  const void *Y NOT_USED,
		  void *Z)
{
     float complex alpha = alpha_real + alpha_imag * I;
     blasx_cscale(N, alpha, X, Z);     
     return 0;
}

void blasx_cell_cscale(const int N, const float complex alpha, 
		       const float complex *X, float complex *Z)
{
     blasx_spe_vec(BSC_cscale, N, crealf(alpha), cimag(alpha), X, NULL, Z, map_cscale);
}

//-----------------------------------------------------------------------------

double map_cmult(const int N,
		 const double alpha_real NOT_USED,
		 const double alpha_imag NOT_USED,
		 const void *X,
		 const void *Y,
		 void *Z)
{
     blasx_cmult(N, X, Y, Z);
     return 0;
}

void blasx_cell_cmult(const int N, const float complex *X,  
		 const float complex *Y, float complex *Z)
{
     blasx_spe_vec(BSC_cmult, N, 0, 0, X, Y, Z, map_cmult);
}

//-----------------------------------------------------------------------------

double map_cmultc(const int N,
		  const double alpha_real NOT_USED,
		  const double alpha_imag NOT_USED,
		  const void *X,
		  const void *Y,
		  void *Z)
{
     blasx_cmultc(N, X, Y, Z);
     return 0;
}

void blasx_cell_cmultc(const int N, const float complex *X,
		  const float complex *Y, float complex *Z)
{
     blasx_spe_vec(BSC_cmultc, N, 0, 0, X, Y, Z, map_cmultc);
}

//-----------------------------------------------------------------------------
// Mixed precision
//-----------------------------------------------------------------------------

double map_zmultc_mixed(const int N,
			const double alpha_real NOT_USED,
			const double alpha_imag NOT_USED,
			const void *X,
			const void *Y,
			void *Z)
{
     blasx_zmultc_mixed(N, X, Y, Z);
     return 0;
}

void blasx_cell_zmultc_mixed(const int N, const double complex *X,
                             const float complex *Y, double complex *Z)
{
     blasx_spe_vec(BSC_zmultc_mixed, N, 0, 0, X, Y, Z, map_zmultc_mixed);
}

//-----------------------------------------------------------------------------

double map_zsxpy_mixed(const int N,
		       const double alpha_real,
		       const double alpha_imag,
		       const void *X,
		       const void *Y,
		       void *Z)
{
     double complex alpha = alpha_real + alpha_imag * I;
     blasx_zsxpy_mixed(N, alpha, X, Y, Z);
     return 0;
}

void blasx_cell_zsxpy_mixed(const int N, const double complex alpha,
                            const double complex *X, const double complex *Y,
                            float complex *Z)
{
     blasx_spe_vec(BSC_zsxpy_mixed, N, creal(alpha), cimag(alpha), X, Y, Z, map_zsxpy_mixed);
}

double map_zero(const int N,
		const double alpha_real NOT_USED,
		const double alpha_imag NOT_USED,
		const void *X           NOT_USED,
		const void *Y           NOT_USED,
		void *Z)
{
     memset(Z, 0, N*S_SIZE);
     return 0;
}

void blasx_cell_zero(size_t N, void *Z)
{
     // Don't attempt acceleration if the size to be zero'd isn't word aligned
     if(N & S_SIZE)
     {
	  memset(Z, 0, N);
	  return;
     }
     
     blasx_spe_vec(BSC_zero, N/S_SIZE, 0, 0, NULL, NULL, Z, map_zero);
}

//-----------------------------------------------------------------------------
// double
//-----------------------------------------------------------------------------


double map_dcopy(const int N,
                 const double alpha_real NOT_USED,
                 const double alpha_imag NOT_USED,
                 const void *X,
                 const void *Y           NOT_USED,
                 void *Z)
{
     blasx_dcopy(N, X, Z);
     return 0;
}

void blasx_cell_dcopy(const int N, const double *X, double *Z)
{
     blasx_spe_vec(BSC_dcopy, N, 0, 0, X, NULL, Z, map_dcopy);     
}

//-----------------------------------------------------------------------------

double map_dscale(const int N,
                  const double alpha_real,
                  const double alpha_imag NOT_USED,
                  const void *X,
                  const void *Y           NOT_USED,
                  void *Z)
{
     blasx_dscale(N, alpha_real, X, Z);
     return 0;
}

void blasx_cell_dscale(const int N, const double alpha, const double *X, double *Z)
{
     blasx_spe_vec(BSC_dscale, N, alpha, 0, X, NULL, Z, map_dscale);
}

//-----------------------------------------------------------------------------

double map_daxpy(const int N,
                 const double alpha_real,
                 const double alpha_imag NOT_USED,
                 const void *X,
                 const void *Y,
                 void *Z)
{
     blasx_daxpy(N, alpha_real, X, Y, Z);
     return 0;
}


void blasx_cell_daxpy(const int N, const double alpha, const double *X,
                      const double *Y, double *Z)
{
     blasx_spe_vec(BSC_daxpy, N, alpha, 0, X, Y, Z, map_daxpy);
}

//-----------------------------------------------------------------------------

double map_dsxpy(const int N,
                 const double alpha_real,
                 const double alpha_imag NOT_USED,
                 const void *X,
                 const void *Y,
                 void *Z)
{
     blasx_dsxpy(N, alpha_real, X, Y, Z);
     return 0;
}

void blasx_cell_dsxpy(const int N, const double alpha, const double *X,
                      const double *Y, double *Z)
{
     blasx_spe_vec(BSC_dsxpy, N, alpha, 0, X, Y, Z, map_dsxpy);
}

//-----------------------------------------------------------------------------

double map_ddot(const int N,
                const double alpha_real NOT_USED,
                const double alpha_imag NOT_USED,
                const void *X,
                const void *Y,
                void *Z                 NOT_USED)
{
     return blasx_ddot(N, X, Y);
}

double blasx_cell_ddot(const int N, const double *X, const double *Y)
{
     return blasx_spe_vec(BSC_ddot, N, 0, 0, X, Y, NULL, map_ddot);
}


//-----------------------------------------------------------------------------
// double complex
//-----------------------------------------------------------------------------

double map_zcopy(const int N,
                 const double alpha_real NOT_USED,
                 const double alpha_imag NOT_USED,
                 const void *X,
                 const void *Y           NOT_USED,
                 void *Z)
{
     blasx_zcopy(N, X, Z);
     return 0;
}

void blasx_cell_zcopy(const int N, const double complex *X, double complex *Z)
{
     blasx_spe_vec(BSC_zcopy, N, 0, 0, X, NULL, Z, map_zcopy);
}

//-----------------------------------------------------------------------------

double map_zaxpy(const int N,
                 const double alpha_real,
                 const double alpha_imag,
                 const void *X,
                 const void *Y,
                 void *Z)
{
     double complex alpha = alpha_real + alpha_imag * I;
     blasx_zaxpy(N, alpha, X, Y, Z);
     return 0;
}

void blasx_cell_zaxpy(const int N, const double complex alpha,
                      const double complex *X, const double complex *Y,
                      double complex *Z)
{
     blasx_spe_vec(BSC_zaxpy, N, creal(alpha), cimag(alpha), X, Y, Z, map_zaxpy);
}

//-----------------------------------------------------------------------------

double map_zsxpy(const int N,
                 const double alpha_real,
                 const double alpha_imag,
                 const void *X,
                 const void *Y,
                 void *Z)
{
     double complex alpha = alpha_real + alpha_imag * I;
     blasx_zsxpy(N, alpha, X, Y, Z);
     return 0;
}

void blasx_cell_zsxpy(const int N, const double complex alpha,
                      const double complex *X, const double complex *Y,
                      double complex *Z)
{
     blasx_spe_vec(BSC_zsxpy, N, creal(alpha), cimag(alpha), X, Y, Z, map_zsxpy);
}

//-----------------------------------------------------------------------------

double map_zscale(const int N,
                  const double alpha_real,
                  const double alpha_imag,
                  const void *X,
                  const void *Y NOT_USED,
                  void *Z)
{
     double complex alpha = alpha_real + alpha_imag * I;
     blasx_zscale(N, alpha, X, Z);
     return 0;
}

void blasx_cell_zscale(const int N, const double complex alpha,
                       const double complex *X, double complex *Z)
{
     blasx_spe_vec(BSC_zscale, N, creal(alpha), cimag(alpha), X, NULL, Z, map_zscale);
}

//-----------------------------------------------------------------------------

double map_zmult(const int N,
                 const double alpha_real NOT_USED,
                 const double alpha_imag NOT_USED,
                 const void *X,
                 const void *Y,
                 void *Z)
{
     blasx_zmult(N, X, Y, Z);
     return 0;
}

void blasx_cell_zmult(const int N, const double complex *X,
                      const double complex *Y, double complex *Z)
{
     blasx_spe_vec(BSC_zmult, N, 0, 0, X, Y, Z, map_zmult);
}

//-----------------------------------------------------------------------------

double map_zmultc(const int N,
                  const double alpha_real NOT_USED,
                  const double alpha_imag NOT_USED,
                  const void *X,
                  const void *Y,
                  void *Z)
{
     blasx_zmultc(N, X, Y, Z);
     return 0;
}

void blasx_cell_zmultc(const int N, const double complex *X,
                       const double complex *Y, double complex *Z)
{
     blasx_spe_vec(BSC_zmultc, N, 0, 0, X, Y, Z, map_zmultc);
}
