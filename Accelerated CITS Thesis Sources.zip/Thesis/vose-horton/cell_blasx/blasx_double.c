#include <inttypes.h>
#include <complex.h>
#include <math.h>

//-----------------------------------------------------------------------------
// double
//-----------------------------------------------------------------------------

void blasx_dcopy(const int N, const double *X, double *Z)
{
     int i;
     for(i=0; i < N; i++)
          Z[i] = X[i];     
}

void blasx_dscale(const int N, const double alpha, const double *X, double *Z)
{
     int i;
     for(i=0; i < N; i++)
          Z[i] = X[i] * (alpha);
}

void blasx_daxpy(const int N, const double alpha, const double *X,
                 const double *Y, double *Z)
{
     int i;
     for(i=0; i < N; i++)
          Z[i] = (X[i]*alpha) + Y[i];
}

void blasx_dsxpy(const int N, const double alpha, const double *X,
                 const double *Y, double *Z)
{
     int i;
     for(i=0; i < N; i++)
          Z[i] = (X[i]*alpha) - Y[i];     
}

double blasx_ddot(const int N, const double *X, const double *Y)
{
     double dot=0;
     int i;
     for(i=0; i < N; i++)
          dot += (X[i] * Y[i]);
     return dot;
}

void blasx_dmask(const int N, const double alpha, const double *X, double *Z, 
		 int flip, int32_t *mask)
{
     int i, wPos, bPos, v;
     int32_t word = 0;
     
     wPos = -1;
     bPos = 0;

     for(i=0; i < N; i++)
     {
	  if(bPos == 0)
	  {
	       wPos++;
		
	       if(flip)
		    word = ~mask[wPos];
	       else
		    word = mask[wPos];
	  }

	  v = word & 1 << (31-bPos);

	  if(v)
	  {
	       Z[i] = alpha*X[i];
	  }
	  else
	       Z[i] = 0.0;
	  
	  bPos = (bPos + 1) % 32;
     }
}

//-----------------------------------------------------------------------------
// double complex
//-----------------------------------------------------------------------------

void blasx_zcopy(const int N, const double complex *X, double complex *Z)
{
     int i;
     for(i=0; i < N; i++)
          Z[i] = X[i];
}

void blasx_zaxpy(const int N, const double complex alpha,
                 const double complex *X, const double complex *Y,
                 double complex *Z)
{
     int i;
     for(i=0; i < N; i++)
          Z[i] = (X[i]*alpha) + Y[i];
}

void blasx_zsxpy(const int N, const double complex alpha,
                 const double complex *X, const double complex *Y,
                 double complex *Z)
{
     int i;
     for(i=0; i < N; i++)
          Z[i] = (X[i]*alpha) - Y[i];
}

void blasx_zscale(const int N, const double complex alpha, 
		  const double complex *X, double complex *Z)
{
     int i;
     for(i=0; i < N; i++)
	  Z[i] = X[i] * alpha;
}

void blasx_zmult(const int N, const double complex *X,  
		 const double complex *Y, double complex *Z)
{
     int i;
     for(i=0; i < N; i++)
	  Z[i] = X[i] * Y[i];
}

void blasx_zmultc(const int N, const double complex *X,
		  const double complex *Y, double complex *Z)
{
     int i;
     for(i=0; i < N; i++)
	  Z[i] = conj(X[i]) * Y[i];
}
