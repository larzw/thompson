#ifndef _BLASX_CELL_H_
#define _BLASX_CELL_H_

#define CELL_ALIGNED ((void*)0xF)

void blasx_spes_exec();
void blasx_spes_wait();
void blasx_start_spes(int num_spes);
void blasx_stop_spes();

typedef double (*vfunc)(const int N, const double alpha_real,
			const double alpha_imag,
			const void *X, const void *Y, void *Z);

double blasx_spe_vec(int dispatch_idx, const int N, const double alpha_real, 
		     const double alpha_imag,
		     const void *X, const void *Y, void *Z, vfunc cleanup);

#endif // _BLASX_CELL_H_
