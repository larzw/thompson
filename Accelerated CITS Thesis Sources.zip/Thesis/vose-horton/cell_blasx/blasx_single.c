#include <inttypes.h>
#include <complex.h>
#include <math.h>

//-----------------------------------------------------------------------------
// single
//-----------------------------------------------------------------------------

void blasx_scopy(const int N, const float *X, float *Z)
{
     int i;
     for(i=0; i < N; i++)
          Z[i] = X[i];     
}

void blasx_sscale(const int N, const float alpha, const float *X, float *Z)
{
     int i;
     for(i=0; i < N; i++)
          Z[i] = X[i] * (alpha);
}

void blasx_saxpy(const int N, const float alpha, const float *X,
                 const float *Y, float *Z)
{
     int i;
     for(i=0; i < N; i++)
          Z[i] = (X[i]*alpha) + Y[i];
}

void blasx_ssxpy(const int N, const float alpha, const float *X,
                 const float *Y, float *Z)
{
     int i;
     for(i=0; i < N; i++)
          Z[i] = (X[i]*alpha) - Y[i];     
}

double blasx_sdot(const int N, const float *X, const float *Y)
{
     double dot=0;
     int i;
     for(i=0; i < N; i++)
          dot += ((double)X[i] * (double)Y[i]);
     return dot;
/*
     float dot=0;
     int i;
     for(i=0; i < N; i++)
          dot += (X[i] * Y[i]);
     return dot;
*/
}

void blasx_smask(const int N, const float alpha, const float *X, float *Z, 
		 int flip, int32_t *mask)
{
     int i, wPos, bPos, v;
     int32_t word = 0;
     
     wPos = -1;
     bPos = 0;

     for(i=0; i < N; i++)
     {
	  if(bPos == 0)
	  {
	       wPos++;
		
	       if(flip)
		    word = ~mask[wPos];
	       else
		    word = mask[wPos];
	  }

	  v = word & 1 << (31-bPos);

	  if(v)
	  {
	       Z[i] = alpha*X[i];
	  }
	  else
	       Z[i] = 0.0;
	  
	  bPos = (bPos + 1) % 32;
     }
}

//-----------------------------------------------------------------------------
// float complex
//-----------------------------------------------------------------------------

void blasx_ccopy(const int N, const float complex *X, float complex *Z)
{
     int i;
     for(i=0; i < N; i++)
          Z[i] = X[i];
}

void blasx_caxpy(const int N, const float complex alpha,
                 const float complex *X, const float complex *Y,
                 float complex *Z)
{
     int i;
     for(i=0; i < N; i++)
          Z[i] = (X[i]*alpha) + Y[i];
}

void blasx_csxpy(const int N, const float complex alpha,
                 const float complex *X, const float complex *Y,
                 float complex *Z)
{
     int i;
     for(i=0; i < N; i++)
          Z[i] = (X[i]*alpha) - Y[i];
}

void blasx_cscale(const int N, const float complex alpha, 
		  const float complex *X, float complex *Z)
{
     int i;
     for(i=0; i < N; i++)
	  Z[i] = X[i] * alpha;
}

void blasx_cmult(const int N, const float complex *X,  
		 const float complex *Y, float complex *Z)
{
     int i;
     for(i=0; i < N; i++)
	  Z[i] = X[i] * Y[i];
}

void blasx_cmultc(const int N, const float complex *X,
		  const float complex *Y, float complex *Z)
{
     int i;
     for(i=0; i < N; i++)
	  Z[i] = conj(X[i]) * Y[i];
}
