#include <complex.h>
#include <math.h>

void blasx_zmultc_mixed(const int N, const double complex *X,
                        const float complex *Y, double complex *Z)
{
     int i;
     for(i=0; i < N; i++)
          Z[i] = conj(X[i]) * (double complex) Y[i];
}

void blasx_zsxpy_mixed(const int N, const double complex alpha,
                       const double complex *X, const double complex *Y,
                       float complex *Z)
{
     int i;
     for(i=0; i < N; i++)
          Z[i] = (float complex)((X[i]*alpha) - Y[i]);     
}
