#include <stdlib.h>
#include <stdio.h>
#include <errno.h>
#include <string.h>
#include <unistd.h>
#include <libspe2.h>
#include <pthread.h>
#include <complex.h>
#include <assert.h>

#include "blasx_cell_common.h"
#include "blasx_cell.h"

DispatchDiscriptor dispatch_table[] = 
{
/*
     // Default SPE allocation: pre-optimization
     {BSC_scopy,        S_SIZE, UNUSED, S_SIZE, DMA_CHUNK_SIZE/S_SIZE, 6},
     {BSC_sscale,       S_SIZE, UNUSED, S_SIZE, DMA_CHUNK_SIZE/S_SIZE, 6},
     {BSC_saxpy,        S_SIZE, S_SIZE, S_SIZE, DMA_CHUNK_SIZE/S_SIZE, 6},
     {BSC_ssxpy,        S_SIZE, S_SIZE, S_SIZE, DMA_CHUNK_SIZE/S_SIZE, 6},
     {BSC_sdot,         S_SIZE, S_SIZE, UNUSED, DMA_CHUNK_SIZE/S_SIZE, 6},
     {BSC_ccopy,        C_SIZE, UNUSED, C_SIZE, DMA_CHUNK_SIZE/C_SIZE, 6},
     {BSC_caxpy,        C_SIZE, C_SIZE, C_SIZE, DMA_CHUNK_SIZE/C_SIZE, 6},
     {BSC_csxpy,        C_SIZE, C_SIZE, C_SIZE, DMA_CHUNK_SIZE/C_SIZE, 6},
     {BSC_cscale,       C_SIZE, UNUSED, C_SIZE, DMA_CHUNK_SIZE/C_SIZE, 6},
     {BSC_cmult,        C_SIZE, C_SIZE, C_SIZE, DMA_CHUNK_SIZE/C_SIZE, 6},
     {BSC_cmultc,       C_SIZE, C_SIZE, C_SIZE, DMA_CHUNK_SIZE/C_SIZE, 6},
     {BSC_zmultc_mixed, Z_SIZE, C_SIZE, Z_SIZE, DMA_CHUNK_SIZE/Z_SIZE, 6},
     {BSC_zsxpy_mixed,  Z_SIZE, Z_SIZE, C_SIZE, DMA_CHUNK_SIZE/Z_SIZE, 6},
     
     {BSC_zero,         UNUSED, UNUSED, S_SIZE, DMA_CHUNK_SIZE/S_SIZE, 6},
     {BSC_dcopy,        D_SIZE, UNUSED, D_SIZE, DMA_CHUNK_SIZE/D_SIZE, 6},
     {BSC_dscale,       D_SIZE, UNUSED, D_SIZE, DMA_CHUNK_SIZE/D_SIZE, 6},
     {BSC_daxpy,        D_SIZE, D_SIZE, D_SIZE, DMA_CHUNK_SIZE/D_SIZE, 6},
     {BSC_dsxpy,        D_SIZE, D_SIZE, D_SIZE, DMA_CHUNK_SIZE/D_SIZE, 6},
     {BSC_ddot,         D_SIZE, D_SIZE, UNUSED, DMA_CHUNK_SIZE/D_SIZE, 6},
     {BSC_zcopy,        Z_SIZE, UNUSED, Z_SIZE, DMA_CHUNK_SIZE/Z_SIZE, 6},
     {BSC_zaxpy,        Z_SIZE, Z_SIZE, Z_SIZE, DMA_CHUNK_SIZE/Z_SIZE, 6},
     {BSC_zsxpy,        Z_SIZE, Z_SIZE, Z_SIZE, DMA_CHUNK_SIZE/Z_SIZE, 6},
     {BSC_zscale,       Z_SIZE, UNUSED, Z_SIZE, DMA_CHUNK_SIZE/Z_SIZE, 6},
     {BSC_zmult,        Z_SIZE, Z_SIZE, Z_SIZE, DMA_CHUNK_SIZE/Z_SIZE, 6},
     {BSC_zmultc,       Z_SIZE, Z_SIZE, Z_SIZE, DMA_CHUNK_SIZE/Z_SIZE, 6}
*/
/*
     // Optimum SPE allocations based on the parameters: <htlb, opt, double, ext>
     {BSC_scopy,        S_SIZE, UNUSED, S_SIZE, DMA_CHUNK_SIZE/S_SIZE, 2},
     {BSC_sscale,       S_SIZE, UNUSED, S_SIZE, DMA_CHUNK_SIZE/S_SIZE, 6},
     {BSC_saxpy,        S_SIZE, S_SIZE, S_SIZE, DMA_CHUNK_SIZE/S_SIZE, 6},
     {BSC_ssxpy,        S_SIZE, S_SIZE, S_SIZE, DMA_CHUNK_SIZE/S_SIZE, 6},
     {BSC_sdot,         S_SIZE, S_SIZE, UNUSED, DMA_CHUNK_SIZE/S_SIZE, 6},
     {BSC_ccopy,        C_SIZE, UNUSED, C_SIZE, DMA_CHUNK_SIZE/C_SIZE, 6},
     {BSC_caxpy,        C_SIZE, C_SIZE, C_SIZE, DMA_CHUNK_SIZE/C_SIZE, 6},
     {BSC_csxpy,        C_SIZE, C_SIZE, C_SIZE, DMA_CHUNK_SIZE/C_SIZE, 6},
     {BSC_cscale,       C_SIZE, UNUSED, C_SIZE, DMA_CHUNK_SIZE/C_SIZE, 6},
     {BSC_cmult,        C_SIZE, C_SIZE, C_SIZE, DMA_CHUNK_SIZE/C_SIZE, 6},
     {BSC_cmultc,       C_SIZE, C_SIZE, C_SIZE, DMA_CHUNK_SIZE/C_SIZE, 6},
     {BSC_zmultc_mixed, Z_SIZE, C_SIZE, Z_SIZE, DMA_CHUNK_SIZE/Z_SIZE, 5},
     {BSC_zsxpy_mixed,  Z_SIZE, Z_SIZE, C_SIZE, DMA_CHUNK_SIZE/Z_SIZE, 6},
     
     {BSC_zero,         UNUSED, UNUSED, S_SIZE, DMA_CHUNK_SIZE/S_SIZE, 2},
     {BSC_dcopy,        D_SIZE, UNUSED, D_SIZE, DMA_CHUNK_SIZE/D_SIZE, 3},
     {BSC_dscale,       D_SIZE, UNUSED, D_SIZE, DMA_CHUNK_SIZE/D_SIZE, 3},
     {BSC_daxpy,        D_SIZE, D_SIZE, D_SIZE, DMA_CHUNK_SIZE/D_SIZE, 3},
     {BSC_dsxpy,        D_SIZE, D_SIZE, D_SIZE, DMA_CHUNK_SIZE/D_SIZE, 3},
     {BSC_ddot,         D_SIZE, D_SIZE, UNUSED, DMA_CHUNK_SIZE/D_SIZE, 6},
     {BSC_zcopy,        Z_SIZE, UNUSED, Z_SIZE, DMA_CHUNK_SIZE/Z_SIZE, 5},
     {BSC_zaxpy,        Z_SIZE, Z_SIZE, Z_SIZE, DMA_CHUNK_SIZE/Z_SIZE, 4},
     {BSC_zsxpy,        Z_SIZE, Z_SIZE, Z_SIZE, DMA_CHUNK_SIZE/Z_SIZE, 4},
     {BSC_zscale,       Z_SIZE, UNUSED, Z_SIZE, DMA_CHUNK_SIZE/Z_SIZE, 6},
     {BSC_zmult,        Z_SIZE, Z_SIZE, Z_SIZE, DMA_CHUNK_SIZE/Z_SIZE, 3},
     {BSC_zmultc,       Z_SIZE, Z_SIZE, Z_SIZE, DMA_CHUNK_SIZE/Z_SIZE, 3}
*/

     // Optimum SPE allocations based on the parameters: <htlb, opt, double>
     {BSC_scopy,        S_SIZE, UNUSED, S_SIZE, DMA_CHUNK_SIZE/S_SIZE, 2},
     {BSC_sscale,       S_SIZE, UNUSED, S_SIZE, DMA_CHUNK_SIZE/S_SIZE, 3},
     {BSC_saxpy,        S_SIZE, S_SIZE, S_SIZE, DMA_CHUNK_SIZE/S_SIZE, 3},
     {BSC_ssxpy,        S_SIZE, S_SIZE, S_SIZE, DMA_CHUNK_SIZE/S_SIZE, 3},
     {BSC_sdot,         S_SIZE, S_SIZE, UNUSED, DMA_CHUNK_SIZE/S_SIZE, 6},
     {BSC_ccopy,        C_SIZE, UNUSED, C_SIZE, DMA_CHUNK_SIZE/C_SIZE, 2},
     {BSC_caxpy,        C_SIZE, C_SIZE, C_SIZE, DMA_CHUNK_SIZE/C_SIZE, 2},
     {BSC_csxpy,        C_SIZE, C_SIZE, C_SIZE, DMA_CHUNK_SIZE/C_SIZE, 2},
     {BSC_cscale,       C_SIZE, UNUSED, C_SIZE, DMA_CHUNK_SIZE/C_SIZE, 3},
     {BSC_cmult,        C_SIZE, C_SIZE, C_SIZE, DMA_CHUNK_SIZE/C_SIZE, 2},
     {BSC_cmultc,       C_SIZE, C_SIZE, C_SIZE, DMA_CHUNK_SIZE/C_SIZE, 2},
     {BSC_zmultc_mixed, Z_SIZE, C_SIZE, Z_SIZE, DMA_CHUNK_SIZE/Z_SIZE, 5},
     {BSC_zsxpy_mixed,  Z_SIZE, Z_SIZE, C_SIZE, DMA_CHUNK_SIZE/Z_SIZE, 6},
     
     {BSC_zero,         UNUSED, UNUSED, S_SIZE, DMA_CHUNK_SIZE/S_SIZE, 2},
     {BSC_dcopy,        D_SIZE, UNUSED, D_SIZE, DMA_CHUNK_SIZE/D_SIZE, 3},
     {BSC_dscale,       D_SIZE, UNUSED, D_SIZE, DMA_CHUNK_SIZE/D_SIZE, 3},
     {BSC_daxpy,        D_SIZE, D_SIZE, D_SIZE, DMA_CHUNK_SIZE/D_SIZE, 3},
     {BSC_dsxpy,        D_SIZE, D_SIZE, D_SIZE, DMA_CHUNK_SIZE/D_SIZE, 3},
     {BSC_ddot,         D_SIZE, D_SIZE, UNUSED, DMA_CHUNK_SIZE/D_SIZE, 6},
     {BSC_zcopy,        Z_SIZE, UNUSED, Z_SIZE, DMA_CHUNK_SIZE/Z_SIZE, 3},
     {BSC_zaxpy,        Z_SIZE, Z_SIZE, Z_SIZE, DMA_CHUNK_SIZE/Z_SIZE, 4},
     {BSC_zsxpy,        Z_SIZE, Z_SIZE, Z_SIZE, DMA_CHUNK_SIZE/Z_SIZE, 4},
     {BSC_zscale,       Z_SIZE, UNUSED, Z_SIZE, DMA_CHUNK_SIZE/Z_SIZE, 6},
     {BSC_zmult,        Z_SIZE, Z_SIZE, Z_SIZE, DMA_CHUNK_SIZE/Z_SIZE, 3},
     {BSC_zmultc,       Z_SIZE, Z_SIZE, Z_SIZE, DMA_CHUNK_SIZE/Z_SIZE, 3}
};

extern spe_program_handle_t blasx_spu_main;

typedef struct {
     blasx_comm_t      spe_param ALIGN128;
     spe_context_ptr_t spe_context;
     pthread_t         spe_thread;
} blasx_spe_node_t;

static blasx_spe_node_t blasx_spe_nodes[MAX_SPES] ALIGN128;
static int running_spes;

static void *ppu_thread(void *arg)
{
     int rc;
     unsigned int entry;
     blasx_spe_node_t *node;
     
     node = (blasx_spe_node_t*) arg;

     do
     {
          entry = SPE_DEFAULT_ENTRY;
          rc = spe_context_run(node->spe_context, &entry, 0, 
			       &(node->spe_param), NULL, NULL);
     }
     while (rc > 0);
     pthread_exit(NULL);
}

static inline void signal_spe(int idx)
{
     unsigned int zero = 0;
     spe_in_mbox_write(blasx_spe_nodes[idx].spe_context,
		       &zero, 1, SPE_MBOX_ANY_NONBLOCKING);
}

void blasx_spes_exec(int working_spes)
{
     int i;

     for(i=0; i < running_spes && i < working_spes; i++)
	  blasx_spe_nodes[i].spe_param.spe_finished_flag = 0;

     asm volatile ("sync");
     
     for(i=0; i < running_spes && i < working_spes; i++)
	  signal_spe(i);
}

void blasx_spes_wait(int working_spes)
{
     int i;
     
     for(i=0; i < running_spes && i < working_spes; i++)
     {
	  printf("Waiting on SPE %d\n", i);
	  while(!blasx_spe_nodes[i].spe_param.spe_finished_flag)
	       ;
     }
     
     /* BE Programming Handbook, 19.6.4 */
     asm volatile ("lwsync");
}

void blasx_start_spes(int num_spes)
{
     int i, rc;
     spe_context_ptr_t spe_ctx;

     if(num_spes > MAX_SPES)
	  num_spes = MAX_SPES;
     
     for(i=0; i < num_spes; i++)
     {
	  // Create the SPE context
	  spe_ctx = spe_context_create(0, NULL);
	  if(spe_ctx == NULL)
	  {
	       fprintf(stderr, "Unable to create SPE context: %s\n", 
		       strerror(errno));
	       exit(EXIT_FAILURE);
	  }
	  
	  // Load program
	  rc = spe_program_load(spe_ctx, &blasx_spu_main);
	  if(rc)
	  {
	       fprintf(stderr, "Unable to load SPE program: %s\n", 
		       strerror(errno));
	       exit(EXIT_FAILURE);
	  }
	  
	  blasx_spe_nodes[i].spe_context = spe_ctx;

	  // Start the thread
	  rc = pthread_create(&blasx_spe_nodes[i].spe_thread, 
			      NULL, ppu_thread, (void *) &blasx_spe_nodes[i]);
	  if(rc)
	  {
	       fprintf(stderr, "Unable to start SPE thread %s\n",
                       strerror(errno));
               exit(EXIT_FAILURE);	       
	  }
     }

     running_spes = num_spes;
}

void blasx_stop_spes()
{
     int i;

     for(i=0; i < running_spes; i++)
	  blasx_spe_nodes[i].spe_param.descriptor.command = BSC_EXIT;
     
     blasx_spes_exec(running_spes);

     for (i = 0; i < running_spes; ++i) 
     {
	  pthread_join(blasx_spe_nodes[i].spe_thread, NULL);
	  spe_context_destroy(blasx_spe_nodes[i].spe_context);
     }
}

double blasx_spe_vec(int dispatch_idx, const int N, 
		     const double alpha_real, const double alpha_imag,
		     const void *X, const void *Y, void *Z, vfunc cleanup)
{
     int total_blocks, blocks_per_SPE, blocks_remainder, blocks;
     int N_remainder;
     int num_spes, max_spes;
     int i;
     double aggregator = 0;
     DispatchDiscriptor *dis = &dispatch_table[dispatch_idx];
     const void *X_ptr, *Y_ptr;
     void *Z_ptr;
     
     X_ptr = X;
     Y_ptr = Y;
     Z_ptr = Z;

     // Ensure that data pointers are aligned properly for DMA,
     // if not, then fallback to the (slow) SPU side functions.
     if( MISALIGNED(X) | MISALIGNED(Y) | MISALIGNED(Z) )
     {
	  //printf("Blasx: data misaligned, SPUs bypassed\n");
	  return cleanup(N, alpha_real, alpha_imag, X, Y, Z);
     }

     // Use the optimal number of SPEs for this task
     max_spes = (dis->max_spes > running_spes) ? running_spes : dis->max_spes;
     
     total_blocks     = N / dis->N_per_block;
     N_remainder      = N % dis->N_per_block;

     // If the total number of blocks is less than the number of running
     // SPEs, then we'll use 1 SPE per block, and one for cleanup.
     num_spes = (total_blocks < max_spes) ? total_blocks : max_spes;
     
     blocks_per_SPE   = total_blocks / num_spes;
     blocks_remainder = total_blocks % num_spes;

     // Setup the SPUs
     for(i=0; i < num_spes; i++)
     {
	  // Evenly distribute the remaining blocks
	  blocks = blocks_per_SPE;
	  if(blocks_remainder > 0)
	  {
	       blocks_remainder--;
	       blocks++;
	  }
	  
	  blasx_spe_nodes[i].spe_param.descriptor = *dis;
	  blasx_spe_nodes[i].spe_param.data.N = blocks*dis->N_per_block;

	  // Setup the data addresses
	  PTR_TO_ADDR64(X_ptr, blasx_spe_nodes[i].spe_param.data.X);
	  PTR_TO_ADDR64(Y_ptr, blasx_spe_nodes[i].spe_param.data.Y);
	  PTR_TO_ADDR64(Z_ptr, blasx_spe_nodes[i].spe_param.data.Z);	  

	  // Increment to the next SPE starting address
	  X_ptr += dis->X_type_size * blasx_spe_nodes[i].spe_param.data.N;
	  Y_ptr += dis->Y_type_size * blasx_spe_nodes[i].spe_param.data.N;
	  Z_ptr += dis->Z_type_size * blasx_spe_nodes[i].spe_param.data.N;

	  blasx_spe_nodes[i].spe_param.data.alpha_real = alpha_real;
	  blasx_spe_nodes[i].spe_param.data.alpha_imag = alpha_imag;

	  // Set the SPE to work
	  //asm volatile ("sync");
	  blasx_spe_nodes[i].spe_param.spe_finished_flag = 0;
	  signal_spe(i);
     }

     // "cleanup" the remainder
     aggregator = cleanup(N_remainder, alpha_real, alpha_imag, X_ptr, Y_ptr, Z_ptr);

     // Get the results and aggregate the return value
     for(i=0; i < num_spes; i++)
     {
          while(!blasx_spe_nodes[i].spe_param.spe_finished_flag)
               ;
	  asm volatile ("lwsync");
	  aggregator += blasx_spe_nodes[i].spe_param.ret_val;
     }

     /* BE Programming Handbook, 19.6.4 */
     asm volatile ("lwsync");

     return aggregator;
}
