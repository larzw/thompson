#ifndef _BLASX_H
#define _BLASX_H

#include <stdlib.h>
#include <inttypes.h>
#include <complex.h>

// BLASX Naming convention
// Prefix        Precision
//   s            single
//   d            double
//   l            long double
//
//   c            single complex 
//   z            double complex 
//   j            long double complex
 

void init_blasx_library();
void close_blasx_library();
void limit_blasx_spes(int n);


//-----------------------------------------------------------------------------
// miscellaneous
//-----------------------------------------------------------------------------

void blasx_zero(size_t N, void *ptr);
void blasx_cell_zero(size_t N, void *ptr);

void blasx_s2d(const int N, const float *X, double *Z);
void blasx_d2s(const int N, const double *X, float *Z);
void blasx_c2z(const int N, const float complex *X, double complex *Z);
void blasx_z2c(const int N, const double complex *X, float complex *Z); 

//-----------------------------------------------------------------------------
// mixed precision
//-----------------------------------------------------------------------------

void blasx_zmultc_mixed(const int N, const double complex *X, 
			const float complex *Y, double complex *Z);

void blasx_zsxpy_mixed(const int N, const double complex alpha,
		       const double complex *X, const double complex *Y,
		       float complex *Z);

//-----------------------------------------------------------------------------
// Cell accelerated mixed precision
//-----------------------------------------------------------------------------

void blasx_cell_zmultc_mixed(const int N, const double complex *X,
			     const float complex *Y, double complex *Z);

void blasx_cell_zsxpy_mixed(const int N, const double complex alpha,
			    const double complex *X, const double complex *Y,
			    float complex *Z);

//-----------------------------------------------------------------------------
// single
//-----------------------------------------------------------------------------
void blasx_scopy(const int N, const float *X, float *Z);

void blasx_sscale(const int N, const float alpha, const float *X,
		  float *Z);

void blasx_saxpy(const int N, const float alpha, const float *X, 
		 const float *Y, float *Z);

void blasx_ssxpy(const int N, const float alpha, const float *X,
                 const float *Y, float *Z);

double blasx_sdot(const int N, const float *X, const float *Y);

void blasx_smask(const int N, const float alpha, const float *X, 
		 float *Z, int flip, int32_t *mask);

//-----------------------------------------------------------------------------
// Cell accelerated single
//-----------------------------------------------------------------------------
void blasx_cell_scopy(const int N, const float *X, float *Z);

void blasx_cell_sscale(const int N, const float alpha, const float *X,
		       float *Z);

void blasx_cell_saxpy(const int N, const float alpha, const float *X,
		      const float *Y, float *Z);

void blasx_cell_ssxpy(const int N, const float alpha, const float *X,
		      const float *Y, float *Z);

double blasx_cell_sdot(const int N, const float *X, const float *Y);

//-----------------------------------------------------------------------------
// single complex 
//-----------------------------------------------------------------------------

void blasx_ccopy(const int N, const float complex *X, float complex *Z);

void blasx_caxpy(const int N, const float complex alpha,
		 const float complex *X, const float complex *Y,
		 float complex *Z);

void blasx_csxpy(const int N, const float complex alpha,
		 const float complex *X, const float complex *Y,
		 float complex *Z);

void blasx_cscale(const int N, const float complex alpha,
                  const float complex *X, float complex *Z);

void blasx_cmult(const int N, const float complex *X,
		 const float complex *Y, float complex *Z);

void blasx_cmultc(const int N, const float complex *X,
		  const float complex *Y, float complex *Z);

//-----------------------------------------------------------------------------
// Cell accelerated single complex 
//-----------------------------------------------------------------------------

void blasx_cell_ccopy(const int N, const float complex *X, float complex *Z);

void blasx_cell_caxpy(const int N, const float complex alpha,
		      const float complex *X, const float complex *Y,
		      float complex *Z);

void blasx_cell_csxpy(const int N, const float complex alpha,
		      const float complex *X, const float complex *Y,
		      float complex *Z);

void blasx_cell_cscale(const int N, const float complex alpha,
		       const float complex *X, float complex *Z);

void blasx_cell_cmult(const int N, const float complex *X,
		      const float complex *Y, float complex *Z);

void blasx_cell_cmultc(const int N, const float complex *X,
		       const float complex *Y, float complex *Z);

//-----------------------------------------------------------------------------
// double
//-----------------------------------------------------------------------------
void blasx_dcopy(const int N, const double *X, double *Z);

void blasx_dscale(const int N, const double alpha, const double *X,
		  double *Z);

void blasx_daxpy(const int N, const double alpha, const double *X, 
		 const double *Y, double *Z);

void blasx_dsxpy(const int N, const double alpha, const double *X,
                 const double *Y, double *Z);

double blasx_ddot(const int N, const double *X, const double *Y);

void blasx_dmask(const int N, const double alpha, const double *X, 
		 double *Z, int flip, int32_t *mask);

//-----------------------------------------------------------------------------
// cell accelerated double
//-----------------------------------------------------------------------------

void blasx_cell_dcopy(const int N, const double *X, double *Z);

void blasx_cell_dscale(const int N, const double alpha, const double *X,
		       double *Z);

void blasx_cell_daxpy(const int N, const double alpha, const double *X,
		      const double *Y, double *Z);

void blasx_cell_dsxpy(const int N, const double alpha, const double *X,
		      const double *Y, double *Z);

double blasx_cell_ddot(const int N, const double *X, const double *Y);

//-----------------------------------------------------------------------------
// double complex 
//-----------------------------------------------------------------------------

void blasx_zcopy(const int N, const double complex *X, double complex *Z);

void blasx_zaxpy(const int N, const double complex alpha,
		 const double complex *X, const double complex *Y,
		 double complex *Z);

void blasx_zsxpy(const int N, const double complex alpha,
		 const double complex *X, const double complex *Y,
		 double complex *Z);

void blasx_zscale(const int N, const double complex alpha,
                  const double complex *X, double complex *Z);

void blasx_zmult(const int N, const double complex *X,
		 const double complex *Y, double complex *Z);

void blasx_zmultc(const int N, const double complex *X,
		  const double complex *Y, double complex *Z);

//-----------------------------------------------------------------------------
// cell accelerated double complex 
//-----------------------------------------------------------------------------

void blasx_cell_zcopy(const int N, const double complex *X, double complex *Z);

void blasx_cell_zaxpy(const int N, const double complex alpha,
		      const double complex *X, const double complex *Y,
		      double complex *Z);

void blasx_cell_zsxpy(const int N, const double complex alpha,
		      const double complex *X, const double complex *Y,
		      double complex *Z);

void blasx_cell_zscale(const int N, const double complex alpha,
		       const double complex *X, double complex *Z);

void blasx_cell_zmult(const int N, const double complex *X,
		      const double complex *Y, double complex *Z);

void blasx_cell_zmultc(const int N, const double complex *X,
		       const double complex *Y, double complex *Z);


//-----------------------------------------------------------------------------
// long double 
//-----------------------------------------------------------------------------
void blasx_laxpy(const int N, const long double alpha,
		 const long double *X,
		 const int incX, long double *Y,
		 const int incY);

void blasx_lscale(const int N, const long double alpha,
		  long double *X, const int incX);


//-----------------------------------------------------------------------------
// long double complex 
//-----------------------------------------------------------------------------
void blasx_jcopy(const int N, const long double complex *X,
		 const int incX, long double complex *Y, const int incY);

void blasx_jscale(const int N, const long double complex alpha, 
		  long double complex *X, const int incX);

void blasx_jaxpy(const int N, const long double complex alpha, 
		 const long double complex *X,
		 const int incX, long double complex *Y, 
		 const int incY);

void blasx_jmultc(const int N, const long double complex *X, 
		  const int incX, long double complex *Y, const int incY);

void blasx_jpow(const int N, const long double complex alpha,
		long double complex *X, const int incX);

void blasx_jmult(const int N, const long double complex *X, const int incX,
		       long double complex *Y, const int incY);

#endif /*_BLASX_H */
