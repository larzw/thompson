#include <spu_mfcio.h>
#include <stdio.h>
#include <stdlib.h>
#include "dispatch.h"

// Memory
static char X_buf[2][DMA_CHUNK_SIZE] ALIGN128;
static char Y_buf[2][DMA_CHUNK_SIZE] ALIGN128;
static char Z_buf[2][DMA_CHUNK_SIZE] ALIGN128;

static unsigned int tags[2];

// Function dispatch
static vector_processor processor_map [] = 
{
     scopy, sscale, saxpy, ssxpy, sdot, ccopy, 
     caxpy, csxpy, cscale, cmult, cmultc, 
     zmultc_mixed, zsxpy_mixed, zero, dcopy,
     dscale, daxpy, dsxpy, ddot, zcopy, zaxpy,
     zsxpy, zscale, zmult, zmultc
};

static inline int max(int a, int b)
{
     return (a > b) ? a : b;
}

static inline int min(int a, int b)
{
     return (a < b) ? a : b;
}

unsigned int alloc_dma_tag()
{
     unsigned int tag;
     
     if((tag = mfc_tag_reserve()) == MFC_TAG_INVALID)
     {
	  printf("SPU error: unable to reserve MFC tag\n");
	  exit(EXIT_FAILURE);
     };
     
     return tag;
}

void init_dispatcher()
{
     int i;

     // Allocate tags for DMA
     for(i=0; i < 2; i++)
	  tags[i] = alloc_dma_tag();
}

static int get_operands(blasx_comm_ptr_t parms, int Nidx, unsigned int buf_idx)
{
     int N_process = min(parms->data.N-Nidx, parms->descriptor.N_per_block);
     int X_size    = parms->descriptor.X_type_size;
     int Y_size    = parms->descriptor.Y_type_size;
     addr64_t X_addr, Y_addr;
     
     // Fill the X buffer (X is always read)
     X_addr = parms->data.X + (Nidx*X_size);
     mfc_get(&X_buf[buf_idx], X_addr, X_size*N_process, 
	     tags[buf_idx], 0, 0);
     
     // Fill the Y buffer (if used)
     if(Y_size > 0)
     {
	  Y_addr = parms->data.Y + (Nidx*Y_size);
	  mfc_get(&Y_buf[buf_idx], Y_addr, Y_size*N_process, 
		  tags[buf_idx], 0, 0);
     }
     
     return N_process;
}

static void put_result(blasx_comm_ptr_t parms, int Nidx, 
		unsigned int buf_idx, int N_process)
{
     int Z_size = parms->descriptor.Z_type_size;
     addr64_t Z_addr;
     
     if(Z_size > 0)
     {
	  Z_addr = parms->data.Z + (Nidx*Z_size);
	  mfc_put(&Z_buf[buf_idx], Z_addr, Z_size*N_process, 
		  tags[buf_idx], 0, 0);
     }     
}

#ifdef DOUBLE_BUFFERED

void dispatch_processor(blasx_comm_ptr_t parms)
{
     int curr_buf, next_buf;
     int curr_N, next_N;
     int curr_idx, next_idx;
     vector_processor handler;
     double aggregator = 0.0;

     handler = processor_map[parms->descriptor.command];

     curr_idx = 0;
     curr_buf = 0;

     // Initiate the first read
     curr_N = get_operands(parms, curr_idx, curr_buf);
     next_idx = curr_idx + curr_N;
     
     // Loop through the vector, double buffering
     while(next_idx < parms->data.N)
     {
	  next_buf = curr_buf^1;
	  next_N = get_operands(parms, next_idx, next_buf);

	  // Wait for the outstanding operand DMA's 
	  mfc_write_tag_mask(1<<tags[curr_buf]);
	  mfc_read_tag_status_all();

	  // Call the data processor
	  aggregator += handler(curr_N, parms->data.alpha_real, 
				parms->data.alpha_imag, &X_buf[curr_buf],
				&Y_buf[curr_buf], &Z_buf[curr_buf]);
	  
	  // Write the output
	  put_result(parms, curr_idx, curr_buf, curr_N);
	  
	  // Increment
	  curr_idx = next_idx;
	  curr_N   = next_N;
	  curr_buf = next_buf;

	  next_idx = curr_idx + curr_N;
     }

     // Handle the last segment
     mfc_write_tag_mask(1<<tags[curr_buf]);
     mfc_read_tag_status_all();

     aggregator += handler(curr_N, parms->data.alpha_real,
			   parms->data.alpha_imag, &X_buf[curr_buf],
			   &Y_buf[curr_buf], &Z_buf[curr_buf]);

     put_result(parms, curr_idx, curr_buf, curr_N);
     
     mfc_write_tag_mask(1<<tags[curr_buf]);
     mfc_read_tag_status_all();

     // Return the value in the aggregator
     parms->ret_val = aggregator;
}

#else // !DOUBLE_BUFFERED

void dispatch_processor(blasx_comm_ptr_t parms)
{
     vector_processor handler;
     double aggregator = 0.0;
     int idx, N_process;

     handler = processor_map[parms->descriptor.command];

     idx = 0;
     while(idx < parms->data.N)
     {
	  N_process = get_operands(parms, idx, 0);

	  // Wait for the operand data
	  mfc_write_tag_mask(1<<tags[0]);
	  mfc_read_tag_status_all();
	  
	  // Call the data processor
	  aggregator += handler(N_process, parms->data.alpha_real, 
				parms->data.alpha_imag, &X_buf[0],
				&Y_buf[0], &Z_buf[0]);

	  put_result(parms, idx, 0, N_process);
	  idx += N_process;
     }

     // Wait for any outstanding put requests
     mfc_write_tag_mask(1<<tags[0]);
     mfc_read_tag_status_all();

     // Return the value in the aggregator
     parms->ret_val = aggregator;
}

#endif
