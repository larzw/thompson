#include <stdio.h>
#include <string.h>
#include <spu_intrinsics.h>

#include "../blasx_cell_common.h"
#include "processors.h"

#include "utility_macros.h"

#ifdef PROCESSORS_OPTIMIZED

//-----------------------------------------------------------------------------
// Double
//-----------------------------------------------------------------------------

double dcopy(int N,
             double alpha_real NOT_USED,
             double alpha_imag NOT_USED,
             void *X_ptr,
             void *Y_ptr       NOT_USED,
             void *Z_ptr)
{
     return scopy(N*2, 0, 0, X_ptr, Y_ptr, Z_ptr);
}

double dscale(int N,
              double alpha_real,
              double alpha_imag NOT_USED,
              void *X_ptr,
              void *Y_ptr       NOT_USED,
              void *Z_ptr)
{
     int i;
     int Nv = N/2;
     
     vector double *X = (vector double*) X_ptr;
     vector double *Z = (vector double*) Z_ptr;
     register vector double alpha = spu_splats(alpha_real);
     register vector double x0, x1, x2, x3, x4, x5, x6, x7;

     for(i=0; i < Nv; i+=8)
     {
          LOAD_X();

          Z[i]   = spu_mul(x0, alpha);
          Z[i+1] = spu_mul(x1, alpha);
          Z[i+2] = spu_mul(x2, alpha);
          Z[i+3] = spu_mul(x3, alpha);
          Z[i+4] = spu_mul(x4, alpha);
          Z[i+5] = spu_mul(x5, alpha);
          Z[i+6] = spu_mul(x6, alpha);
          Z[i+7] = spu_mul(x7, alpha);
     }

     return 0;
}

double daxpy(int N,
             double alpha_real,
             double alpha_imag NOT_USED,
             void *X_ptr,
             void *Y_ptr,
             void *Z_ptr)
{
     int i;
     int Nv = N/2;
     vector double *X = (vector double*) X_ptr;
     vector double *Y = (vector double*) Y_ptr;
     vector double *Z = (vector double*) Z_ptr;

     register vector double alpha = spu_splats((double) alpha_real);
     register vector double x0, x1, x2, x3, x4, x5, x6, x7;
     register vector double y0, y1, y2, y3, y4, y5, y6, y7;

     for(i=0; i < Nv; i+=8)
     {
          LOAD_X();
          LOAD_Y();

          Z[i]   = spu_madd(alpha, x0, y0);
          Z[i+1] = spu_madd(alpha, x1, y1);
          Z[i+2] = spu_madd(alpha, x2, y2);
          Z[i+3] = spu_madd(alpha, x3, y3);
          Z[i+4] = spu_madd(alpha, x4, y4);
          Z[i+5] = spu_madd(alpha, x5, y5);
          Z[i+6] = spu_madd(alpha, x6, y6);
          Z[i+7] = spu_madd(alpha, x7, y7);
     }

     return 0;
}


double dsxpy(int N,
             double alpha_real,
             double alpha_imag NOT_USED,
             void *X_ptr,
             void *Y_ptr,
             void *Z_ptr)
{
     int i;
     int Nv = N/2;
     vector double *X = (vector double*) X_ptr;
     vector double *Y = (vector double*) Y_ptr;
     vector double *Z = (vector double*) Z_ptr;

     register vector double alpha = spu_splats((double) alpha_real);
     register vector double x0, x1, x2, x3, x4, x5, x6, x7;
     register vector double y0, y1, y2, y3, y4, y5, y6, y7;

     for(i=0; i < Nv; i+=8)
     {
          LOAD_X();
          LOAD_Y();

          Z[i]   = spu_msub(alpha, x0, y0);
          Z[i+1] = spu_msub(alpha, x1, y1);
          Z[i+2] = spu_msub(alpha, x2, y2);
          Z[i+3] = spu_msub(alpha, x3, y3);
          Z[i+4] = spu_msub(alpha, x4, y4);
          Z[i+5] = spu_msub(alpha, x5, y5);
          Z[i+6] = spu_msub(alpha, x6, y6);
          Z[i+7] = spu_msub(alpha, x7, y7);
     }

     return 0;
}

double ddot(int N,
            double alpha_real NOT_USED,
            double alpha_imag NOT_USED,
            void *X_ptr,
            void *Y_ptr,
            void *Z_ptr       NOT_USED)
{
     int i;
     int Nv = N/2;

     vector double *X = (vector double*) X_ptr;
     vector double *Y = (vector double*) Y_ptr;
     double ac;

     register vector double x0, x1, x2, x3, x4, x5, x6, x7;
     register vector double y0, y1, y2, y3, y4, y5, y6, y7;

     register vector double dot0 = ((vector double){0.0, 0.0});
     register vector double dot1 = ((vector double){0.0, 0.0});
     register vector double dot2 = ((vector double){0.0, 0.0});
     register vector double dot3 = ((vector double){0.0, 0.0});
     register vector double dot4 = ((vector double){0.0, 0.0});
     register vector double dot5 = ((vector double){0.0, 0.0});
     register vector double dot6 = ((vector double){0.0, 0.0});
     register vector double dot7 = ((vector double){0.0, 0.0});

     for(i=0; i < Nv; i+=8)
     {
	  LOAD_X();
          LOAD_Y();

          dot0 = spu_madd(x0, y0, dot0);
          dot1 = spu_madd(x1, y1, dot1);
          dot2 = spu_madd(x2, y2, dot2);
          dot3 = spu_madd(x3, y3, dot3);
          dot4 = spu_madd(x4, y4, dot4);
          dot5 = spu_madd(x5, y5, dot5);
          dot6 = spu_madd(x6, y6, dot6);
          dot7 = spu_madd(x7, y7, dot7);
     }

     // Accumulate the results
     dot0 = spu_add(dot0, dot1);
     dot2 = spu_add(dot2, dot3);
     dot4 = spu_add(dot4, dot5);
     dot6 = spu_add(dot6, dot7);

     dot0 = spu_add(dot0, dot2);
     dot4 = spu_add(dot4, dot6);

     dot0 = spu_add(dot0, dot4);

     ac = spu_extract(dot0, 0);
     ac += spu_extract(dot0, 1);

     return ac;
}

//-----------------------------------------------------------------------------
// Double Complex
//-----------------------------------------------------------------------------

double zcopy(int N,
             double alpha_real NOT_USED,
             double alpha_imag NOT_USED,
             void *X_ptr,
             void *Y_ptr       NOT_USED,
             void *Z_ptr)
{
     return scopy(N*4, 0, 0, X_ptr, Y_ptr, Z_ptr);
}


double zaxpy(int N,
             double alpha_real,
             double alpha_imag,
             void *X_ptr,
             void *Y_ptr,
             void *Z_ptr)
{
     int i;
     vector double *X = (vector double*) X_ptr;
     vector double *Y = (vector double*) Y_ptr;
     vector double *Z = (vector double*) Z_ptr;

     register vector double ar = spu_splats((double) alpha_real);
     register vector double ai = spu_splats((double) alpha_imag);

     register vector double x0, x1, x2, x3, x4, x5, x6, x7;
     register vector double y0, y1, y2, y3, y4, y5, y6, y7;
     register vector double z0, z1, z2, z3, z4, z5, z6, z7;

     register vector double xr0, xr1, xr2, xr3;
     register vector double xi0, xi1, xi2, xi3;
     register vector double zr0, zr1, zr2, zr3;
     register vector double zi0, zi1, zi2, zi3;

     for(i=0; i < N; i+=8)
     {
          LOAD_X();
          LOAD_Y();

          EXTRACT_DOUBLE_X();

          // Z = (X*alpha)
          SCALE_X(ar, ai);
          INSERT_DOUBLE_Z();

          // Z += Y
          Z[i]   = spu_add(z0, y0);
          Z[i+1] = spu_add(z1, y1);
          Z[i+2] = spu_add(z2, y2);
          Z[i+3] = spu_add(z3, y3);
          Z[i+4] = spu_add(z4, y4);
          Z[i+5] = spu_add(z5, y5);
          Z[i+6] = spu_add(z6, y6);
          Z[i+7] = spu_add(z7, y7);
     }

     return 0;
}

double zsxpy(int N,
             double alpha_real,
             double alpha_imag,
             void *X_ptr,
             void *Y_ptr,
             void *Z_ptr)
{
     int i;
     vector double *X = (vector double*) X_ptr;
     vector double *Y = (vector double*) Y_ptr;
     vector double *Z = (vector double*) Z_ptr;

     register vector double ar = spu_splats((double) alpha_real);
     register vector double ai = spu_splats((double) alpha_imag);

     register vector double x0, x1, x2, x3, x4, x5, x6, x7;
     register vector double y0, y1, y2, y3, y4, y5, y6, y7;
     register vector double z0, z1, z2, z3, z4, z5, z6, z7;

     register vector double xr0, xr1, xr2, xr3;
     register vector double xi0, xi1, xi2, xi3;
     register vector double zr0, zr1, zr2, zr3;
     register vector double zi0, zi1, zi2, zi3;

     for(i=0; i < N; i+=8)
     {
          LOAD_X();
          LOAD_Y();

          EXTRACT_DOUBLE_X();

          // Z = (X*alpha)
          SCALE_X(ar, ai);
          INSERT_DOUBLE_Z();

          // Z += Y
          Z[i]   = spu_sub(z0, y0);
          Z[i+1] = spu_sub(z1, y1);
          Z[i+2] = spu_sub(z2, y2);
          Z[i+3] = spu_sub(z3, y3);
          Z[i+4] = spu_sub(z4, y4);
          Z[i+5] = spu_sub(z5, y5);
          Z[i+6] = spu_sub(z6, y6);
          Z[i+7] = spu_sub(z7, y7);
     }

     return 0;
}

double zscale(int N,
              double alpha_real,
              double alpha_imag,
              void *X_ptr,
              void *Y_ptr       NOT_USED,
              void *Z_ptr)
{
     int i;
     vector double *X = (vector double*) X_ptr;
     vector double *Z = (vector double*) Z_ptr;

     register vector double ar = spu_splats(alpha_real);
     register vector double ai = spu_splats(alpha_imag);

     register vector double x0, x1, x2, x3, x4, x5, x6, x7;
     register vector double z0, z1, z2, z3, z4, z5, z6, z7;

     register vector double xr0, xr1, xr2, xr3;
     register vector double xi0, xi1, xi2, xi3;
     register vector double zr0, zr1, zr2, zr3;
     register vector double zi0, zi1, zi2, zi3;

     for(i=0; i < N; i+=8)
     {
          LOAD_X();
          EXTRACT_DOUBLE_X();

          // Z = (X*alpha)
          SCALE_X(ar, ai);
          INSERT_DOUBLE_Z();

          Z[i]   = z0;
          Z[i+1] = z1;
          Z[i+2] = z2;
          Z[i+3] = z3;
          Z[i+4] = z4;
          Z[i+5] = z5;
          Z[i+6] = z6;
          Z[i+7] = z7;
     }

     return 0;
}

double zmult(int N,
             double alpha_real NOT_USED,
             double alpha_imag NOT_USED,
             void *X_ptr,
             void *Y_ptr,
             void *Z_ptr)
{
     int i;
     vector double *X = (vector double*) X_ptr;
     vector double *Y = (vector double*) Y_ptr;
     vector double *Z = (vector double*) Z_ptr;

     register vector double x0, x1, x2, x3, x4, x5, x6, x7;
     register vector double y0, y1, y2, y3, y4, y5, y6, y7;
     register vector double z0, z1, z2, z3, z4, z5, z6, z7;

     register vector double xr0, xr1, xr2, xr3;
     register vector double xi0, xi1, xi2, xi3;
     register vector double yr0, yr1, yr2, yr3;
     register vector double yi0, yi1, yi2, yi3;
     register vector double zr0, zr1, zr2, zr3;
     register vector double zi0, zi1, zi2, zi3;

     for(i=0; i < N; i+=8)
     {
          LOAD_X();
          LOAD_Y();

          EXTRACT_DOUBLE_X();
          EXTRACT_DOUBLE_Y();

          // Z = (X*Y)
          zr0 = spu_mul(xi0, (yi0));
          zr0 = spu_msub(xr0, (yr0), zr0);
          zi0 = spu_mul(xi0, (yr0));
          zi0 = spu_madd(xr0, (yi0), zi0);
          zr1 = spu_mul(xi1, (yi1));
          zr1 = spu_msub(xr1, (yr1), zr1);
          zi1 = spu_mul(xi1, (yr1));
          zi1 = spu_madd(xr1, (yi1), zi1);
          zr2 = spu_mul(xi2, (yi2));
          zr2 = spu_msub(xr2, (yr2), zr2);
          zi2 = spu_mul(xi2, (yr2));
          zi2 = spu_madd(xr2, (yi2), zi2);
          zr3 = spu_mul(xi3, (yi3));
          zr3 = spu_msub(xr3, (yr3), zr3);
          zi3 = spu_mul(xi3, (yr3));
          zi3 = spu_madd(xr3, (yi3), zi3);

          INSERT_DOUBLE_Z();

          Z[i]   = z0;
          Z[i+1] = z1;
          Z[i+2] = z2;
          Z[i+3] = z3;
          Z[i+4] = z4;
          Z[i+5] = z5;
          Z[i+6] = z6;
          Z[i+7] = z7;
     }

     return 0;
}

double zmultc(int N,
              double alpha_real NOT_USED,
              double alpha_imag NOT_USED,
              void *X_ptr,
              void *Y_ptr,
              void *Z_ptr)
{
     int i;
     vector double *X = (vector double*) X_ptr;
     vector double *Y = (vector double*) Y_ptr;
     vector double *Z = (vector double*) Z_ptr;

     register vector double x0, x1, x2, x3, x4, x5, x6, x7;
     register vector double y0, y1, y2, y3, y4, y5, y6, y7;
     register vector double z0, z1, z2, z3, z4, z5, z6, z7;

     register vector double xr0, xr1, xr2, xr3;
     register vector double xi0, xi1, xi2, xi3;
     register vector double yr0, yr1, yr2, yr3;
     register vector double yi0, yi1, yi2, yi3;
     register vector double zr0, zr1, zr2, zr3;
     register vector double zi0, zi1, zi2, zi3;

     for(i=0; i < N; i+=8)
     {
          LOAD_X();
          LOAD_Y();

          EXTRACT_DOUBLE_X();
          EXTRACT_DOUBLE_Y();
	  
	  // Z = (X*Y)
          zr0 = spu_mul(xi0, (yi0));
          zr0 = spu_madd(xr0, (yr0), zr0);
          zi0 = spu_mul(xi0, (yr0));
          zi0 = spu_msub(xr0, (yi0), zi0);
          zr1 = spu_mul(xi1, (yi1));
          zr1 = spu_madd(xr1, (yr1), zr1);
          zi1 = spu_mul(xi1, (yr1));
          zi1 = spu_msub(xr1, (yi1), zi1);
          zr2 = spu_mul(xi2, (yi2));
          zr2 = spu_madd(xr2, (yr2), zr2);
          zi2 = spu_mul(xi2, (yr2));
          zi2 = spu_msub(xr2, (yi2), zi2);
          zr3 = spu_mul(xi3, (yi3));
          zr3 = spu_madd(xr3, (yr3), zr3);
          zi3 = spu_mul(xi3, (yr3));
          zi3 = spu_msub(xr3, (yi3), zi3);

          INSERT_DOUBLE_Z();

          Z[i]   = z0;
          Z[i+1] = z1;
          Z[i+2] = z2;
          Z[i+3] = z3;
          Z[i+4] = z4;
          Z[i+5] = z5;
          Z[i+6] = z6;
          Z[i+7] = z7;
     }

     return 0;
}

#endif // PROCESSORS_OPTIMIZED
