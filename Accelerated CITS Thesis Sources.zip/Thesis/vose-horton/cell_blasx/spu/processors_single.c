#include <stdio.h>

#include "../blasx_cell_common.h"
#include "processors.h"

#ifndef PROCESSORS_OPTIMIZED

//-----------------------------------------------------------------------------
// Single
//-----------------------------------------------------------------------------

double scopy(int N, 
	     double alpha_real NOT_USED, 
	     double alpha_imag NOT_USED,
	     void *X_ptr, 
	     void *Y_ptr       NOT_USED, 
	     void *Z_ptr)
{
     int i;
     float *X = (float*) X_ptr;
     float *Z = (float*) Z_ptr;

     for(i=0; i < N; i++)
          Z[i] = X[i];

     return 0;
}

double sscale(int N, 
	      double alpha_real, 
	      double alpha_imag NOT_USED,
	      void *X_ptr, 
	      void *Y_ptr       NOT_USED, 
	      void *Z_ptr)
{
     int i;
     float *X = (float*) X_ptr;
     float *Z = (float*) Z_ptr;
     float alpha = (float) alpha_real;

     for(i=0; i < N; i++)
	  Z[i] = X[i] * (alpha);
     
     return 0;
}

double saxpy(int N, 
	     double alpha_real, 
	     double alpha_imag NOT_USED, 
	     void *X_ptr, 
	     void *Y_ptr, 
	     void *Z_ptr)
{
     int i;
     float *X = (float*) X_ptr;
     float *Y = (float*) Y_ptr;
     float *Z = (float*) Z_ptr;
     float alpha = (float) alpha_real;
     
     for(i=0; i < N; i++)
	  Z[i] = (X[i]*alpha) + Y[i];

     return 0;
}


double ssxpy(int N, 
	     double alpha_real, 
	     double alpha_imag NOT_USED,
	     void *X_ptr, 
	     void *Y_ptr, 
	     void *Z_ptr)
{
     int i;
     float *X = (float*) X_ptr;
     float *Y = (float*) Y_ptr;
     float *Z = (float*) Z_ptr;
     float alpha = (float) alpha_real;

     for(i=0; i < N; i++)
          Z[i] = (X[i]*alpha) - Y[i];

     return 0;
}

double sdot(int N, 
	    double alpha_real NOT_USED, 
	    double alpha_imag NOT_USED,
	    void *X_ptr, 
	    void *Y_ptr, 
	    void *Z_ptr       NOT_USED)
{
     float *X = (float*) X_ptr;
     float *Y = (float*) Y_ptr;
     double dot=0;
     int i;
     for(i=0; i < N; i++)
          dot += ((double)X[i] * (double)Y[i]);
     
     return dot;
}

//-----------------------------------------------------------------------------
// Single Complex
//-----------------------------------------------------------------------------

double ccopy(int N, 
	     double alpha_real NOT_USED,
	     double alpha_imag NOT_USED,
	     void *X_ptr, 
	     void *Y_ptr       NOT_USED, 
	     void *Z_ptr)
{
     float *X = (float*) X_ptr;
     float *Z = (float*) Z_ptr;
     int i;
     
     for(i=0; i < N*2; i++)
          Z[i] = X[i];

     return 0;
}

double caxpy(int N, 
	     double alpha_real, 
	     double alpha_imag,
	     void *X_ptr, 
	     void *Y_ptr, 
	     void *Z_ptr)
{
     float *X = (float*) X_ptr;
     float *Y = (float*) Y_ptr;
     float *Z = (float*) Z_ptr;
     float a_real = (float)alpha_real;
     float a_imag = (float)alpha_imag;

     int i;
     for(i=0; i < N*2; i += 2)
     {
	  // (X*alpha)
	  Z[i]   = (X[i] * a_real) - (X[i+1] * a_imag);
	  Z[i+1] = (X[i] * a_imag) + (X[i+1] * a_real);

	  // + Y
	  Z[i]   += Y[i];
	  Z[i+1] += Y[i+1];
     }

     return 0;
}

double csxpy(int N, 
	     double alpha_real, 
	     double alpha_imag,
	     void *X_ptr, 
	     void *Y_ptr,
	     void *Z_ptr)
{
     float *X = (float*) X_ptr;
     float *Y = (float*) Y_ptr;
     float *Z = (float*) Z_ptr;
     float a_real = (float)alpha_real;
     float a_imag = (float)alpha_imag;

     int i;
     for(i=0; i < N*2; i += 2)
     {
          // (X*alpha)
          Z[i]   = (X[i] * a_real) - (X[i+1] * a_imag);
          Z[i+1] = (X[i] * a_imag) + (X[i+1] * a_real);

          // - Y
          Z[i]   -= Y[i];
          Z[i+1] -= Y[i+1];
     }

     return 0;
}

double cscale(int N, 
	      double alpha_real, 
	      double alpha_imag,
	      void *X_ptr, 
	      void *Y_ptr       NOT_USED,
	      void *Z_ptr)
{

     float *X = (float*) X_ptr;
     float *Z = (float*) Z_ptr;
     float a_real = (float)alpha_real;
     float a_imag = (float)alpha_imag;
     int i;

     for(i=0; i < N*2; i += 2)
     {
          // (X*alpha)
          Z[i]   = (X[i] * a_real) - (X[i+1] * a_imag);
          Z[i+1] = (X[i] * a_imag) + (X[i+1] * a_real);
     }

     return 0;
}

double cmult(int N, 
	     double alpha_real NOT_USED,
	     double alpha_imag NOT_USED,
	     void *X_ptr, 
	     void *Y_ptr, 
	     void *Z_ptr)
{
     float *X = (float*) X_ptr;
     float *Y = (float*) Y_ptr;
     float *Z = (float*) Z_ptr;

     int i;
     for(i=0; i < N*2; i += 2)
     {
          // (X*Y)
          Z[i]   = (X[i] * Y[i]) - (X[i+1] * Y[i+1]);
          Z[i+1] = (X[i] * Y[i+1]) + (X[i+1] * Y[i]);
     }

     return 0;
}

double cmultc(int N, 
	      double alpha_real NOT_USED, 
	      double alpha_imag NOT_USED,
	      void *X_ptr, 
	      void *Y_ptr, 
	      void *Z_ptr)
{
     float *X = (float*) X_ptr;
     float *Y = (float*) Y_ptr;
     float *Z = (float*) Z_ptr;

     int i;
     for(i=0; i < N*2; i += 2)
     {
          // (X*Y)
          Z[i]   = (X[i] * Y[i]) + (X[i+1] * Y[i+1]);
          Z[i+1] = (X[i] * Y[i+1]) - (X[i+1] * Y[i]);
     }

     return 0;
}

#endif // !PROCESSORS_OPTIMIZED

