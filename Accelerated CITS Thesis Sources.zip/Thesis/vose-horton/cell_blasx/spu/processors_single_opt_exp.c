#include <stdio.h>
#include <string.h>
#include <spu_intrinsics.h>

#include "../blasx_cell_common.h"
#include "processors.h"

#include "utility_macros.h"

#ifdef PROCESSORS_OPTIMIZED
#ifdef SINGLE_EXP

//-----------------------------------------------------------------------------
// Single
//-----------------------------------------------------------------------------

double scopy(int N, 
	     double alpha_real NOT_USED, 
	     double alpha_imag NOT_USED,
	     void *X_ptr, 
	     void *Y_ptr       NOT_USED, 
	     void *Z_ptr)
{
     int i;
     int Nv = N/4;
     vector float *X = (vector float*) X_ptr;
     vector float *Z = (vector float*) Z_ptr;
     register vector float x0, x1, x2, x3, x4, x5, x6, x7;
     
     for(i=0; i < Nv; i+=8)
     {
          LOAD_X();
	  
          Z[i]   = x0;
          Z[i+1] = x1;
          Z[i+2] = x2;
          Z[i+3] = x3;
          Z[i+4] = x4;
          Z[i+5] = x5;
          Z[i+6] = x6;
          Z[i+7] = x7;
     }

     return 0;
}

double sscale(int N, 
	      double alpha_real, 
	      double alpha_imag NOT_USED,
	      void *X_ptr, 
	      void *Y_ptr       NOT_USED, 
	      void *Z_ptr)
{
     int i;
     int Nv = N/4;
     
     vector float *X = (vector float*) X_ptr;
     vector float *Z = (vector float*) Z_ptr;
     register vector double alpha = spu_splats(alpha_real);

     register vector float   x0,  x1,  x2,  x3;
     register vector float   t0,  t1,  t2,  t3,  t4,  t5,  t6,  t7;
     register vector double dx0, dx1, dx2, dx3, dx4, dx5, dx6, dx7;
     register vector double dz0, dz1, dz2, dz3, dz4, dz5, dz6, dz7;

     for(i=0; i < Nv; i+=4)
     {
	  LOAD_F2D_X();

	  dz0 = spu_mul(dx0, alpha);
	  dz1 = spu_mul(dx1, alpha);
	  dz2 = spu_mul(dx2, alpha);
	  dz3 = spu_mul(dx3, alpha);
	  dz4 = spu_mul(dx4, alpha);
	  dz5 = spu_mul(dx5, alpha);
	  dz6 = spu_mul(dx6, alpha);
	  dz7 = spu_mul(dx7, alpha);

	  STORE_DZ();
     }

     return 0;
}

double saxpy(int N, 
	     double alpha_real, 
	     double alpha_imag NOT_USED, 
	     void *X_ptr, 
	     void *Y_ptr, 
	     void *Z_ptr)
{
     int i;
     int Nv = N/4;
     vector float *X = (vector float*) X_ptr;
     vector float *Y = (vector float*) Y_ptr;
     vector float *Z = (vector float*) Z_ptr;

     register vector double alpha = spu_splats(alpha_real);
     register vector float x0, x1, x2, x3;
     register vector float y0, y1, y2, y3;
     register vector float t0, t1, t2, t3, t4, t5, t6, t7;

     register vector double dx0, dx1, dx2, dx3, dx4, dx5, dx6, dx7;
     register vector double dy0, dy1, dy2, dy3, dy4, dy5, dy6, dy7;     
     register vector double dz0, dz1, dz2, dz3, dz4, dz5, dz6, dz7;

     for(i=0; i < Nv; i+=4)
     {
	  LOAD_F2D_X();
	  LOAD_F2D_Y();

	  dz0 = spu_madd(alpha, dx0, dy0);
	  dz1 = spu_madd(alpha, dx1, dy1);
	  dz2 = spu_madd(alpha, dx2, dy2);
	  dz3 = spu_madd(alpha, dx3, dy3);
	  dz4 = spu_madd(alpha, dx4, dy4);
	  dz5 = spu_madd(alpha, dx5, dy5);
	  dz6 = spu_madd(alpha, dx6, dy6);
	  dz7 = spu_madd(alpha, dx7, dy7);

	  STORE_DZ();
     }

     return 0;
}


double ssxpy(int N, 
	     double alpha_real, 
	     double alpha_imag NOT_USED,
	     void *X_ptr, 
	     void *Y_ptr, 
	     void *Z_ptr)
{
     int i;
     int Nv = N/4;
     vector float *X = (vector float*) X_ptr;
     vector float *Y = (vector float*) Y_ptr;
     vector float *Z = (vector float*) Z_ptr;

     register vector double alpha = spu_splats(alpha_real);
     register vector float x0, x1, x2, x3;
     register vector float y0, y1, y2, y3;
     register vector float t0, t1, t2, t3, t4, t5, t6, t7;

     register vector double dx0, dx1, dx2, dx3, dx4, dx5, dx6, dx7;
     register vector double dy0, dy1, dy2, dy3, dy4, dy5, dy6, dy7;     
     register vector double dz0, dz1, dz2, dz3, dz4, dz5, dz6, dz7;

     for(i=0; i < Nv; i+=4)
     {
	  LOAD_F2D_X();
	  LOAD_F2D_Y();

	  dz0 = spu_msub(alpha, dx0, dy0);
	  dz1 = spu_msub(alpha, dx1, dy1);
	  dz2 = spu_msub(alpha, dx2, dy2);
	  dz3 = spu_msub(alpha, dx3, dy3);
	  dz4 = spu_msub(alpha, dx4, dy4);
	  dz5 = spu_msub(alpha, dx5, dy5);
	  dz6 = spu_msub(alpha, dx6, dy6);
	  dz7 = spu_msub(alpha, dx7, dy7);

	  STORE_DZ();
     }

     return 0;
}

double sdot(int N, 
	    double alpha_real NOT_USED, 
	    double alpha_imag NOT_USED,
	    void *X_ptr, 
	    void *Y_ptr, 
	    void *Z_ptr       NOT_USED)
{
     int i;
     int Nv = N/4;

     vector float *X = (vector float*) X_ptr;
     vector float *Y = (vector float*) Y_ptr;
     double ac;

     register vector float x0, x1, x2, x3;
     register vector float y0, y1, y2, y3;
     
     register vector double dx0, dx1, dx2, dx3, dx4, dx5, dx6, dx7;
     register vector double dy0, dy1, dy2, dy3, dy4, dy5, dy6, dy7;

     register vector double dot0 = ((vector double){0.0, 0.0});
     register vector double dot1 = ((vector double){0.0, 0.0});
     register vector double dot2 = ((vector double){0.0, 0.0});
     register vector double dot3 = ((vector double){0.0, 0.0});
     register vector double dot4 = ((vector double){0.0, 0.0});
     register vector double dot5 = ((vector double){0.0, 0.0});
     register vector double dot6 = ((vector double){0.0, 0.0});
     register vector double dot7 = ((vector double){0.0, 0.0});

     for(i=0; i < Nv; i+=4)
     {
          LOAD_F2D_X();
          LOAD_F2D_Y();

	  dot0 = spu_madd(dx0, dy0, dot0);
          dot1 = spu_madd(dx1, dy1, dot1);
          dot2 = spu_madd(dx2, dy2, dot2);
          dot3 = spu_madd(dx3, dy3, dot3);
          dot4 = spu_madd(dx4, dy4, dot4);
          dot5 = spu_madd(dx5, dy5, dot5);
          dot6 = spu_madd(dx6, dy6, dot6);
          dot7 = spu_madd(dx7, dy7, dot7);
     }

     // Accumulate the results
     dot0 = spu_add(dot0, dot1);
     dot2 = spu_add(dot2, dot3);
     dot4 = spu_add(dot4, dot5);
     dot6 = spu_add(dot6, dot7);

     dot0 = spu_add(dot0, dot2);
     dot4 = spu_add(dot4, dot6);
     
     dot0 = spu_add(dot0, dot4);

     ac = spu_extract(dot0, 0);
     ac += spu_extract(dot0, 1);

     return ac;
}

//-----------------------------------------------------------------------------
// Single Complex
//-----------------------------------------------------------------------------

double ccopy(int N, 
	     double alpha_real NOT_USED,
	     double alpha_imag NOT_USED,
	     void *X_ptr, 
	     void *Y_ptr       NOT_USED, 
	     void *Z_ptr)
{
     int i;
     int Nv = N/2;
     vector float *X = (vector float*) X_ptr;
     vector float *Z = (vector float*) Z_ptr;
     register vector float x0, x1, x2, x3, x4, x5, x6, x7;

     for(i=0; i < Nv; i+=8)
     {
          LOAD_X();

          Z[i]   = x0;
          Z[i+1] = x1;
          Z[i+2] = x2;
          Z[i+3] = x3;
          Z[i+4] = x4;
          Z[i+5] = x5;
          Z[i+6] = x6;
          Z[i+7] = x7;
     }

     return 0;
}

double caxpy(int N, 
	     double alpha_real, 
	     double alpha_imag,
	     void *X_ptr, 
	     void *Y_ptr, 
	     void *Z_ptr)
{
     int i;
     int Nv = N/2;
     vector float *X = (vector float*) X_ptr;
     vector float *Y = (vector float*) Y_ptr;
     vector float *Z = (vector float*) Z_ptr;

     register vector double ar = spu_splats(alpha_real);
     register vector double ai = spu_splats(alpha_imag);

     register vector float x0, x1, x2, x3;
     register vector float y0, y1, y2, y3;
     register vector float t0, t1, t2, t3, t4, t5, t6, t7;
     
     register vector double xr0, xr1, xr2, xr3;
     register vector double xi0, xi1, xi2, xi3;

     register vector double yr0, yr1, yr2, yr3;
     register vector double yi0, yi1, yi2, yi3;

     register vector double zr0, zr1, zr2, zr3;
     register vector double zi0, zi1, zi2, zi3;

     for(i=0; i < Nv; i+=4)
     {
	  LOAD_F2D_X_CPARTS();
	  LOAD_F2D_Y_CPARTS();
	  
	  SCALE_X(ar, ai);
	  
	  zr0 = spu_add(zr0, yr0);
	  zr1 = spu_add(zr1, yr1);
	  zr2 = spu_add(zr2, yr2);
	  zr3 = spu_add(zr3, yr3);

	  zi0 = spu_add(zi0, yi0);
	  zi1 = spu_add(zi1, yi1);
	  zi2 = spu_add(zi2, yi2);
	  zi3 = spu_add(zi3, yi3);

	  STORE_DOUBLE_COMLPEX_Z();	  
     }

     return 0;
}

double csxpy(int N, 
	     double alpha_real, 
	     double alpha_imag,
	     void *X_ptr, 
	     void *Y_ptr       NOT_USED,
	     void *Z_ptr)
{
     int i;
     int Nv = N/2;
     vector float *X = (vector float*) X_ptr;
     vector float *Y = (vector float*) Y_ptr;
     vector float *Z = (vector float*) Z_ptr;

     register vector double ar = spu_splats(alpha_real);
     register vector double ai = spu_splats(alpha_imag);

     register vector float x0, x1, x2, x3;
     register vector float y0, y1, y2, y3;
     register vector float t0, t1, t2, t3, t4, t5, t6, t7;
     
     register vector double xr0, xr1, xr2, xr3;
     register vector double xi0, xi1, xi2, xi3;

     register vector double yr0, yr1, yr2, yr3;
     register vector double yi0, yi1, yi2, yi3;

     register vector double zr0, zr1, zr2, zr3;
     register vector double zi0, zi1, zi2, zi3;

     for(i=0; i < Nv; i+=4)
     {
	  LOAD_F2D_X_CPARTS();
	  LOAD_F2D_Y_CPARTS();
	  
	  SCALE_X(ar, ai);
	  
	  zr0 = spu_sub(zr0, yr0);
	  zr1 = spu_sub(zr1, yr1);
	  zr2 = spu_sub(zr2, yr2);
	  zr3 = spu_sub(zr3, yr3);

	  zi0 = spu_sub(zi0, yi0);
	  zi1 = spu_sub(zi1, yi1);
	  zi2 = spu_sub(zi2, yi2);
	  zi3 = spu_sub(zi3, yi3);

	  STORE_DOUBLE_COMLPEX_Z();	  
     }

     return 0;
}

double cscale(int N, 
	      double alpha_real, 
	      double alpha_imag,
	      void *X_ptr, 
	      void *Y_ptr       NOT_USED,
	      void *Z_ptr)
{
     int i;
     int Nv = N/2;
     vector float *X = (vector float*) X_ptr;
     vector float *Z = (vector float*) Z_ptr;

     register vector double ar = spu_splats(alpha_real);
     register vector double ai = spu_splats(alpha_imag);

     register vector float x0, x1, x2, x3;
     register vector float t0, t1, t2, t3, t4, t5, t6, t7;
     
     register vector double xr0, xr1, xr2, xr3;
     register vector double xi0, xi1, xi2, xi3;
     register vector double zr0, zr1, zr2, zr3;
     register vector double zi0, zi1, zi2, zi3;

     for(i=0; i < Nv; i+=4)
     {
	  LOAD_F2D_X_CPARTS();
	  SCALE_X(ar, ai);
	  STORE_DOUBLE_COMLPEX_Z();	  
     }

     return 0;
}

double cmult(int N, 
	     double alpha_real NOT_USED,
	     double alpha_imag NOT_USED,
	     void *X_ptr, 
	     void *Y_ptr, 
	     void *Z_ptr)
{
     int i;
     int Nv = N/2;
     vector float *X = (vector float*) X_ptr;
     vector float *Y = (vector float*) Y_ptr;
     vector float *Z = (vector float*) Z_ptr;

     register vector float x0, x1, x2, x3;
     register vector float y0, y1, y2, y3;
     register vector float t0, t1, t2, t3, t4, t5, t6, t7;

     register vector double xr0, xr1, xr2, xr3;
     register vector double xi0, xi1, xi2, xi3;

     register vector double yr0, yr1, yr2, yr3;
     register vector double yi0, yi1, yi2, yi3;

     register vector double zr0, zr1, zr2, zr3;
     register vector double zi0, zi1, zi2, zi3;

     for(i=0; i < Nv; i+=4)
     {
          LOAD_F2D_X_CPARTS();
          LOAD_F2D_Y_CPARTS();

	  // Z = (X*Y)
          zr0 = spu_mul(xi0, (yi0));
          zr0 = spu_msub(xr0, (yr0), zr0);
          zi0 = spu_mul(xi0, (yr0));
          zi0 = spu_madd(xr0, (yi0), zi0);
          zr1 = spu_mul(xi1, (yi1));
          zr1 = spu_msub(xr1, (yr1), zr1);
          zi1 = spu_mul(xi1, (yr1));
          zi1 = spu_madd(xr1, (yi1), zi1);
          zr2 = spu_mul(xi2, (yi2));
          zr2 = spu_msub(xr2, (yr2), zr2);
          zi2 = spu_mul(xi2, (yr2));
          zi2 = spu_madd(xr2, (yi2), zi2);
          zr3 = spu_mul(xi3, (yi3));
          zr3 = spu_msub(xr3, (yr3), zr3);
          zi3 = spu_mul(xi3, (yr3));
          zi3 = spu_madd(xr3, (yi3), zi3);

          STORE_DOUBLE_COMLPEX_Z();
     }
     
     return 0;
}

double cmultc(int N, 
	      double alpha_real NOT_USED, 
	      double alpha_imag NOT_USED,
	      void *X_ptr, 
	      void *Y_ptr, 
	      void *Z_ptr)
{
     int i;
     int Nv = N/2;
     vector float *X = (vector float*) X_ptr;
     vector float *Y = (vector float*) Y_ptr;
     vector float *Z = (vector float*) Z_ptr;

     register vector float x0, x1, x2, x3;
     register vector float y0, y1, y2, y3;
     register vector float t0, t1, t2, t3, t4, t5, t6, t7;

     register vector double xr0, xr1, xr2, xr3;
     register vector double xi0, xi1, xi2, xi3;

     register vector double yr0, yr1, yr2, yr3;
     register vector double yi0, yi1, yi2, yi3;

     register vector double zr0, zr1, zr2, zr3;
     register vector double zi0, zi1, zi2, zi3;

     for(i=0; i < Nv; i+=4)
     {
          LOAD_F2D_X_CPARTS();
          LOAD_F2D_Y_CPARTS();

          // Z = (X*Y)
          zr0 = spu_mul(xi0, (yi0));
          zr0 = spu_madd(xr0, (yr0), zr0);
          zi0 = spu_mul(xi0, (yr0));
          zi0 = spu_msub(xr0, (yi0), zi0);
          zr1 = spu_mul(xi1, (yi1));
          zr1 = spu_madd(xr1, (yr1), zr1);
          zi1 = spu_mul(xi1, (yr1));
          zi1 = spu_msub(xr1, (yi1), zi1);
          zr2 = spu_mul(xi2, (yi2));
          zr2 = spu_madd(xr2, (yr2), zr2);
          zi2 = spu_mul(xi2, (yr2));
          zi2 = spu_msub(xr2, (yi2), zi2);
          zr3 = spu_mul(xi3, (yi3));
          zr3 = spu_madd(xr3, (yr3), zr3);
          zi3 = spu_mul(xi3, (yr3));
          zi3 = spu_msub(xr3, (yi3), zi3);

          STORE_DOUBLE_COMLPEX_Z();
     }
     
     return 0;
}

#endif // SINGLE_EXP
#endif // PROCESSORS_OPTIMIZED
