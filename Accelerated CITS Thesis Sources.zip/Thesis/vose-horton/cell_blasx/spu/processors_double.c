#include <stdio.h>

#include "../blasx_cell_common.h"
#include "processors.h"

#ifndef PROCESSORS_OPTIMIZED

//-----------------------------------------------------------------------------
// Double
//-----------------------------------------------------------------------------

double dcopy(int N, 
	     double alpha_real NOT_USED, 
	     double alpha_imag NOT_USED,
             void *X_ptr, 
	     void *Y_ptr       NOT_USED, 
	     void *Z_ptr)
{
     int i;
     double *X = (double*) X_ptr;
     double *Z = (double*) Z_ptr;
     
     for(i=0; i < N; i++)
          Z[i] = X[i];
     
     return 0;
}

double dscale(int N, 
	      double alpha_real, 
	      double alpha_imag NOT_USED,
              void *X_ptr, 
	      void *Y_ptr       NOT_USED, 
	      void *Z_ptr)
{
     int i;
     double *X = (double*) X_ptr;
     double *Z = (double*) Z_ptr;
     
     for(i=0; i < N; i++)
          Z[i] = X[i] * (alpha_real);

     return 0;
}

double daxpy(int N, 
	     double alpha_real, 
	     double alpha_imag NOT_USED,
             void *X_ptr, 
	     void *Y_ptr, 
	     void *Z_ptr)
{
     int i;
     double *X = (double*) X_ptr;
     double *Y = (double*) Y_ptr;
     double *Z = (double*) Z_ptr;

     for(i=0; i < N; i++)
          Z[i] = (X[i]*alpha_real) + Y[i];

     return 0;
}


double dsxpy(int N, 
	     double alpha_real,
	     double alpha_imag NOT_USED,
             void *X_ptr, 
	     void *Y_ptr, 
	     void *Z_ptr)
{
     int i;
     double *X = (double*) X_ptr;
     double *Y = (double*) Y_ptr;
     double *Z = (double*) Z_ptr;

     for(i=0; i < N; i++)
          Z[i] = (X[i]*alpha_real) - Y[i];

     return 0;
}

double ddot(int N, 
	    double alpha_real NOT_USED, 
	    double alpha_imag NOT_USED,
            void *X_ptr, 
	    void *Y_ptr, 
	    void *Z_ptr       NOT_USED)
{
     double *X = (double*) X_ptr;
     double *Y = (double*) Y_ptr;
     double dot=0;

     int i;
     for(i=0; i < N; i++)
          dot += (X[i] * Y[i]);

     return dot;
}

//-----------------------------------------------------------------------------
// Double Complex
//-----------------------------------------------------------------------------

double zcopy(int N, 
	     double alpha_real NOT_USED, 
	     double alpha_imag NOT_USED,
             void *X_ptr, 
	     void *Y_ptr       NOT_USED, 
	     void *Z_ptr)
{
     double *X = (double*) X_ptr;
     double *Z = (double*) Z_ptr;
     int i;
     
     for(i=0; i < N*2; i++)
	  Z[i] = X[i];
     
     return 0;
}

double zaxpy(int N, 
	     double alpha_real, 
	     double alpha_imag,
             void *X_ptr, 
	     void *Y_ptr, 
	     void *Z_ptr)
{
     double *X = (double*) X_ptr;
     double *Y = (double*) Y_ptr;
     double *Z = (double*) Z_ptr;

     int i;
     for(i=0; i < N*2; i += 2)
     {
          // (X*alpha)
          Z[i]   = (X[i] * alpha_real) - (X[i+1] * alpha_imag);
          Z[i+1] = (X[i] * alpha_imag) + (X[i+1] * alpha_real);

          // + Y
          Z[i]   += Y[i];
          Z[i+1] += Y[i+1];
     }

     return 0;
}

double zsxpy(int N, 
	     double alpha_real, 
	     double alpha_imag,
             void *X_ptr, 
	     void *Y_ptr, 
	     void *Z_ptr)
{
     double *X = (double*) X_ptr;
     double *Y = (double*) Y_ptr;
     double *Z = (double*) Z_ptr;

     int i;
     for(i=0; i < N*2; i += 2)
     {
          // (X*alpha)
          Z[i]   = (X[i] * alpha_real) - (X[i+1] * alpha_imag);
          Z[i+1] = (X[i] * alpha_imag) + (X[i+1] * alpha_real);

          // - Y
          Z[i]   -= Y[i];
          Z[i+1] -= Y[i+1];
     }

     return 0;
}

double zscale(int N,
	      double alpha_real,
	      double alpha_imag,
              void *X_ptr,
	      void *Y_ptr       NOT_USED, 
	      void *Z_ptr)
{
     double *X = (double*) X_ptr;
     double *Z = (double*) Z_ptr;
     int i;

     for(i=0; i < N*2; i += 2)
     {
          // (X*alpha)
          Z[i]   = (X[i] * alpha_real) - (X[i+1] * alpha_imag);
          Z[i+1] = (X[i] * alpha_imag) + (X[i+1] * alpha_real);
     }

     return 0;
}

double zmult(int N, 
	     double alpha_real NOT_USED, 
	     double alpha_imag NOT_USED,
             void *X_ptr, 
	     void *Y_ptr, 
	     void *Z_ptr)
{
     double *X = (double*) X_ptr;
     double *Y = (double*) Y_ptr;
     double *Z = (double*) Z_ptr;

     int i;
     for(i=0; i < N*2; i += 2)
     {
          // (X*Y)
          Z[i]   = (X[i] * Y[i]) - (X[i+1] * Y[i+1]);
          Z[i+1] = (X[i] * Y[i+1]) + (X[i+1] * Y[i]);
     }

     return 0;
}

double zmultc(int N, 
	      double alpha_real NOT_USED, 
	      double alpha_imag NOT_USED,
              void *X_ptr, 
	      void *Y_ptr, 
	      void *Z_ptr)
{
     double *X = (double*) X_ptr;
     double *Y = (double*) Y_ptr;
     double *Z = (double*) Z_ptr;

     int i;
     for(i=0; i < N*2; i += 2)
     {
          // (X*Y)
          Z[i]   = (X[i] * Y[i]) + (X[i+1] * Y[i+1]);
          Z[i+1] = (X[i] * Y[i+1]) - (X[i+1] * Y[i]);
     }

     return 0;
}

#endif // !PROCESSORS_OPTIMIZED

