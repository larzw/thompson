#include <spu_intrinsics.h>
#include <stdio.h>
#include <spu_mfcio.h>

#include "../blasx_cell_common.h"
#include "dispatch.h"

int main(addr64_t spu_id NOT_USED, addr64_t parm_ptr)
{
     blasx_comm_t params;
     int param_tag;
     
     //spu_writech(MFC_WrTagMask, -1);
     init_dispatcher();
     
     param_tag = alloc_dma_tag();

     for (;;)
     {
	  spu_read_in_mbox();
	  
	  // Obtain the comm block
	  mfc_get(&params, parm_ptr, sizeof(params), param_tag, 0, 0);
	  mfc_write_tag_mask(1<<param_tag);
          mfc_read_tag_status_all();

	  if(params.descriptor.command < BSC_META_OPS)
	  {
	       dispatch_processor(&params);
	  }
	  else
	  {
	       switch(params.descriptor.command)
	       {
	       case BSC_PING:
		    printf("PONG!\n");
		    break;
		    
	       case BSC_EXIT:
		    return 0;
	       }
	  }
	  
	  params.spe_finished_flag = 1;
	  
	  mfc_put(&params, parm_ptr, sizeof(params), param_tag, 0, 0);
          mfc_write_tag_mask(1<<param_tag);
          mfc_read_tag_status_all();
     }
}
