#ifndef _DISPATCH_H_
#define _DISPATCH_H_

#include "../blasx_cell_common.h"
#include "processors.h"

typedef double (*vector_processor)(int N, double alpha_real,
				   double alpha_imag, void *X,
				   void *Y, void *Z);

void init_dispatcher();
unsigned int alloc_dma_tag();
void dispatch_processor(blasx_comm_ptr_t parms);

#endif // _DISPATCH_H_
