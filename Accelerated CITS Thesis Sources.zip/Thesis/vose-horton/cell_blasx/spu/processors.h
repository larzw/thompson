#ifndef _PROCESSORS_H_
#define _PROCESSORS_H_

//-----------------------------------------------------------------------------
// Single 
//-----------------------------------------------------------------------------

double scopy(int N, double alpha_real, double alpha_imag,
	     void *X_ptr, void *Y_ptr, void *Z_ptr);

double sscale(int N, double alpha_real, double alpha_imag,
	      void *X_ptr, void *Y_ptr, void *Z_ptr);

double saxpy(int N, double alpha_real, double alpha_imag,
	     void *X_ptr, void *Y_ptr, void *Z_ptr);

double ssxpy(int N, double alpha_real, double alpha_imag,
	     void *X_ptr, void *Y_ptr, void *Z_ptr);

double sdot(int N, double alpha_real, double alpha_imag,
	    void *X_ptr, void *Y_ptr, void *Z_ptr);

//-----------------------------------------------------------------------------
// Single Complex
//-----------------------------------------------------------------------------

double ccopy(int N, double alpha_real, double alpha_imag,
	     void *X_ptr, void *Y_ptr, void *Z_ptr);

double caxpy(int N, double alpha_real, double alpha_imag,
	     void *X_ptr, void *Y_ptr, void *Z_ptr);

double csxpy(int N, double alpha_real, double alpha_imag,
	     void *X_ptr, void *Y_ptr, void *Z_ptr);

double cscale(int N, double alpha_real, double alpha_imag,
	      void *X_ptr, void *Y_ptr, void *Z_ptr);

double cmult(int N, double alpha_real, double alpha_imag,
	     void *X_ptr, void *Y_ptr, void *Z_ptr);

double cmultc(int N, double alpha_real, double alpha_imag,
	      void *X_ptr, void *Y_ptr, void *Z_ptr);

//-----------------------------------------------------------------------------
// Mixed 
//-----------------------------------------------------------------------------

double zmultc_mixed(int N, double alpha_real, double alpha_imag,
		    void *X_ptr, void *Y_ptr, void *Z_ptr);

double zsxpy_mixed(int N, double alpha_real, double alpha_imag,
		   void *X_ptr, void *Y_ptr, void *Z_ptr);

double zero(int N, double alpha_real, double alpha_imag,
	    void *X_ptr, void *Y_ptr, void *Z_ptr);

//-----------------------------------------------------------------------------
// Double 
//-----------------------------------------------------------------------------

double dcopy(int N, double alpha_real, double alpha_imag,
	     void *X_ptr, void *Y_ptr, void *Z_ptr);

double dscale(int N, double alpha_real, double alpha_imag,
	      void *X_ptr, void *Y_ptr, void *Z_ptr);

double daxpy(int N, double alpha_real, double alpha_imag,
	     void *X_ptr, void *Y_ptr, void *Z_ptr);

double dsxpy(int N, double alpha_real, double alpha_imag,
	     void *X_ptr, void *Y_ptr, void *Z_ptr);

double ddot(int N, double alpha_real, double alpha_imag,
	    void *X_ptr, void *Y_ptr, void *Z_ptr);

//-----------------------------------------------------------------------------
// Double Complex
//-----------------------------------------------------------------------------

double zcopy(int N, double alpha_real, double alpha_imag,
	     void *X_ptr, void *Y_ptr, void *Z_ptr);

double zaxpy(int N, double alpha_real, double alpha_imag,
	     void *X_ptr, void *Y_ptr, void *Z_ptr);

double zsxpy(int N, double alpha_real, double alpha_imag,
	     void *X_ptr, void *Y_ptr, void *Z_ptr);

double zscale(int N, double alpha_real, double alpha_imag,
	      void *X_ptr, void *Y_ptr, void *Z_ptr);

double zmult(int N, double alpha_real, double alpha_imag,
	     void *X_ptr, void *Y_ptr, void *Z_ptr);

double zmultc(int N, double alpha_real, double alpha_imag,
	      void *X_ptr, void *Y_ptr, void *Z_ptr);

#endif // _PROCESSORS_H_
