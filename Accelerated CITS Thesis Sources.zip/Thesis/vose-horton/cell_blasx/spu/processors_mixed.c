#include <stdio.h>

#include "../blasx_cell_common.h"
#include "processors.h"

#ifndef PROCESSORS_OPTIMIZED

//-----------------------------------------------------------------------------
// Mixed
//-----------------------------------------------------------------------------

double zmultc_mixed(int N, 
		    double alpha_real NOT_USED, 
		    double alpha_imag NOT_USED,
		    void *X_ptr, 
		    void *Y_ptr, 
		    void *Z_ptr)
{
     double *X = (double*) X_ptr;
     float  *Y = (float*) Y_ptr;
     double *Z = (double*) Z_ptr;

     int i;
     for(i=0; i < N*2; i += 2)
     {
          // (X*Y)
          Z[i]   = (X[i] * (double)Y[i]) + (X[i+1] * (double)Y[i+1]);
          Z[i+1] = (X[i] * (double)Y[i+1]) - (X[i+1] * (double)Y[i]);
     }

     return 0;
}

double zsxpy_mixed(int N, 
		   double alpha_real,
		   double alpha_imag,
		   void *X_ptr, 
		   void *Y_ptr, 
		   void *Z_ptr)
{
     double *X = (double*) X_ptr;
     double *Y = (double*) Y_ptr;
     float *Z = (float*) Z_ptr;
     
     double temp_real, temp_imag;

     int i;
     for(i=0; i < N*2; i += 2)
     {
          // (X*alpha)
	  temp_real = (X[i] * alpha_real) - (X[i+1] * alpha_imag);
          temp_imag = (X[i] * alpha_imag) + (X[i+1] * alpha_real);

	  // - Y
	  temp_real -= Y[i];
	  temp_imag -= Y[i+1];

          Z[i]   = (float) temp_real;
          Z[i+1] = (float) temp_imag;
     }

     return 0;
}

double zero(int N, 
	    double alpha_real NOT_USED, 
	    double alpha_imag NOT_USED,
            void *X_ptr       NOT_USED, 
	    void *Y_ptr       NOT_USED, 
	    void *Z_ptr)
{
     int i;
     float *Z = (float*) Z_ptr;
     
     for(i=0; i < N; i++)
          Z[i] = 0;

     return 0;
}

#endif // !PROCESSORS_OPTIMIZED

