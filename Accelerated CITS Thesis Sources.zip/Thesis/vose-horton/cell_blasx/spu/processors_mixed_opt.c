#include <stdio.h>
#include <string.h>
#include <spu_intrinsics.h>

#include "../blasx_cell_common.h"
#include "processors.h"

#include "utility_macros.h"

#ifdef PROCESSORS_OPTIMIZED

//-----------------------------------------------------------------------------
// Mixed
//-----------------------------------------------------------------------------

double zmultc_mixed(int N, 
		    double alpha_real NOT_USED, 
		    double alpha_imag NOT_USED,
		    void *X_ptr, 
		    void *Y_ptr, 
		    void *Z_ptr)
{
     int si, di;

     vector double *X = (vector double*) X_ptr;
     vector float  *Y = (vector float*) Y_ptr;
     vector double *Z = (vector double*) Z_ptr;

     register vector double x0, x1, x2, x3;
     register vector float y0, y1;
     register vector double z0, z1, z2, z3;

     register vector double xr0, xr1;
     register vector double xi0, xi1;
     register vector double yr0, yr1;
     register vector double yi0, yi1;
     register vector double zr0, zr1;
     register vector double zi0, zi1;

     // Since the SPE loads data a quadword at a time,
     // we're traversing through the single and double
     // precision quads at a different rate (thus the separate
     // counters)
     for(si=0, di=0; di < N; di+=4, si+=2)
     {
	  x0 = X[di];
	  x1 = X[di+1];
	  x2 = X[di+2];
	  x3 = X[di+3];
	  
	  y0 = Y[si];
	  y1 = Y[si+1];

	  // Shuffle Z
	  xr0 = EXTRACT_REAL_DOUBLE(x0, x1);
	  xi0 = EXTRACT_IMAG_DOUBLE(x0, x1);

	  xr1 = EXTRACT_REAL_DOUBLE(x2, x3);
	  xi1 = EXTRACT_IMAG_DOUBLE(x2, x3);

	  // Extend and shuffle Y
	  VFLOAT_2_VDOUBLE_CPARTS(yr0, yi0, y0);
	  VFLOAT_2_VDOUBLE_CPARTS(yr1, yi1, y1);

	  // Conjugate and multiply
	  zr0 = spu_mul(xi0, yi0);
          zr0 = spu_madd(xr0, yr0, zr0);
          zi0 = spu_mul(xi0, yr0);
          zi0 = spu_msub(xr0, yi0, zi0);
	  
	  zr1 = spu_mul(xi1, yi1);
          zr1 = spu_madd(xr1, yr1, zr1);
          zi1 = spu_mul(xi1, yr1);
          zi1 = spu_msub(xr1, yi1, zi1);

          z0 = INSERT_EVEN_DOUBLE(zr0, zi0);
          z1 = INSERT_ODD_DOUBLE(zr0, zi0);

          z2 = INSERT_EVEN_DOUBLE(zr1, zi1);
          z3 = INSERT_ODD_DOUBLE(zr1, zi1);
	  
	  Z[di]   = z0;
	  Z[di+1] = z1;
	  Z[di+2] = z2;
	  Z[di+3] = z3;
     }
     
     return 0;
}

double zsxpy_mixed(int N, 
		   double alpha_real,
		   double alpha_imag,
		   void *X_ptr, 
		   void *Y_ptr, 
		   void *Z_ptr)
{
     int i, si;
     vector double *X = (vector double*) X_ptr;
     vector double *Y = (vector double*) Y_ptr;
     vector float *Z = (vector float*) Z_ptr;
     
     register vector double ar = spu_splats(alpha_real);
     register vector double ai = spu_splats(alpha_imag);
     
     register vector double x0, x1, x2, x3, x4, x5, x6, x7;
     register vector double y0, y1, y2, y3, y4, y5, y6, y7;
     register vector double z0, z1, z2, z3, z4, z5, z6, z7;
     
     register vector float r0, r1, r2, r3, r4, r5, r6, r7;
     
     register vector double xr0, xr1, xr2, xr3;
     register vector double xi0, xi1, xi2, xi3;
     register vector double zr0, zr1, zr2, zr3;
     register vector double zi0, zi1, zi2, zi3;
     
     for(i=0, si=0; i < N; i+=8, si+=4)
     {
          LOAD_X();
          LOAD_Y();

          EXTRACT_DOUBLE_X();

          // Z = (X*alpha)
          SCALE_X(ar, ai);
          INSERT_DOUBLE_Z();

          // Z += Y
	  z0 = spu_sub(z0, y0);
	  z1 = spu_sub(z1, y1);
	  z2 = spu_sub(z2, y2);
	  z3 = spu_sub(z3, y3);
	  z4 = spu_sub(z4, y4);
	  z5 = spu_sub(z5, y5);
	  z6 = spu_sub(z6, y6);
	  z7 = spu_sub(z7, y7);
	  
	  VDOUBLE_2_VFLOAT(z0, z1, r0, r1);
	  VDOUBLE_2_VFLOAT(z2, z3, r2, r3);
	  VDOUBLE_2_VFLOAT(z4, z5, r4, r5);
	  VDOUBLE_2_VFLOAT(z6, z7, r6, r7);
	  
          Z[si]   = r0;
          Z[si+1] = r2;
          Z[si+2] = r4;
          Z[si+3] = r6;
     }

     return 0;
}

double zero(int N,
            double alpha_real NOT_USED,
            double alpha_imag NOT_USED,
            void *X_ptr       NOT_USED,
            void *Y_ptr       NOT_USED,
            void *Z_ptr)
{
     int i;
     float *Z = (float*) Z_ptr;

     for(i=0; i < N; i++)
          Z[i] = 0;

     return 0;
}

#endif // PROCESSORS_OPTIMIZED
