#ifndef _UTILITY_MACROS_H_
#define _UTILITY_MACROS_H_

//-----------------------------------------------------------------------------
// Insertion/ Extraction Macros
//-----------------------------------------------------------------------------

// 
// The spu_shuffle function composes a vector from two input vectors based 
// on a byte selector mask. For our purposes we're mostly instrested in 
// shuffling whole words (for dealing with complex numbers, doubles, etc.)
// 
//           +-----------------------+
//           |W0|W1|W2|W3|W4|W5|W6|W7|
//           +-----------------------+
//           | vector a  |  vector b |
//           +-----------------------+
//    The word layout as interpreted by spu_shuffle
//
// Word masks (by byte #)
#define W0 0,1,2,3
#define W1 4,5,6,7
#define W2 8,9,10,11
#define W3 12,13,14,15
#define W4 16,17,18,19
#define W5 20,21,22,23
#define W6 24,25,26,27
#define W7 28,29,30,31

typedef vector unsigned char smask;

#define ZERO_VEC ((vector float){0,0,0,0})

#define DOUBLE_EVEN_MASK ((smask){W0,W1,W4,W5})
#define DOUBLE_ODD_MASK  ((smask){W2,W3,W6,W7})

#define EXTRACT_REAL(a, b) (spu_shuffle((a), (b), ((smask){W0,W2,W4,W6})))
#define EXTRACT_IMAG(a, b) (spu_shuffle((a), (b), ((smask){W1,W3,W5,W7})))

#define EXTRACT_REAL_DOUBLE(a, b) (spu_shuffle((a), (b), DOUBLE_EVEN_MASK))
#define EXTRACT_IMAG_DOUBLE(a, b) (spu_shuffle((a), (b), DOUBLE_ODD_MASK))

#define INSERT_EVEN(a, b) (spu_shuffle((a), (b), ((smask){W0,W4,W1,W5})))
#define INSERT_ODD(a, b)  (spu_shuffle((a), (b), ((smask){W2,W6,W3,W7})))

#define INSERT_EVEN_DOUBLE(a, b) (spu_shuffle((a), (b), DOUBLE_EVEN_MASK))
#define INSERT_ODD_DOUBLE(a, b)  (spu_shuffle((a), (b), DOUBLE_ODD_MASK))

// f{W0,W1,W2,W3}
// d0 = f{W0,W1}
// d1 = f{W2,W3}
// Note: This macro modifies f
#define VFLOAT_2_VDOUBLE(d0, d1, f)                                     \
     do{                                                                \
	  (f)  = spu_shuffle((f), ZERO_VEC, ((smask){W0,W2,W1,W3}));	\
	  (d0) = spu_extend((f));                                       \
	  (f)  = spu_rlqwbyte((f), 4);                                  \
	  (d1) = spu_extend((f));                                       \
     }while(0)

// f{W0,W1,W2,W3}
// d0 = f{W0,W2}
// d1 = f{W1,W3}
// Note: This macro modifies f
#define VFLOAT_2_VDOUBLE_CPARTS(d0, d1, f)                              \
     do{                                                                \
	  (d0) = spu_extend((f));                                       \
	  (f)  = spu_rlqwbyte((f), 4);                                  \
	  (d1) = spu_extend((f));                                       \
     }while(0)

// f0{W0,W1,W2,W3} = d0{W0,W1}, d1{W2,W3}
// Note: f1 is a temporary float vector which is modified
#define VDOUBLE_2_VFLOAT(d0, d1, f0, f1)                                \
     do{                                                                \
	  (f0) = spu_roundtf((d0));                                     \
	  (f1) = spu_roundtf((d1));                                     \
	  (f0) = EXTRACT_REAL(f0, f1);                                  \
     }while(0)

// f0{W0,W1,W2,W3} = d0{W0,W2}, d1{W1,W3}
// Note: f1 is a temporary float vector which is modified
#define VDOUBLE_2_VFLOAT_CPARTS(d0, d1, f0, f1)				\
     do{                                                                \
	  (f0) = spu_roundtf((d0));                                     \
	  (f1) = spu_roundtf((d1));                                     \
	  (f0) = spu_shuffle((f0), (f1), ((smask){W0,W4,W2,W6}));	\
     }while(0)


//-----------------------------------------------------------------------------
// Block operation macros
//-----------------------------------------------------------------------------

#define LOAD_X()                                \
     do {                                       \
	  x0 = X[i];                            \
	  x1 = X[i+1];                          \
	  x2 = X[i+2];                          \
	  x3 = X[i+3];                          \
	  x4 = X[i+4];                          \
	  x5 = X[i+5];                          \
	  x6 = X[i+6];                          \
	  x7 = X[i+7];                          \
     } while(0)

#define LOAD_F2D_X()                            \
     do {                                       \
	  x0 = X[i];                            \
	  x1 = X[i+1];                          \
	  x2 = X[i+2];                          \
	  x3 = X[i+3];                          \
	  VFLOAT_2_VDOUBLE(dx0, dx1, x0);       \
	  VFLOAT_2_VDOUBLE(dx2, dx3, x1);       \
	  VFLOAT_2_VDOUBLE(dx4, dx5, x2);       \
	  VFLOAT_2_VDOUBLE(dx6, dx7, x3);       \
     } while(0)


#define LOAD_F2D_X_CPARTS()			       \
     do {					       \
	  x0 = X[i];				       \
	  x1 = X[i+1];				       \
	  x2 = X[i+2];				       \
	  x3 = X[i+3];				       \
	  VFLOAT_2_VDOUBLE_CPARTS(xr0, xi0, x0);       \
	  VFLOAT_2_VDOUBLE_CPARTS(xr1, xi1, x1);       \
	  VFLOAT_2_VDOUBLE_CPARTS(xr2, xi2, x2);       \
	  VFLOAT_2_VDOUBLE_CPARTS(xr3, xi3, x3);       \
     } while(0)


#define LOAD_Y()                                \
     do {                                       \
	  y0 = Y[i];                            \
	  y1 = Y[i+1];                          \
	  y2 = Y[i+2];                          \
	  y3 = Y[i+3];                          \
	  y4 = Y[i+4];                          \
	  y5 = Y[i+5];                          \
	  y6 = Y[i+6];                          \
	  y7 = Y[i+7];                          \
     } while(0)


#define LOAD_F2D_Y()                            \
     do {                                       \
	  y0 = Y[i];                            \
	  y1 = Y[i+1];                          \
	  y2 = Y[i+2];                          \
	  y3 = Y[i+3];                          \
	  VFLOAT_2_VDOUBLE(dy0, dy1, y0);       \
	  VFLOAT_2_VDOUBLE(dy2, dy3, y1);       \
	  VFLOAT_2_VDOUBLE(dy4, dy5, y2);       \
	  VFLOAT_2_VDOUBLE(dy6, dy7, y3);       \
     } while(0)

#define LOAD_F2D_Y_CPARTS()                            \
     do {                                              \
	  y0 = Y[i];                                   \
	  y1 = Y[i+1];                                 \
	  y2 = Y[i+2];                                 \
	  y3 = Y[i+3];                                 \
	  VFLOAT_2_VDOUBLE_CPARTS(yr0, yi0, y0);       \
	  VFLOAT_2_VDOUBLE_CPARTS(yr1, yi1, y1);       \
	  VFLOAT_2_VDOUBLE_CPARTS(yr2, yi2, y2);       \
	  VFLOAT_2_VDOUBLE_CPARTS(yr3, yi3, y3);       \
     } while(0)

#define EXTRACT_X()                             \
     do {                                       \
	  xr0 = EXTRACT_REAL(x0, x1);           \
	  xi0 = EXTRACT_IMAG(x0, x1);           \
	  xr1 = EXTRACT_REAL(x2, x3);           \
	  xi1 = EXTRACT_IMAG(x2, x3);           \
	  xr2 = EXTRACT_REAL(x4, x5);           \
	  xi2 = EXTRACT_IMAG(x4, x5);           \
	  xr3 = EXTRACT_REAL(x6, x7);           \
	  xi3 = EXTRACT_IMAG(x6, x7);           \
     } while(0)

#define EXTRACT_DOUBLE_X()                                              \
     do {                                                               \
	  xr0 = EXTRACT_REAL_DOUBLE(x0, x1);                            \
	  xi0 = EXTRACT_IMAG_DOUBLE(x0, x1);                            \
	  xr1 = EXTRACT_REAL_DOUBLE(x2, x3);                            \
	  xi1 = EXTRACT_IMAG_DOUBLE(x2, x3);                            \
	  xr2 = EXTRACT_REAL_DOUBLE(x4, x5);                            \
	  xi2 = EXTRACT_IMAG_DOUBLE(x4, x5);                            \
	  xr3 = EXTRACT_REAL_DOUBLE(x6, x7);                            \
	  xi3 = EXTRACT_IMAG_DOUBLE(x6, x7);                            \
     } while(0)


#define EXTRACT_Y()                             \
     do {                                       \
	  yr0 = EXTRACT_REAL(y0, y1);           \
	  yi0 = EXTRACT_IMAG(y0, y1);           \
	  yr1 = EXTRACT_REAL(y2, y3);           \
	  yi1 = EXTRACT_IMAG(y2, y3);           \
	  yr2 = EXTRACT_REAL(y4, y5);           \
	  yi2 = EXTRACT_IMAG(y4, y5);           \
	  yr3 = EXTRACT_REAL(y6, y7);           \
	  yi3 = EXTRACT_IMAG(y6, y7);           \
     } while(0)


#define EXTRACT_DOUBLE_Y()			       \
     do {					       \
	  yr0 = EXTRACT_REAL_DOUBLE(y0, y1);           \
	  yi0 = EXTRACT_IMAG_DOUBLE(y0, y1);           \
	  yr1 = EXTRACT_REAL_DOUBLE(y2, y3);           \
	  yi1 = EXTRACT_IMAG_DOUBLE(y2, y3);           \
	  yr2 = EXTRACT_REAL_DOUBLE(y4, y5);           \
	  yi2 = EXTRACT_IMAG_DOUBLE(y4, y5);           \
	  yr3 = EXTRACT_REAL_DOUBLE(y6, y7);           \
	  yi3 = EXTRACT_IMAG_DOUBLE(y6, y7);           \
     } while(0)


#define SCALE_X(ar, ai)                         \
     do{                                        \
	  zr0 = spu_mul(xi0, (ai));             \
	  zr0 = spu_msub(xr0, (ar), zr0);       \
	  zi0 = spu_mul(xi0, (ar));             \
	  zi0 = spu_madd(xr0, (ai), zi0);       \
	  zr1 = spu_mul(xi1, (ai));             \
	  zr1 = spu_msub(xr1, (ar), zr1);       \
	  zi1 = spu_mul(xi1, (ar));             \
	  zi1 = spu_madd(xr1, (ai), zi1);       \
	  zr2 = spu_mul(xi2, (ai));             \
	  zr2 = spu_msub(xr2, (ar), zr2);       \
	  zi2 = spu_mul(xi2, (ar));             \
	  zi2 = spu_madd(xr2, (ai), zi2);       \
	  zr3 = spu_mul(xi3, (ai));             \
	  zr3 = spu_msub(xr3, (ar), zr3);       \
	  zi3 = spu_mul(xi3, (ar));             \
	  zi3 = spu_madd(xr3, (ai), zi3);       \
     }while(0)

#define INSERT_Z()                              \
     do {                                       \
	  z0 = INSERT_EVEN(zr0, zi0);           \
	  z1 = INSERT_ODD(zr0, zi0);            \
	  z2 = INSERT_EVEN(zr1, zi1);           \
	  z3 = INSERT_ODD(zr1, zi1);            \
	  z4 = INSERT_EVEN(zr2, zi2);           \
	  z5 = INSERT_ODD(zr2, zi2);            \
	  z6 = INSERT_EVEN(zr3, zi3);           \
	  z7 = INSERT_ODD(zr3, zi3);            \
     }while(0)

#define INSERT_DOUBLE_Z()                               \
     do {                                               \
	  z0 = INSERT_EVEN_DOUBLE(zr0, zi0);            \
	  z1 = INSERT_ODD_DOUBLE(zr0, zi0);             \
	  z2 = INSERT_EVEN_DOUBLE(zr1, zi1);            \
	  z3 = INSERT_ODD_DOUBLE(zr1, zi1);             \
	  z4 = INSERT_EVEN_DOUBLE(zr2, zi2);            \
	  z5 = INSERT_ODD_DOUBLE(zr2, zi2);             \
	  z6 = INSERT_EVEN_DOUBLE(zr3, zi3);            \
	  z7 = INSERT_ODD_DOUBLE(zr3, zi3);             \
     }while(0)

#define STORE_DZ()                              \
     do {                                       \
	  VDOUBLE_2_VFLOAT(dz0, dz1, t0, t1);   \
	  VDOUBLE_2_VFLOAT(dz2, dz3, t2, t3);   \
	  VDOUBLE_2_VFLOAT(dz4, dz5, t4, t5);   \
	  VDOUBLE_2_VFLOAT(dz6, dz7, t6, t7);   \
	  Z[i]   = t0;                          \
	  Z[i+1] = t2;                          \
	  Z[i+2] = t4;                          \
	  Z[i+3] = t6;                          \
     }while(0)

#define STORE_DOUBLE_COMLPEX_Z()		       \
     do {					       \
	  VDOUBLE_2_VFLOAT_CPARTS(zr0, zi0, t0, t1);   \
	  VDOUBLE_2_VFLOAT_CPARTS(zr1, zi1, t2, t3);   \
	  VDOUBLE_2_VFLOAT_CPARTS(zr2, zi2, t4, t5);   \
	  VDOUBLE_2_VFLOAT_CPARTS(zr3, zi3, t6, t7);   \
	  Z[i]   = t0;				       \
	  Z[i+1] = t2;				       \
	  Z[i+2] = t4;				       \
	  Z[i+3] = t6;				       \
     }while(0)


#endif // _UTILITY_MACROS_H_
