#ifndef _BLASX_CELL_COMMON_H_
#define _BLASX_CELL_COMMON_H_

#define ALIGN128  __attribute__ ((aligned(128)))
#define NOT_USED  __attribute__ ((unused))
        
#define MAX_SPES 6

//-----------------------------------------------------------------------------
// DMA_CHUNK_SIZE 
// This is the size (in bytes) of the blocks used for data transfer between
// the PPU and the SPUs. 
// 
// Requirements:
// - Must be a multiple of 16 (For data alignment and performance)
// - Must be no larger than 32K (Storage requirements on the SPUs)

//#define DMA_CHUNK_SIZE 32768
#define DMA_CHUNK_SIZE 16384
//#define DMA_CHUNK_SIZE 8192
//#define DMA_CHUNK_SIZE 4096

// Due to optimizations used in the SPEs, it is cleaner to only
// operate on multiples of 32 elements. For now, this is enforced
// as a constraint, though it could certainly be mopped up by the PPU
// (it'll need SOMEthing to do while it waits...)
#define CELL_N_MULTIPLE 32

typedef unsigned long long addr64_t;

// Typesize definitions
#define S_SIZE (sizeof(float))
#define D_SIZE (sizeof(double))
#define C_SIZE (sizeof(float)*2)
#define Z_SIZE (sizeof(double)*2)
#define UNUSED 0

// SPE commands
// Note: These are used similar to system call numbers by the  SPE - 
// the command is used to lookup the implementing function in a map. 
// If these are changed, then the function map in dispatch.c must
// be modified as well.
enum blasx_spe_command
{
     BSC_scopy        = 0,
     BSC_sscale       = 1,
     BSC_saxpy        = 2,
     BSC_ssxpy        = 3,
     BSC_sdot         = 4,
     BSC_ccopy        = 5,
     BSC_caxpy        = 6,
     BSC_csxpy        = 7,
     BSC_cscale       = 8,
     BSC_cmult        = 9, 
     BSC_cmultc       = 10,
     BSC_zmultc_mixed = 11,
     BSC_zsxpy_mixed  = 12,
     BSC_zero         = 13,
     BSC_dcopy        = 14,
     BSC_dscale       = 15,
     BSC_daxpy        = 16,
     BSC_dsxpy        = 17,
     BSC_ddot         = 18,
     BSC_zcopy        = 19,
     BSC_zaxpy        = 20,
     BSC_zsxpy        = 21,
     BSC_zscale       = 22,
     BSC_zmult        = 23,
     BSC_zmultc       = 24,
     BSC_META_OPS     = 100,
     BSC_PING         = 101,
     BSC_EXIT         = 999
};

typedef struct
{
     int command;
     int X_type_size;
     int Y_type_size;
     int Z_type_size;
     int N_per_block;
     int max_spes;
} DispatchDiscriptor;

typedef struct
{
     int N;
     addr64_t X;
     addr64_t Y;
     addr64_t Z;
     double alpha_real;
     double alpha_imag;
} DispatchData;

typedef struct 
{
     DispatchDiscriptor descriptor;
     DispatchData data;
     double ret_val;
     volatile unsigned int spe_finished_flag;
} ALIGN128 blasx_comm_t;

typedef blasx_comm_t * blasx_comm_ptr_t;

// Conversion Macros
#ifdef __PPC__
    #ifdef __PPC64__
       #define _BLASX_64B_   1
    #else
       #define _BLASX_32B_   1
    #endif
    #elif __SPU__
       #define _BLASX_32B_   1
    #endif
#endif

#ifdef _BLASX_32B_ //32Bit Compiler

    #define PTR_TO_ADDR64( ptr , addr) {					\
     (addr) = ( (unsigned long)(ptr) & 0xFFFFFFFFUL);			\
    }

    //! Macro to cast 64 bits effective address to a pointer
    #define ADDR64_TO_PTR( addr, type, ptr) { (ptr) = (type)((unsigned int)addr); }

    #define ADDR64_PTR_OFFSET(addr, offset) (addr.ui[1] + offset)

    #define MISALIGNED(addr) ((unsigned long)(addr) & 0xF)

#elif _BLASX_64B_ //64Bit Compiler

    #define PTR_TO_ADDR64( ptr , addr) {				     \
     (addr) = (unsigned long long)(ptr);				\
    }

    //! Macro to cast 64 bits effective address to a pointer
    #define ADDR64_TO_PTR( addr, type, ptr) { (ptr) = (type)(addr);}
    #define ADDR64_PTR_OFFSET(addr, offset) (addr + offset)

    #define MISALIGNED(addr) ((unsigned long long)(addr) & 0xF)

#endif // _BLASX_CELL_COMMON_H_
