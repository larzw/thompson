#include "blasx_cell.h"
#include <libspe2.h>

static int max_spes = 0;

void limit_blasx_spes(int n)
{
     max_spes = n;
}

void init_blasx_library()
{
     int available_spes;
     available_spes = spe_cpu_info_get(SPE_COUNT_PHYSICAL_SPES, -1);
     
     if(max_spes > 0 && max_spes < available_spes)
	  available_spes = max_spes;
     
     blasx_start_spes(available_spes);
}

void close_blasx_library()
{
     ;
}
