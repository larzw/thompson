#include <complex.h>
#include <math.h>
#include <stdlib.h>
#include <string.h>

void blasx_zero(size_t N, void *ptr)
{
     memset(ptr, 0, N);
}

void blasx_s2d(const int N, const float *X, double *Z)
{
     int i;
     for(i=0; i < N; i++)
	  Z[i] = (double) X[i];
}

void blasx_d2s(const int N, const double *X, float *Z)
{
     int i;
     for(i=0; i < N; i++)
	  Z[i] = (float) X[i];
}

void blasx_c2z(const int N, const float complex *X, double complex *Z)
{
     int i;
     for(i=0; i < N; i++)
	  Z[i] = (double complex) X[i];
}

void blasx_z2c(const int N, const double complex *X, float complex *Z)
{
     int i;
     for(i=0; i < N; i++)
	  Z[i] = (float complex) X[i];
}
