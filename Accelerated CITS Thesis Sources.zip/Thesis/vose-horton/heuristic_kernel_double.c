#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <complex.h>

#include "ctis_double.h"
#include "ctis_config.h"
#include "fft_interface.h"
#include "blas_interface.h"

#define ZERO_DC(x) (x[0] = 0)

void heuristic_kernel(CTIS_Config *cfg,  CTIS_Workspace *work)
{
     // Config aliases
     int n = cfg->n;
     int w = cfg->w;
     double  mu = cfg->mu;
     double  muInv = cfg->muInv;
     double complex zmuInv = muInv;
     int zlen = cfg->zlen;

     // Data aliases
     double complex *eta = work->eta;
     double complex *Fck = work->Fck;
     int32_t *ZPattern   = work->ZPattern;
     double *f_est       = work->f_est;

     // Overlays for use with real and complex types
     double complex *cv   = (double complex *) work->v;
     double complex *cv1  = (double complex *) work->v1;
     double complex *cv2  = (double complex *) work->v2;
     double complex *cv3  = (double complex *) work->v3;

     double *rv   = (double *) work->v;
     double *rv1  = (double *) work->v1;
     double *rv2  = (double *) work->v2;
     double *rv3  = (double *) work->v3;

     // Local Variables
     int i;
          
     // cv = fft(v)
     fftw_execute_dft_r2c(work->fft_ip_double, rv, cv);
     //ZERO_DC(cv);
     
     // cv3 = 0;
     cell_zero(zlen*sizeof(double complex), cv3);
     
     // v = mult_sHTranspose( Fck, v, w);
     for(i=0; i < w; i++)
     {
	  // cv2 = cv * conj(Fck)
	  cell_zmultc(zlen, &Fck[i*zlen], cv, cv2);
	  
	  // cv1 = cv2 * conj(eta)
	  cell_zmultc(zlen, &eta[i*zlen], cv2, &cv1[i*zlen]);
	  
	  // cv3 = cv3 + cv1
	  cell_zaxpy(zlen, 1, &cv1[i*zlen], cv3, cv3);
	  
	  // cv1 = (1/mu)*cv2
	  cell_zscal(zlen, zmuInv, cv2, &cv1[i*zlen]);
     }

     // v1 = mult_PTranspose * mult_P
     for(i=0; i < w; i++)
     {
	  // cv2 = cv3*eta
	  cell_zmult(zlen, &eta[i*zlen], cv3, cv2);
	  
	  // cv2 = cv1-cv2
	  cell_zsxpy(zlen, 1, &cv1[i*zlen], cv2, cv2);

	  // rv = ifft(v2)
	  fftw_execute_dft_c2r(work->ifft_ip_double, cv2, rv2);
	  
	  cell_dscal(n, (double)1/n, rv2,  &rv[i*n]);
     }

     // cv1 = 0;
     cell_zero(zlen*sizeof(double complex), cv1);
     
     for(i=0; i < w; i++)
     {
	  // rv2 = ZPrimePattern * rv
	  cell_dmask(n, 1, &rv[n*i], rv2, 1, ZPattern);
	  
	  // fcv2 = fft(frv2)
	  fftw_execute_dft_r2c(work->fft_ip_double, rv2, cv2);

	  // cv2 = cv2 * conj(eta)
	  cell_zmultc(zlen, &eta[i*zlen], cv2, cv2);
	  
	  //cv1 = cv3 + cv2
	  cell_zaxpy(zlen, 1, cv2, cv1, cv1);
     }
     
     fftw_execute_dft_c2r(work->ifft_ip_double, cv1, rv1);

     cell_dscal(n*w, (double)1/n, rv1, rv1);

     /////////////////////// Conjugate Gradient //////////////////////////     
     // In use: x, v, v1

     // v2 = conjugate_gradient()
     conjugate_gradient(cfg, work);
     
     fftw_execute_dft_r2c(work->fft_ip_double, rv2, cv2);
     
     for(i=0; i < w; i++)
     {
	  // cv3 = v2 * eta
	  cell_zmult(zlen, &eta[i*zlen], cv2, cv3);
	  
	  // v3 = fft(v3)
	  fftw_execute_dft_c2r(work->ifft_ip_double, cv3, rv3);
	  
	  //rv1 = (1/n)*rv3 + rv
	  cell_daxpy(n, (double)1/n, rv3, &rv[i*n], &rv1[i*n]);
     }
     
     // v2 = 0
     cell_zero(zlen*sizeof(double complex), cv2);
     
     for(i=0; i < w; i++)
     {
	  cell_dmask(n, 1, &rv1[n*i], rv3, 1, ZPattern);
	  
	  // v3 = fft(v3)
	  fftw_execute_dft_r2c(work->fft_ip_double, rv3, cv3);

	  // v3 = conj(eta) * v3
	  cell_zmultc(zlen, &eta[i*zlen], cv3, cv3);
	  
	  // v2 = v2 + v3
	  cell_zaxpy(zlen, 1, cv3, cv2, cv2);
     }
     
     for(i=0; i < w; i++)
     {
	  // v3 = eta * v2
	  cell_zmult(zlen, &eta[i*zlen], cv2, cv3);
	  
	  // v3 = ifft(v3)
	  fftw_execute_dft_c2r(work->ifft_ip_double, cv3, rv3);
	  
	  // rv[i*n] += rv3*(((double)1/n)*mu)
	  cell_daxpy(n, ((double)1/n)*mu, rv3, &rv[i*n], &rv[i*n]);
     }

     RunZReduce(f_est, rv2, rv, ZPattern, n, w);
}

void conjugate_gradient(CTIS_Config *cfg, CTIS_Workspace *work)
{
     int i;
     int pass;
     double lastE, dotR;
     double ca, e;

     // Namespace aliases
     int n = cfg->n;
     int w = cfg->w;
     double  muInv = cfg->muInv;
     int zlen = cfg->zlen;

     double complex *eta = work->eta;
     int32_t *ZPattern   = work->ZPattern;

     double complex *cv2  = (double complex *) work->v2;
     double complex *cv3  = (double complex *) work->v3;

     double *rv1  = (double *) work->v1;
     double *rv2  = (double *) work->v2;
     double *rv3  = (double *) work->v3;

     double *cg_x        = work->cg_x;
     double *cg_r        = work->cg_r;
     double *cg_p        = work->cg_p;
     double *cg_v        = work->cg_v;

     /////////////////////// Conjugate Gradient //////////////////////////
     
     // cg_x = 0;
     cell_zero(sizeof(double)*n, cg_x);

     // cg_r = rv1
     cell_dcopy(n, rv1, cg_r);
	  
     //cg_p = cg_r
     cell_dcopy(n, cg_r, cg_p);
     
     // e = dot(cg_r, cg_r)
     e = cell_ddot(n, cg_r, cg_r);

     pass = 0;	  
     while(e > cfg->CG_EPSILON && pass < cfg->CG_ITERS)
     {
	  pass++;

	  lastE = e;
	  
	  //cg_v = 0
	  cell_zero(zlen*sizeof(double complex), cg_v);
	  
	  // cfv2 = fft(cg_p)
	  fftw_execute_dft_r2c(work->fft_oop_double, cg_p, cv2);

	  for(i=0; i < w; i++)
	  {
	       // v3 = v2 * eta
	       cell_zmult(zlen, &eta[i*zlen], cv2, cv3);
	       
	       // v3 = ifft(v3)
	       fftw_execute_dft_c2r(work->ifft_ip_double, cv3, rv3);

	       // v3 = ZPrimePattern * v3
	       cell_dmask(n, (double)1/n, rv3, rv3, 1, ZPattern);
	       
	       // v3 = fft(v3)
	       fftw_execute_dft_r2c(work->fft_ip_double, rv3, cv3);

	       // v3 = conj(eta) * v3
	       cell_zmultc(zlen, &eta[i*zlen], cv3, cv3);
	       
	       // cg_v = cg_v + v3
	       cell_zaxpy(zlen, 1, cv3, (double complex*)cg_v, 
			  (double complex*)cg_v);
	  }
	  
	  fftw_execute_dft_c2r(work->ifft_ip_double, 
			       (double complex*)cg_v, cg_v);
	  
	  cell_dscal(n, (double)1/n, cg_v, cg_v);
	  
	  // cg_v = (cg_p*muInv) - cg_v
	  cell_dsxpy(n, muInv, cg_p, cg_v, cg_v);

	  ca = e/cell_ddot(n, cg_p, cg_v);

	  //cg_r = -ca*cg_v + cg_r
	  cell_daxpy(n, -ca, cg_v, cg_r, cg_r);

	  dotR = cell_ddot(n, cg_r, cg_r);
	  
	  if(lastE < dotR)
	       break;
	  
	  cell_daxpy(n, ca, cg_p, cg_x, cg_x);
	  ca = dotR;
	  
	  // cg_p = cg_r + (a/e)*cg_p
	  cell_daxpy(n, (ca/e), cg_p, cg_r, cg_p);

	  e = ca;	 
     }
     
     // v2 = cg_x
     cell_dcopy(n, cg_x, rv2);

     fprintf(stdout, "CG Passes: %d, e: %f\n", pass, e);     
}

void calculate_residual(CTIS_Config *cfg, CTIS_Workspace *work)
{
     int n = cfg->n;
     int w = cfg->w;
     int zlen = cfg->zlen;
     
     double *f_est = work->f_est;
     double *x     = work->x;
     double complex *Fck = work->Fck;
     int32_t *ZPattern   = work->ZPattern;

     double *rv   = (double *) work->v;
     double *rv1  = (double *) work->v1;
     double *rv2  = (double *) work->v2;
     double *rv3  = (double *) work->v3;

     double complex *cv3  = (double complex *) work->v3;

     // Local Variables
     int i;
     double ls;
          
     // rv1 = 0;
     cell_zero(n*sizeof(double), rv1);
     
     for(i=0; i < w; i++)
     {
	  // rv3 = fft(rv2)
	  fftw_execute_dft_r2c(work->fft_oop_double, &rv2[i*n], cv3);

	  // cv3 = cv3*Fck
	  cell_zmult(zlen, &Fck[i*zlen], cv3, cv3);
	  
	  // rv3 = ifft(cv3)
	  fftw_execute_dft_c2r(work->ifft_ip_double, cv3, rv3);
	  
	  // rv1 = rv1 + rv3
	  cell_daxpy(n, (double)1/n, rv3, rv1, rv1);
     }
     
     ls = cell_ddot(n, rv1, x)/cell_ddot(n, rv1, rv1);
     
     /////// Recalculate v ////////////
     RunLSAdjust(rv1, f_est, ls, ZPattern, n, w);

     // frv = 0
     cell_zero(n*sizeof(double), rv);

     for(i=0; i < w; i++)
     {
	  // rv3 = fft(rv3)
	  fftw_execute_dft_r2c(work->fft_oop_double, &rv1[i*n], cv3);
	  
	  // cv3 = cv3*Fck
	  cell_zmult(zlen, &Fck[i*zlen], cv3, cv3);

	  // rv3 = ifft(cv3)
	  fftw_execute_dft_c2r(work->ifft_ip_double, cv3, rv3);
	  
	  // rv = rv + rv3
	  cell_daxpy(n, (double)1/n, rv3, rv, rv);
     }

     // v = x-v
     cell_dsxpy(n, 1, x, rv, rv);
}


void RunZReduce(double *f, double *v2, double *v, int32_t *mask, int n, int w)
{
     int i, j, wPos, bPos, z;
     int k;

     k = 0;
     for(i=0; i < w; i++)
     {
          wPos = bPos = 0 ;
          for(j=0; j < n; j++)
          {
               z = mask[wPos] & 1 << (31-bPos);
               if(z)
               {
                    f[k] = v[(i*n)+j]+f[k];
                    v2[(i*n)+j] = f[k];
                    k++;
               }
               else
                    v2[(i*n)+j] = 0.0;

               bPos++;
               if(bPos == 32)
               {
                    bPos = 0;
                    wPos++;
               }
          }
     }
}


void RunLSAdjust(double *v1, double *f, double lse, int32_t *mask, int n, int w)
{
     int i, j, wPos, bPos, z;
     int k;

     k = 0;
     for(i=0; i < w; i++)
     {
          wPos = bPos = 0 ;
          for(j=0; j < n; j++)
          {
               z = mask[wPos] & 1 << (31-bPos);
               if(z)
               {
                    v1[(i*n)+j] = f[k]*lse;
                    k++;
               }
               else
                    v1[(i*n)+j] = 0.0;

               bPos++;
               if(bPos == 32)
               {
                    bPos = 0;
                    wPos++;
               }
          }
     }
}


