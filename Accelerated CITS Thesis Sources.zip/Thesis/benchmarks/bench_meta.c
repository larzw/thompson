#include <string.h>
#include <math.h>
#include "bench.h"
#include "cell_util.h"
#include "blasx.h"

static void RandomizeSingleVector(size_t N, void *z);
static void RandomizeDoubleVector(size_t N, void *z);
static void RandomizeSingleComplexVector(size_t N, void *z);
static void RandomizeDoubleComplexVector(size_t N, void *z);

static void CheckSingle(BenchData *b);
static void CheckDouble(BenchData *b);
static void CheckSingleComplex(BenchData *b);
static void CheckDoubleComplex(BenchData *b);

typedef void (*Randomizer)(size_t N, void *vector);
typedef void (*Checker)(BenchData *b);

Randomizer randomizers[] = 
{
     RandomizeSingleVector,
     RandomizeDoubleVector,
     RandomizeSingleComplexVector,
     RandomizeDoubleComplexVector
};

Checker checkers[] = 
{
     CheckSingle,
     CheckDouble,
     CheckSingleComplex,
     CheckDoubleComplex
};

int size_map [] = 
{
     sizeof(float), 
     sizeof(double),
     sizeof(float complex), 
     sizeof(double complex)
};

void alloc_test_vectors(BenchData *b)
{
     void* (*allocator)(size_t size);

     if(b->use_huge_pages)
	  allocator = huge_alloc;
     else
	  allocator = cell_malloc;

     b->x = allocator(MAX_BLOCK_SIZE);
     b->y = allocator(MAX_BLOCK_SIZE);
     b->baseline_z = allocator(MAX_BLOCK_SIZE);     
     b->bench_z = allocator(MAX_BLOCK_SIZE);
}

void warmup_library(BenchData *b)
{
     blasx_scopy(b->N, b->x, b->baseline_z);
     blasx_cell_scopy(b->N, b->x, b->bench_z);
}

void prep_bench_data(BenchData *bd, BenchEntry *be)
{
     randomizers[be->X_type](bd->N, bd->x);
     randomizers[be->Y_type](bd->N, bd->y);
     
     memset(bd->baseline_z, EMPTY_BASELINE_Z, size_map[be->Z_type]*bd->N);
     memset(bd->bench_z, EMPTY_BENCH_Z, size_map[be->Z_type]*bd->N);
     
     init_ppu_timer(&bd->baseline_timer);
     init_ppu_timer(&bd->bench_timer);
}

void check_bench_results(BenchData *bd, BenchEntry *be)
{
     checkers[be->Z_type](bd);
}

void RandomizeSingleVector(size_t N, void *z)
{
     size_t i;
     float *mask = z;
     for(i=0; i < N; i++)
	  mask[i] = RandomSingle();
}

void RandomizeDoubleVector(size_t N, void *z)
{
     size_t i;
     double *mask = z;
     for(i=0; i < N; i++)
	  mask[i] = RandomDouble();
}

void RandomizeSingleComplexVector(size_t N, void *z)
{
     size_t i;
     float *mask = z;

     for(i=0; i < N*2; i+=2)
     {
          mask[i] = RandomSingle();
	  mask[i+1] =  RandomSingle();
     }
}

void RandomizeDoubleComplexVector(size_t N, void *z)
{
     size_t i;
     double *mask = z;
     
     for(i=0; i < N*2; i+=2)
     {
          mask[i] = RandomDouble();
	  mask[i+1] =  RandomDouble();
     }
}

void CheckSingle(BenchData *b)
{
     int i;
     double d;
     double sum, max_x, max_diff;
     double x_hat, x;
     float *z1, *z2;

     z1 = b->baseline_z;
     z2 = b->bench_z;
     
     sum = max_x = max_diff = 0;

     for(i=0; i < b->N; i++)
     {
	  x = z1[i];
	  x_hat = z2[i];
	  
	  d = fabs(x - x_hat);
	  
	  // Largest difference element
	  if(d > max_diff)
	       max_diff = d;
	  
	  sum += d;
     }
     
     b->average_error = sum/b->N;
     b->max_error = max_diff;
}

void CheckDouble(BenchData *b)
{
     int i;
     double d;
     double sum, max_x, max_diff;
     double x_hat, x;
     double *z1, *z2;

     z1 = b->baseline_z;
     z2 = b->bench_z;
     
     sum = max_x = max_diff = 0;

     for(i=0; i < b->N; i++)
     {
	  x = z1[i];
	  x_hat = z2[i];
	  
	  d = fabs(x - x_hat);
	  
	  // Largest difference element
	  if(d > max_diff)
	       max_diff = d;
	  
	  sum += d;
     }
     
     b->average_error = sum/b->N;
     b->max_error = max_diff;
}

void CheckSingleComplex(BenchData *b)
{
     int i;
     double d;
     double sum, max_x, max_diff;
     double complex x_hat, x;
     float complex *z1, *z2;

     z1 = b->baseline_z;
     z2 = b->bench_z;
     
     sum = max_x = max_diff = 0;

     for(i=0; i < b->N; i++)
     {
	  x = z1[i];
	  x_hat = z2[i];
	  
	  d = cabs(x - x_hat);
	  
	  // Largest difference element
	  if(d > max_diff)
	       max_diff = d;
	  
	  sum += d;
     }
     
     b->average_error = sum/b->N;
     b->max_error = max_diff;
}

void CheckDoubleComplex(BenchData *b)
{
     int i;
     double d;
     double sum, max_x, max_diff;
     double complex x_hat, x;
     double complex *z1, *z2;

     z1 = b->baseline_z;
     z2 = b->bench_z;
     
     sum = max_x = max_diff = 0;

     for(i=0; i < b->N; i++)
     {
	  x = z1[i];
	  x_hat = z2[i];
	  
	  d = cabs(x - x_hat);
	  
	  // Largest difference element
	  if(d > max_diff)
	       max_diff = d;
	  
	  sum += d;
     }
     
     b->average_error = sum/b->N;
     b->max_error = max_diff;
}
