#ifndef _BENCH_H_
#define _BENCH_H_

#include <stdlib.h>
#include <complex.h>

#include "cell_util.h"

//#define BENCH_HEADER "Function    BaseTicks    BaseMS    BenchTicks    BenchMS    AvgDiff    MaxDiff"
//#define BENCH_FMT    "%-12s %8lld %9.2f %13lld %10.2f %10f %10f\n"

#define BENCH_HEADER "Function      BaseMS    BaseGFLOPS    BenchMS    BenchGFLOPS      AvgErr    MaxError"
#define BENCH_FMT    "%-13s %6.2f %13.2f %10.2f %14.2f  %10.2e  %10.2e\n"

enum data_type
{
     SINGLE         = 0,
     DOUBLE         = 1,
     SINGLE_COMPLEX = 2,
     DOUBLE_COMPLEX = 3
};

#define MAX_BLOCK_SIZE (1024*1024*32)
#define MAX_N          MAX_BLOCK_SIZE/sizeof(complex double)
#define EMPTY_BASELINE_Z 0x0
#define EMPTY_BENCH_Z    0xFFFFFFFF

#define GIGA           1000000000

#define RANDOM_SEED    1234567890
#define RANDOM_RANGE   256

typedef struct _bench_data
{
     int N;
     void *x;
     void *y;
     void *baseline_z;
     void *bench_z;

     int use_huge_pages;

     ppu_timer baseline_timer;
     ppu_timer bench_timer;
     double average_error;
     double max_error;
     //double average_diff;
     //double max_diff;

} BenchData;

typedef void (*bench_function)(BenchData *b);

typedef struct _bench_entry
{
     int ops_per_element;
     int X_type;
     int Y_type;
     int Z_type;
     bench_function bench;
     char *name;
} BenchEntry;

extern BenchEntry benchmarks[];
extern int benchmark_count;

// Benchmark helper functions
void alloc_test_vectors(BenchData *b);
void prep_bench_data(BenchData *bd, BenchEntry *be);
void check_bench_results(BenchData *bd, BenchEntry *be);
void warmup_library(BenchData *b);

// Random number interface
#define InitRandomizer() ( srand48(RANDOM_SEED) )
#define RandomSingle()   ( (float)drand48()*RANDOM_RANGE )
#define RandomDouble()   ( drand48()*RANDOM_RANGE )

// Benchmark functions
void scopy(BenchData *b);
void sscale(BenchData *b);
void saxpy(BenchData *b);
void ssxpy(BenchData *b);
void sdot(BenchData *b);
void ccopy(BenchData *b);
void caxpy(BenchData *b);
void csxpy(BenchData *b);
void cscale(BenchData *b);
void cmult(BenchData *b);
void cmultc(BenchData *b);
void zmultc_mixed(BenchData *b);
void zsxpy_mixed(BenchData *b);
void dcopy(BenchData *b);
void dscale(BenchData *b);
void daxpy(BenchData *b);
void dsxpy(BenchData *b);
void ddot(BenchData *b);
void zcopy(BenchData *b);
void zaxpy(BenchData *b);
void zsxpy(BenchData *b);
void zscale(BenchData *b);
void zmult(BenchData *b);
void zmultc(BenchData *b);

#endif // _BENCH_H_
