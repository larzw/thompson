#!/bin/sh

#BENCH_SIZES="1024 2048 4096 1048576 2097152"

#for S in $BENCH_SIZES; do
#    ./blasx_bench -h all $S
#done

BENCH_NAME="test"

NUM_RUNS="0 1 2 3 4"

for R in $NUM_RUNS; do
    ./blasx_bench -h all 2097152 > results/${BENCH_NAME}_${R}.txt
done
