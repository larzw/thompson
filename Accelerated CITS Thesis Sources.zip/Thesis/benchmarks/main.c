#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <string.h>

#include "blasx.h"
#include "cell_util.h"

#include "bench.h"

void usage_exit()
{
     int i;

     fprintf(stderr, "usage: %s [-h] function size\n", PROGNAME);
     fprintf(stderr, " -h:  Use huge TLB pages for memory allocation\n");
     fprintf(stderr, " -i:  Average times over <i> iterations\n");
     fprintf(stderr, " Available Tests: all\n");
     
     for(i=0; i < benchmark_count; i++)
	  fprintf(stderr, "                  %s\n", benchmarks[i].name);

     exit(EXIT_FAILURE);
}

int isString(const char *a, const char *b)
{
     return (strcasecmp(a, b) == 0);
}

void run_benchmark(BenchData *bd, BenchEntry *be, int iters)
{
     long long base_ticks, bench_ticks;
     double  base_sec, bench_sec, base_ms, bench_ms;
     double base_gflops, bench_gflops;
     int i;
     
     base_ticks = bench_ticks = 0;

     for(i=0; i < iters; i++)
     {
	  prep_bench_data(bd, be);
	  be->bench(bd);
	  check_bench_results(bd, be);
	  base_ticks  += bd->baseline_timer.elapsed_ticks;
	  bench_ticks += bd->bench_timer.elapsed_ticks;
     }
     
     //tconv = bd->baseline_timer.time_base / 1000;
     
     base_ticks /= iters;
     bench_ticks /= iters;
     
     base_sec  = (double)base_ticks/bd->baseline_timer.time_base;
     bench_sec = (double)bench_ticks/bd->baseline_timer.time_base; 
     base_ms   = base_sec*1000;
     bench_ms  = bench_sec*1000;

     base_gflops = ((double)bd->N/base_sec/GIGA)*be->ops_per_element;
     bench_gflops = ((double)bd->N/bench_sec/GIGA)*be->ops_per_element;

     fprintf(stdout, BENCH_FMT,
             be->name,
             base_ms,
             base_gflops,
             bench_ms,
             bench_gflops,
             bd->average_error,
             bd->max_error);
}

int main(int argc, char **argv)
{
     int c;
     int i;
     char *test;
     unsigned int test_size;
     int iters = 1;
     BenchData bench_data;

     // Clear the bench data structure
     memset(&bench_data, 0, sizeof(bench_data));

     while((c = getopt(argc, argv, ":hi:")) != -1)
     {
	  switch(c)
	  {
	  case 'h':
	       printf("Using huge pages\n");
	       bench_data.use_huge_pages = 1;
	       break;
	       
	  case 'i':
	       iters = atoi(optarg);
	       printf("Iterations: %d\n", iters);
	       break;
	       
	  case '?':
	  default:
	       usage_exit();
	  }
     }
     
     if(argc - optind < 2)
	  usage_exit();

     // Prep the benchmark 
     test = argv[optind];
     test_size = atoi(argv[optind+1]);
     
     if(test_size > MAX_N)
     {
	  printf("Maximum benchmark size is %ld elements\n", MAX_N);
	  return -1;
     }

     fprintf(stdout, "Running blasx benchmarks N: %d\n", test_size);
     fprintf(stdout, "%s\n", BENCH_HEADER);

     InitRandomizer();

     bench_data.N = test_size;
     alloc_test_vectors(&bench_data);

     init_blasx_library();
     warmup_library(&bench_data);

     if(isString(test, "all"))
     {
	  for(i=0; i < benchmark_count; i++)
	       run_benchmark(&bench_data, &benchmarks[i], iters);
     }
     else
     {
	  for(i=0; i < benchmark_count; i++)
	       if(isString(benchmarks[i].name, test))
	       {
		    run_benchmark(&bench_data, &benchmarks[i], iters);
		    break;
	       }
     }

     return 0;
}
