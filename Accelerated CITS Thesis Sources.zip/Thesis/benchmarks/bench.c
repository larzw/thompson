#include <stdio.h>
#include <string.h>

#include "blasx.h"
#include "bench.h"

BenchEntry benchmarks[] = 
{
     {1, SINGLE, SINGLE, SINGLE, scopy,  "scopy"},
     {1, SINGLE, SINGLE, SINGLE, sscale, "sscale"},
     {2, SINGLE, SINGLE, SINGLE, saxpy,  "saxpy"},
     {2, SINGLE, SINGLE, SINGLE, ssxpy,  "ssxpy"},
     {2, SINGLE, SINGLE, SINGLE, sdot,   "sdot"},
     {1, SINGLE_COMPLEX, SINGLE_COMPLEX, SINGLE_COMPLEX, ccopy,  "ccopy"},
     {6, SINGLE_COMPLEX, SINGLE_COMPLEX, SINGLE_COMPLEX, cscale, "cscale"},
     {8, SINGLE_COMPLEX, SINGLE_COMPLEX, SINGLE_COMPLEX, caxpy,  "caxpy"},
     {8, SINGLE_COMPLEX, SINGLE_COMPLEX, SINGLE_COMPLEX, csxpy,  "csxpy"},
     {6, SINGLE_COMPLEX, SINGLE_COMPLEX, SINGLE_COMPLEX, cmult,  "cmult"},
     {6, SINGLE_COMPLEX, SINGLE_COMPLEX, SINGLE_COMPLEX, cmultc, "cmultc"},
     {6, DOUBLE_COMPLEX, SINGLE_COMPLEX, DOUBLE_COMPLEX, 
      zmultc_mixed,   "zmultc_mixed"},
     {8, DOUBLE_COMPLEX, DOUBLE_COMPLEX, SINGLE_COMPLEX, 
      zsxpy_mixed, "zsxpy_mixed"},
     
     {1, DOUBLE, DOUBLE, DOUBLE, dcopy,  "dcopy"},
     {1, DOUBLE, DOUBLE, DOUBLE, dscale, "dscale"},
     {2, DOUBLE, DOUBLE, DOUBLE, daxpy,  "daxpy"},
     {2, DOUBLE, DOUBLE, DOUBLE, dsxpy,  "dsxpy"},
     {2, DOUBLE, DOUBLE, DOUBLE, ddot,   "ddot"},
     {1, DOUBLE_COMPLEX, DOUBLE_COMPLEX, DOUBLE_COMPLEX, zcopy,  "zcopy"},
     {6, DOUBLE_COMPLEX, DOUBLE_COMPLEX, DOUBLE_COMPLEX, zscale, "zscale"},
     {8, DOUBLE_COMPLEX, DOUBLE_COMPLEX, DOUBLE_COMPLEX, zaxpy,  "zaxpy"},
     {8, DOUBLE_COMPLEX, DOUBLE_COMPLEX, DOUBLE_COMPLEX, zsxpy,  "zsxpy"},
     {6, DOUBLE_COMPLEX, DOUBLE_COMPLEX, DOUBLE_COMPLEX, zmult,  "zmult"},
     {6, DOUBLE_COMPLEX, DOUBLE_COMPLEX, DOUBLE_COMPLEX, zmultc, "zmultc"}
};

int benchmark_count = sizeof(benchmarks)/sizeof(BenchEntry);

void scopy(BenchData *b)
{
     start_timer(&b->baseline_timer);
     blasx_scopy(b->N, b->x, b->baseline_z);
     stop_timer(&b->baseline_timer);

     start_timer(&b->bench_timer);
     blasx_cell_scopy(b->N, b->x, b->bench_z);
     stop_timer(&b->bench_timer);
}

void sscale(BenchData *b)
{
     float alpha = RandomSingle();

     start_timer(&b->baseline_timer);
     blasx_sscale(b->N, alpha, b->x, b->baseline_z);
     stop_timer(&b->baseline_timer);

     start_timer(&b->bench_timer);
     blasx_cell_sscale(b->N, alpha, b->x, b->bench_z);
     stop_timer(&b->bench_timer);
}

void saxpy(BenchData *b)
{
     float alpha = RandomSingle();

     start_timer(&b->baseline_timer);
     blasx_saxpy(b->N, alpha, b->x, b->y, b->baseline_z);
     stop_timer(&b->baseline_timer);
     
     start_timer(&b->bench_timer);
     blasx_cell_saxpy(b->N, alpha, b->x, b->y, b->bench_z);
     stop_timer(&b->bench_timer);
}

void ssxpy(BenchData *b)
{
     float alpha = RandomSingle();

     start_timer(&b->baseline_timer);
     blasx_ssxpy(b->N, alpha, b->x, b->y, b->baseline_z);
     stop_timer(&b->baseline_timer);

     start_timer(&b->bench_timer);
     blasx_cell_ssxpy(b->N, alpha, b->x, b->y, b->bench_z);
     stop_timer(&b->bench_timer);
}

void sdot(BenchData *b)
{
     float baseline_dot, bench_dot;
     
     start_timer(&b->baseline_timer);
     baseline_dot = blasx_sdot(b->N, b->x, b->y);
     stop_timer(&b->baseline_timer);

     start_timer(&b->bench_timer);
     bench_dot = blasx_cell_sdot(b->N, b->x, b->y);
     stop_timer(&b->bench_timer);

     // Cheat a little to make our output conform to the same 
     // format as the others.
     memset(b->baseline_z, 1, sizeof(float)*b->N);
     memset(b->bench_z, 1, sizeof(float)*b->N);

     *((float*)b->baseline_z) = baseline_dot;
     *((float*)b->bench_z) = bench_dot;
}

void ccopy(BenchData *b)
{
     start_timer(&b->baseline_timer);
     blasx_ccopy(b->N, b->x, b->baseline_z);
     stop_timer(&b->baseline_timer);

     start_timer(&b->bench_timer);
     blasx_cell_ccopy(b->N, b->x, b->bench_z);
     stop_timer(&b->bench_timer);     
}

void caxpy(BenchData *b)
{     
     float complex alpha = RandomSingle() + RandomSingle()*I;

     start_timer(&b->baseline_timer);
     blasx_caxpy(b->N, alpha, b->x, b->y, b->baseline_z);
     stop_timer(&b->baseline_timer);

     start_timer(&b->bench_timer);
     blasx_cell_caxpy(b->N, alpha, b->x, b->y, b->bench_z);
     stop_timer(&b->bench_timer);
}

void csxpy(BenchData *b)
{
     float complex alpha = RandomSingle() + RandomSingle()*I;

     start_timer(&b->baseline_timer);
     blasx_csxpy(b->N, alpha, b->x, b->y, b->baseline_z);
     stop_timer(&b->baseline_timer);

     start_timer(&b->bench_timer);
     blasx_cell_csxpy(b->N, alpha, b->x, b->y, b->bench_z);
     stop_timer(&b->bench_timer);
}

void cscale(BenchData *b)
{
     float complex alpha = RandomSingle() + RandomSingle()*I;

     start_timer(&b->baseline_timer);
     blasx_cscale(b->N, alpha, b->x, b->baseline_z);
     stop_timer(&b->baseline_timer);

     start_timer(&b->bench_timer);
     blasx_cell_cscale(b->N, alpha, b->x, b->bench_z);
     stop_timer(&b->bench_timer);
}

void cmult(BenchData *b)
{
     start_timer(&b->baseline_timer);
     blasx_cmult(b->N, b->x, b->y, b->baseline_z);
     stop_timer(&b->baseline_timer);

     start_timer(&b->bench_timer);
     blasx_cell_cmult(b->N, b->x, b->y, b->bench_z);
     stop_timer(&b->bench_timer);
}

void cmultc(BenchData *b)
{
     start_timer(&b->baseline_timer);
     blasx_cmultc(b->N, b->x, b->y, b->baseline_z);
     stop_timer(&b->baseline_timer);
     
     start_timer(&b->bench_timer);
     blasx_cell_cmultc(b->N, b->x, b->y, b->bench_z);
     stop_timer(&b->bench_timer);
}

void zmultc_mixed(BenchData *b)
{
     start_timer(&b->baseline_timer);
     blasx_zmultc_mixed(b->N, b->x, b->y, b->baseline_z);
     stop_timer(&b->baseline_timer);

     start_timer(&b->bench_timer);
     blasx_cell_zmultc_mixed(b->N, b->x, b->y, b->bench_z);
     stop_timer(&b->bench_timer);
}

void zsxpy_mixed(BenchData *b)
{
     double complex alpha = RandomDouble() + RandomDouble()*I;

     start_timer(&b->baseline_timer);
     blasx_zsxpy_mixed(b->N, alpha, b->x, b->y, b->baseline_z);
     stop_timer(&b->baseline_timer);
     
     start_timer(&b->bench_timer);
     blasx_cell_zsxpy_mixed(b->N, alpha, b->x, b->y, b->bench_z);
     stop_timer(&b->bench_timer);
}

void dcopy(BenchData *b)
{
     start_timer(&b->baseline_timer);
     blasx_dcopy(b->N, b->x, b->baseline_z);
     stop_timer(&b->baseline_timer);

     start_timer(&b->bench_timer);
     blasx_cell_dcopy(b->N, b->x, b->bench_z);
     stop_timer(&b->bench_timer);
}

void dscale(BenchData *b)
{
     double alpha = RandomDouble();
     
     start_timer(&b->baseline_timer);
     blasx_dscale(b->N, alpha, b->x, b->baseline_z);
     stop_timer(&b->baseline_timer);

     start_timer(&b->bench_timer);
     blasx_cell_dscale(b->N, alpha, b->x, b->bench_z);
     stop_timer(&b->bench_timer);
}

void daxpy(BenchData *b)
{
     double alpha = RandomDouble();

     start_timer(&b->baseline_timer);
     blasx_daxpy(b->N, alpha, b->x, b->y, b->baseline_z);
     stop_timer(&b->baseline_timer);

     start_timer(&b->bench_timer);
     blasx_cell_daxpy(b->N, alpha, b->x, b->y, b->bench_z);
     stop_timer(&b->bench_timer);
}

void dsxpy(BenchData *b)
{
     double alpha = RandomDouble();

     start_timer(&b->baseline_timer);
     blasx_dsxpy(b->N, alpha, b->x, b->y, b->baseline_z);
     stop_timer(&b->baseline_timer);

     start_timer(&b->bench_timer);
     blasx_cell_dsxpy(b->N, alpha, b->x, b->y, b->bench_z);
     stop_timer(&b->bench_timer);
}

void ddot(BenchData *b)
{
     double baseline_dot, bench_dot;

     start_timer(&b->baseline_timer);
     baseline_dot = blasx_ddot(b->N, b->x, b->y);
     stop_timer(&b->baseline_timer);

     start_timer(&b->bench_timer);
     bench_dot = blasx_cell_ddot(b->N, b->x, b->y);
     stop_timer(&b->bench_timer);

     // Cheat a little to make our output conform to the same
     // format as the others.
     memset(b->baseline_z, 1, sizeof(double)*b->N);
     memset(b->bench_z, 1, sizeof(double)*b->N);

     *((double*)b->baseline_z) = baseline_dot;
     *((double*)b->bench_z) = bench_dot;
}

void zcopy(BenchData *b)
{
     start_timer(&b->baseline_timer);
     blasx_zcopy(b->N, b->x, b->baseline_z);
     stop_timer(&b->baseline_timer);

     start_timer(&b->bench_timer);
     blasx_cell_zcopy(b->N, b->x, b->bench_z);
     stop_timer(&b->bench_timer);
}

void zaxpy(BenchData *b)
{
     double complex alpha = RandomDouble() + RandomDouble()*I;

     start_timer(&b->baseline_timer);
     blasx_zaxpy(b->N, alpha, b->x, b->y, b->baseline_z);
     stop_timer(&b->baseline_timer);

     start_timer(&b->bench_timer);
     blasx_cell_zaxpy(b->N, alpha, b->x, b->y, b->bench_z);
     stop_timer(&b->bench_timer);
}

void zsxpy(BenchData *b)
{
     double complex alpha = RandomDouble() + RandomDouble()*I;

     start_timer(&b->baseline_timer);
     blasx_zsxpy(b->N, alpha, b->x, b->y, b->baseline_z);
     stop_timer(&b->baseline_timer);

     start_timer(&b->bench_timer);
     blasx_cell_zsxpy(b->N, alpha, b->x, b->y, b->bench_z);
     stop_timer(&b->bench_timer);
}

void zscale(BenchData *b)
{
     double complex alpha = RandomDouble() + RandomDouble()*I;

     start_timer(&b->baseline_timer);
     blasx_zscale(b->N, alpha, b->x, b->baseline_z);
     stop_timer(&b->baseline_timer);

     start_timer(&b->bench_timer);
     blasx_cell_zscale(b->N, alpha, b->x, b->bench_z);
     stop_timer(&b->bench_timer);
}

void zmult(BenchData *b)
{
     start_timer(&b->baseline_timer);
     blasx_zmult(b->N, b->x, b->y, b->baseline_z);
     stop_timer(&b->baseline_timer);

     start_timer(&b->bench_timer);
     blasx_cell_zmult(b->N, b->x, b->y, b->bench_z);
     stop_timer(&b->bench_timer);
}

void zmultc(BenchData *b)
{
     start_timer(&b->baseline_timer);
     blasx_zmultc(b->N, b->x, b->y, b->baseline_z);
     stop_timer(&b->baseline_timer);

     start_timer(&b->bench_timer);
     blasx_cell_zmultc(b->N, b->x, b->y, b->bench_z);
     stop_timer(&b->bench_timer);
}
