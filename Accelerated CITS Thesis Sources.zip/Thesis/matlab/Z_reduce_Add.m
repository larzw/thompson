function vm = Z_reduce_Add(v, f, ZPattern, n, w)

x = 1;
for i=0:(w-1)
    for j=1:n
        if ZPattern(j) == 1
            vm(x,1) = v(i*n+j)+f(x);
            x = x+1;
        end
    end
end