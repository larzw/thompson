addpath(pwd)
addpath([ pwd '\generators'])
addpath([ pwd '\solvers'])
addpath([ pwd '\Hcolumns'])
