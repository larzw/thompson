function Mv = mult_M( eta, v, n, w, mu, P)
%mult_M Returns Mv

%v1 = P' * v;
v1 = mult_PTranspose( eta, v, n, w )/n;

v1 = P*v1;
%v1 = mult_P( eta, v1, n, w )/n;

Mv = (((mu^-1)*eye(n*w))*v) - v1;

%v1 = v;
%v1 = mult_PTranspose( eta, v, n, w );


%v1 = mult_P( eta, v1, n, w );
%Mv = ((mu^-1)*eye(n*w)*(v)) - v1;