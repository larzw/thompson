function yLim = compute_yLim_long(x, n, w, mu, sH, M, P, Z, Zprime )

yLim = Z*(eye(n*w)+mu*P*P'*Zprime*(eye(n*w)+ P*(((mu^-1)*eye(n)-P'*Zprime*P)^-1)*P'*Zprime) )*M*sH'*x;