function lse = estimate_LeastSquares(f, x, d, ZPattern, w, n )

M = mult_H(f, d, ZPattern, w, n); 
lse = dot(M,x)/dot(M,M);