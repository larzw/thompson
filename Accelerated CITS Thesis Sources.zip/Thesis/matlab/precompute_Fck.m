function Fck = precompute_Fck(CkV, w)

Fck = [];
for i = 1:w
    dk = fft(CkV(:,i));
%   dk(1)=0;
    Fck = [Fck dk];
end