function Zexp = Z_expand( ZPattern, v, n, w)

Zexp(n*w,1) = 0;

x = 1;
for i = 0:(w-1)
    for j = 1:n
        if ZPattern(j) == 1
            Zexp(j+(i*n)) = v(x);
            x = x+1;
        end
    end
end