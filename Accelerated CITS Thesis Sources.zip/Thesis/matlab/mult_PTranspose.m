function PTv = mult_PTranspose( eta, v, n, w)
%mult_P Returns transpose(P)v

% PTv = P'*v;
% return;

% Partion and multiply v
sumK = zeros(n,1);
for k = 0:(w-1)
    rs = ((k*n)+1);
    re = ((k*n)+n);
    part = v(rs:re);
    sumK = sumK + (conj(eta(:,k+1)).*(fft(part)));
end

PTv = ifft(sumK);
PTv = real(PTv);