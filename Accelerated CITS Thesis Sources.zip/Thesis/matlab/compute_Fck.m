function Fck = compute_Fck(sH, n, w)
%COMPUTE_D 

Fck = [];
for i = 0:(w-1)
    rs = ((i*n)+1);
    ck = sH(:,rs);
    dk = fft(ck);
    Fck = [Fck dk];
end