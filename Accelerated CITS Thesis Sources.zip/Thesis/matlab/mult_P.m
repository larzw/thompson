function Pv = mult_P( eta, v, w)
%mult_P Returns Pv

%Pv = P*v;
%return;

%% Pv Multiplication
Pv = [];
Fv = fft(v);
for k = 1:w
    tmp = ifft(eta(:,k).*Fv);
    Pv = [Pv ; tmp];
end

Pv = real(Pv);