function  [fv,res]  = vh_kernel_funcs(fv, res, x, n, w, mu, eta, ZPattern, Fck, CG_ITRS, CG_EPSILON )

% Compute f estimate
xi = compute_yLim_opt(res, n, w, mu, eta, ZPattern, ~ZPattern, Fck, CG_ITRS, CG_EPSILON);
fv = Z_reduce_Add(xi, fv, ZPattern, n, w);
lse = estimate_LeastSquares(fv, x, Fck, ZPattern, w, n );
res = x-mult_H(fv*lse, Fck, ZPattern, w, n);