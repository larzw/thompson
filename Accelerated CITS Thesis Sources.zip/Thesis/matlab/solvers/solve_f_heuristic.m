function fv = solve_f_heuristic(x, n, m, w, mu, eta, ZPattern, ZPrimePattern, d, LS_THRESHOLD, LS_ITRS, CG_ITRS, CG_EPSILON )

ls = LS_THRESHOLD;
itrs = 1;
fi(m,1) = 0;
xi = x;

while ls >= LS_THRESHOLD && itrs < LS_ITRS
    
    % Compute f estimate
    xi = compute_yLim_opt(xi, n, w, mu, eta, ZPattern, ZPrimePattern, d, CG_ITRS, CG_EPSILON);
    
    %fi = Z_collapse(yv, ZPattern, n, m, w);
    %f = f+fi;
    fi = Z_reduce_Add(xi, fi, ZPattern, n, m, w);
    
    lse = estimate_LeastSquares(fi, x, d, ZPattern, w, n );
    %lse = 1;
    
    xi = x-mult_H(fi*lse, d, ZPattern, w, n);

    ls = dot(xi,xi);
    disp(['LS: ' mat2str(ls,6)]);
    itrs = itrs + 1;
    pause;
end

disp(['Heuristic Iterations: ' mat2str(itrs-1,3) ', Least Squares: ' mat2str(ls,6)]);
fv = fi;