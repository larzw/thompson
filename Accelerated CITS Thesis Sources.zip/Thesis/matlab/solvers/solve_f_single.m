function fv = solve_f_single(f, x, n, m, w, mu, muInv, eta, ZPattern, ZPrimePattern, Fck, LS_THRESHOLD, LS_ITERS, CG_ITERS, CG_EPSILON )

ls = LS_THRESHOLD;
itrs = 1;
fv(m,1) = single(0);
v = x;

while ls >= LS_THRESHOLD && itrs < LS_ITERS
    
%% Compute f estimate
%     v = compute_yLim_opt(v, n, w, mu, eta, ZPattern, ZPrimePattern, d, CG_ITRS, CG_EPSILON);
% BEGIN v

    %% Expanding sH' Mult
    %   v = mult_sHTranspose( Fck, v, w);
    v = single(v);
    v = fft(v);
    v = double(v);
    % Eliminate the DC component
     v(1) = 0;
    v1 = [];
    v3 = [];
    v3 = zeros(n,1);
    for i = 1:w
        v2 = conj(Fck(:,i)) .* v;
        v3 = v3 + (conj(eta(:,i)).*v2);
        v2 = v2 * muInv;
        v1 = [v1; v2 ];
    end
    
    % P Mult
    v = [];
    for i = 1:w
        v2 = eta(:,i).*v3;
        istart = ((i-1)*n)+1;
        iend   = ((i-1)*n)+n;
        v2 = v1(istart:iend)-v2;
        v2 = single(v2);
        v2 = ifft(v2);
        v2 = real(v2);
        v = [v ; v2];
    end
    
% INPLAY: x, v

% BEGIN v1

    %   v2 = mult_Z( v2, ZPrimePattern, n, w );
    v3 = zeros(n,1);
    for k=0:(w-1)
        rs = ((k*n)+1);
        re = ((k*n)+n);
        v2 = v(rs:re).*ZPrimePattern;
        v2 = fft(v2);
        v2 = (conj(single(eta(:,k+1))).*v2);
        v3 = v3 + v2;
    end

    v1 = real(ifft(v3));
    
%%  Conjugate Gradient
%   v1 = embedded_cg( v1, n, mu, w, eta, ZPrimePattern, CG_EPSILON, CG_ITRS );
% INPLAY: x, v, v1
% BEGIN cg_x, cg_r, cg_p, cg_v

    % Start our initial cg guess at zero
    cg_x = zeros(n,1);
   
    %cg_r = b-A*x;
    cg_r = v1;

    cg_p = cg_r;
    e = dot(cg_r,cg_r);

    pass = 1;

    while(e > CG_EPSILON && pass <= CG_ITERS)
       disp(['CG itr: ' num2str(pass) ' e: ' num2str(e,6) ]);
       lastE = e;
       %cg_v = mult_A( eta, cg_p, n, w, mu, ZPrimePattern);

        v2 = fft(cg_p);
        cg_v = [];
        cg_v = zeros(n,1);
        for k = 1:w
            v3 = eta(:,k).*v2;
            v3 = ifft(v3);
            v3 = v3 .* ZPrimePattern;
            v3 = fft(v3);
            cg_v = cg_v + (conj(single(eta(:,k))).*v3);
        end

        cg_v = ifft(cg_v);
        cg_v = real(cg_v);

        cg_v = (cg_p*muInv)-cg_v;

       a = e/dot(cg_p,cg_v);
       cg_r = cg_r - a*cg_v;
       dotR = dot(cg_r,cg_r);
       
       % Halt at the first local minimum of error
      if lastE < dotR
        break;
      end
       
       cg_x = cg_x + a*cg_p;
        
       a = dotR;
       cg_p = cg_r + (a/e)*cg_p;
       e = a;
       pass = pass + 1;
    end
% END cg_x, cg_r, cg_p, cg_v

    disp(['CG Passes: ' mat2str(pass,3) ', e: ' mat2str(lastE,6) ' (next:' num2str(e,6) ')' ]);
    
    v1 = cg_x;
    
%%

% BEGIN v2, v3
%   v1 = mult_P(eta, v1, w);
    v2 = fft(v1);
    v1 = [];
    for k = 1:w
        v3 = single(eta(:,k)).*v2;
        v3 = ifft(v3);
        v1 = [v1 ; real(v3)];
    end
% END v2, v3    

    v1 = v + v1;

% BEGIN v2, v3
    v2 = zeros(n,1);
    for k = 0:(w-1)
        rs = ((k*n)+1);
        re = ((k*n)+n);
        v3 = v1(rs:re).*ZPrimePattern;
        v3 = fft(v3);
        v2 = v2 + (conj(single(eta(:,k+1))).*v3);
    end
    
    % P Mult
    v1 = [];
    for k = 1:w
        v3 = single(eta(:,k)).*v2;
        v3 = ifft(v3);
        v1 = [v1 ; real(v3)];
    end
% END v2, v3
% END P*P'
    
    v1 = mu*v1;
    v = v1+v;
% END v1

% INPLAY: x, v
  
%%      Z Reduce xi and add fv
%fv = Z_reduce_Add(xi, fv, ZPattern, n, m, w);

    k = 1;
    for i=0:(w-1)
        for j=1:n
            if ZPattern(j) == 1
                fv(k,1) = v(i*n+j)+fv(k);
                k = k+1;
            end
        end
    end

%%      Estimate Least Squares
%   lse = estimate_LeastSquares(fv, x, d, ZPattern, w, n );

% BEGIN v1, v2, v3

    %   part = Z_expand( ZPattern, fv, n, w);
%     v2 = [];
    v2 = single([]);
    
    v2(n*w,1) = 0;
    k = 1;
    for i = 0:(w-1)
        for j = 1:n
            if ZPattern(j) == 1
                v2(j+(i*n)) = fv(k);
                k = k+1;
            end
        end
    end
    
    v1 = single(zeros(n,1));
%     v1 = zeros(n,1);
    for i = 0:(w-1)
        rs = ((i*n)+1);
        re = ((i*n)+n);
        v3 = fft(v2(rs:re));
         v3(1)=0;
        v3 = Fck(:,(i+1)).*v3;
        v3 = ifft(v3);
        v1 = v1 + real(v3);
    end
    
    lse = single(dot(v1,x)/dot(v1,v1));

%     lse = single(1);
% END v1, v2, v3

%% Recalculate v
    %   v = x-mult_H(fv*lse, d, ZPattern, w, n);
    v = zeros(n,1);
    
    %   part = Z_expand( ZPattern, fv, n, w);
% BEGIN v1, v2
    v1 = single([]);
    v1(n*w,1) = 0;
    k = 1;
    for i = 0:(w-1)
        for j = 1:n
            if ZPattern(j) == 1
                v1(j+(i*n)) = fv(k)*lse;
                k = k+1;
            end
        end
    end
    
    for i = 0:(w-1)
        rs = ((i*n)+1);
        re = ((i*n)+n);
        v2 = ifft(Fck(:,(i+1)).*fft(v1(rs:re)));
        v = v + real(v2);
    end
    
    v = x-v;
% END v1, v2

%% Determine the error
    ls = dot(v,v);
    disp(['LS: ' mat2str(ls,6) ', LSIters: ' mat2str(itrs,3)]);
    pixAbs = abs(double(f)-double(fv));
    disp(['Deviation Mean: ' mat2str(mean(pixAbs)) ', min: ' mat2str(min(pixAbs)) ', max: ' mat2str(max(pixAbs))]);
    
    itrs = itrs + 1;
%     pause;
end

disp(['Heuristic Iterations: ' mat2str(itrs-1,3) ', Least Squares: ' mat2str(ls,6)]);
% fv = fv;