function fv = solve_f(solver, f, x, n, m, w, mu, eta, ZPattern, Fck, MAX_PIX_ERR, MAX_VH_ITERS, CG_ITERS, CG_EPSILON )

pixErr = MAX_PIX_ERR;
itrs = 1;
fv(m,1) = 0;
res = x;

while pixErr >= MAX_PIX_ERR && itrs <= MAX_VH_ITERS
    
    fv  = solver(fv, res, x, n, w, mu, eta, ZPattern, Fck, CG_ITERS, CG_EPSILON );
    res = calculate_residual(fv, x, n, w, ZPattern, Fck);
    serr = dot(res,res);
    disp(['Square Residual: ' mat2str(serr,6)]);
    disp(['Iterations: ' mat2str(itrs,3)]);
    pixAbs = abs(double(f)-double(fv));
    pixErr = max(pixAbs);
    disp(['Pixel Error mean: ' mat2str(mean(pixAbs)) ', min: ' mat2str(min(pixAbs)) ', max: ' mat2str(pixErr)]);
    
    itrs = itrs + 1;
    pause;
end

disp(['Heuristic Iterations: ' mat2str(itrs-1,3) ', Max Pixel Err: ' mat2str(pixErr,6)]);