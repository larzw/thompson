function Zv = mult_Z( v, pattern, n, w )

Zv = [];
for k=0:(w-1)
    rs = ((k*n)+1);
    re = ((k*n)+n);
    part = v(rs:re); 
    Zv = [Zv; part.*pattern];
end