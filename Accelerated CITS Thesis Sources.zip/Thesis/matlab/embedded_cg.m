function x = embedded_cg( b, n, mu, w, eta, ZPrimePattern, epsilon, iters)
%embedded_cg  Conjugate gradient method solving (mu^-1*I-PtZ'P)u

x = zeros(n,1);

%r = b-A*x;
r = b - mult_A( eta, x, n, w, mu, ZPrimePattern);

p = r;
e = dot(r,r);

pass = 1;
lastX = x;
lastE = e;

while(e > epsilon && pass <= iters)
   disp(['CG itr: ' num2str(pass) ' e: ' num2str(e,6) ]);
   lastE = e;
   lastX = x;
   %v = A*p; 
   v = mult_A( eta, p, n, w, mu, ZPrimePattern);
   a = e/dot(p,v);
   x = x + a*p;
   
   r = r - a*v;
   a = dot(r,r);
   p = r + (a/e)*p;
   e = a;

 % Halt at the first local minimum of error
   if lastE < e
     break;
   end
   
   pass = pass + 1;
end

disp(['CG Passes: ' mat2str(pass,3) ', e: ' mat2str(lastE,6) ' (next:' num2str(e,6) ')' ]);
x = lastX;