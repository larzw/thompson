%% Write Configuration File
fname = ['data\conf_' num2str(n) '.txt'];
fd = fopen(fname, 'wt');
fprintf(fd,'n               = %u\n', n);
fprintf(fd,'m               = %u\n', m);
fprintf(fd,'w               = %u\n', w);
fprintf(fd,'alpha           = %u\n', alpha);
fprintf(fd,'a               = %u\n', a);
fprintf(fd,'g               = %u\n', g);
fprintf(fd,'mu              = %f\n', mu);
fprintf(fd,'\n');
fprintf(fd,'MAX_CTIS_ITERS  = %u\n', MAX_VH_ITERS);
fprintf(fd,'CG_ITERS        = %u\n', CG_ITERS);
fprintf(fd,'CG_EPSILON      = %f\n', CG_EPSILON);
fprintf(fd,'\n');
fprintf(fd,'Hmatrix         = %s\n', ['../data/Hmatrix_' num2str(n) '.txt']);
fprintf(fd,'x               = %s\n', ['../data/x_' num2str(n) '.txt']);
fprintf(fd,'f               = %s\n', ['../data/f_' num2str(n) '.txt']);
fprintf(fd,'eta             = %s\n', ['../data/eta_' num2str(n) '.txt']);
fprintf(fd,'Fck             = %s\n', ['../data/Fck_' num2str(n) '.txt']);
fprintf(fd,'ZPattern        = %s\n', ['../data/ZPattern_' num2str(n) '.txt']);
fclose(fd);

%% Write Hmatrix
fname = ['data\Hmatrix_' num2str(n) '.txt'];
fd = fopen(fname, 'wt');
for i = 1:w
    fprintf(fd, 'col %d\n', (i-1)*alpha*a);
    for j = 1:n
        fprintf(fd, '%d %7f\n', (j-1), CkV(j,i));
    end
end
fclose(fd);

%% Write f
fname = ['data\f_' num2str(n) '.txt'];
fd = fopen(fname, 'wt');
for i = 1:m
        fprintf(fd, '%7f\n', f(i));
end
fclose(fd);

%% Write x
fname = ['data\x_' num2str(n) '.txt'];
fd = fopen(fname, 'wt');
for i = 1:n
        fprintf(fd, '%+.16e\n', x(i));
end
fclose(fd);

%% Write ZPattern
fname = ['data\ZPattern_' num2str(n) '.txt'];
fd = fopen(fname, 'wt');
for i = 1:n
        fprintf(fd, '%i\n', ZPattern(i));
end
fclose(fd);

%% Write eta
fname = ['data\eta_' num2str(n) '.txt'];
fd = fopen(fname, 'wt');
for j = 1:w
    for i = 1:((n/2)+1)
        fprintf(fd, '%+.16e %+.16e\n', real(eta(i,j)),imag(eta(i,j)));
    end
end
fclose(fd);

%% Write Fck
fname = ['data\Fck_' num2str(n) '.txt'];
fd = fopen(fname, 'wt');
for j = 1:w
    for i = 1:((n/2)+1)
        fprintf(fd, '%+.16e %+.16e\n', real(Fck(i,j)),imag(Fck(i,j)));
    end
end
fclose(fd);