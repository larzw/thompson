
%% Piecewise check
%k = 2;
%Hk = gen_Hk(n, a, k, alpha, g)
%Ck = gen_Ck(Hk(:,1)) 
%f = rand(a*alpha,1);
%r1 = Hk*f
%r2 = Ck*E*f

%% Whole matrix check
%f = round(rand(m,1).*100)
% r1 = H*f
% r2 = sH*kron(eye(w),E)*f

%% P & M check
% P = gen_P(sH, w, mu)
% r1 = M*sH'*sH
% r2 = mu*P*P'

%% P mult check
% tv = x.*10000000;
% r1 = P*tv;
% r2 = mult_P( eta, tv, n, w, P, mu, sH );
% r1b = P\r1;
% r2b = P\r2;
% 
% diff1 = sum(abs(r1b-tv));
% diff2 = sum(abs(r2b-tv));
% disp(['Direct Err: ' mat2str(diff1,5) ', Eta Method Err: ' mat2str(diff2,5)]);

%% P transpose mult check
% v = sH'*x;
% r1 = P'*v;
% r2 = mult_PTranspose( eta, v, n, w, P );

% tv = sH'*x;
% Pt = P';
% r1 = Pt*tv;
% r2 = mult_PTranspose( eta, tv, n, w, P );

%% Zprime multiplication check
% v = round(rand(n*w,1).*100);
% Zprime = gen_Zprime( E, n, m, w) 
% r1 = Zprime*v
% r2 = mult_Zprime( v, Zpattern, n, w )

%% A multiplication check
% r1 = A*x;
% r2 = mult_A( eta, x, n, w, mu, ZPrimePattern, P, Zprime );

%% sH' multiplication check
% tv = x;
% r1 = sH'*tv;
% r2 = mult_sHTranspose(d, tv, w);
% r1b = sH'\r1;
% r2b = sH'\r2;
% 

%% H multiplication check
% tv = f;
% r1 = H*tv;
% r2 = mult_H(tv, d, ZPattern, w, n);
% r1b = H\r1;
% r2b = H\r2;
% 
% diff1 = sum(abs(r1b-tv));
% diff2 = sum(abs(r2b-tv));
% disp(['Direct Err: ' mat2str(diff1,5) ', Eta Method Err: ' mat2str(diff2,5)]);

%% Conjugate Gradient
% v = x;
% Inw = eye(n*w);
% v = sH'*v;
% v = M*v;
% v1 = v;
% v2 = v;
% v3 = v;
% v3 = Zprime*v3;
% v3 = P'*v3;
% 
% CG_ITRS     = n;
% CG_EPSILON  = 0.001;
% 
% r1 = A\v3;
% r2 = embedded_cg( v3, n, mu, w, eta, ZPrimePattern, CG_EPSILON, CG_ITRS, A );
% 
% %% Evaluate Results
% diff = sum(abs(r1-r2));
% err = diff/sum(abs(r1));
% if err < ERR_THRESHOLD  
%     disp(['Valid -- Relative Error: ' mat2str(err*100,5) '%, Absolute Error: ' mat2str(diff,6)]);
% else
%     disp(['INVALID -- Relative Error: ' mat2str(err*100,5) '%, Absolute Error: ' mat2str(diff,6)]);
% end
% pixAbs = mean(abs(r1-r2));
% disp(['Average Absolute Deviation: ' mat2str(pixAbs,5)]);


%% Solving for f
r1 = f;
tic
r2 = solve_f_heuristic(x, n, m, w, mu, eta, ZPattern, ZPrimePattern, Fck, LS_THRESHOLD, LS_ITERS, CG_ITERS, CG_EPSILON );
%r2 = solve_f_unrolled(x, n, m, w, mu, muInv, eta, ZPattern, ZPrimePattern, Fck, LS_THRESHOLD, LS_ITERS, CG_ITERS, CG_EPSILON );
toc

% When evaluating the results of our heuristic, we're not so concerned with
% the overall correctness as we are about average per/pixel error.
pixAbs = mean(abs(r1-r2));
disp(['Average Absolute Deviation: ' mat2str(pixAbs,5)]);
