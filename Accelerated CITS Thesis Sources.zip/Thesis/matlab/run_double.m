tic
fv = solve_f(@vh_kernel_double, f, x, n, m, w, mu, eta, ZPattern, Fck, MAX_PIX_ERR, MAX_VH_ITERS, CG_ITERS, CG_EPSILON );
toc