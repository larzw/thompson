function yLim = compute_yLim_opt(v, n, w, mu, eta, ZPattern, ZPrimePattern, d, CG_ITRS, CG_EPSILON)

%yLim = Z*(eye(n*w)+mu*P*P'*Zprime*(eye(n*w)+ P*(((mu^-1)*eye(n)-P'*Zprime*P)^-1)*P'*Zprime) )*M*sH'*x;

%v = x;
%Inw = eye(n*w);

%% v = sH'*v;
v = mult_sHTranspose( d, v, w);

%% Expanding sH' Mult
% sHTv = [];
% Fv = ifft(v);
% for i = 1:w
%     t = fft(d(:,i).*Fv);
%     sHTv = [sHTv; t];
% end
% 
% sHTv = real(sHTv);
% 
% v = sHTv;

%% v = M*v;    
%v1 = P' * v;
v1 = v;
%v1 = mult_PTranspose(eta, v1, n, w);

%v1 = P * v1;
%v1 = mult_P( eta, v1, w);

%% COMBINE P*P'
% P' Mult
sumK = zeros(n,1);
for k = 0:(w-1)
    rs = ((k*n)+1);
    re = ((k*n)+n);
    part = v(rs:re);
    sumK = sumK + (conj(eta(:,k+1)).*(fft(part)));
end

% P Mult
Pv = [];
Fv = sumK;
for k = 1:w
    tmp = ifft(eta(:,k).*Fv);
    Pv = [Pv ; tmp];
end

v1 = real(Pv);

%%

% v = (((mu^-1)*Inw)*v) - v1;
%v = Inw*v;

v = v * (mu^-1);
v = v - v1;


%%

v1 = v;
v2 = v;
v3 = v;

%v3 = Zprime*v3;
v3 = mult_Z( v3, ZPrimePattern, n, w );

%v3 = P'*v3;
v3 = mult_PTranspose(eta, v3, n, w);

%% Conjugate Gradient
%v3 = (((mu^-1)*eye(n)-P'*Zprime*P)^-1)*v3;
v3 = embedded_cg( v3, n, mu, w, eta, ZPrimePattern, CG_EPSILON, CG_ITRS );

%%
%v3 = P*v3;
v3 = mult_P(eta, v3, w);

%v2 = Inw*v2;

v2 = v2 + v3;

%%
%v2 = Zprime*v2;
v2 = mult_Z( v2, ZPrimePattern, n, w );

%v2 = P'*v2;
%v2 = mult_PTranspose( eta, v2, n, w );

%v2 = P*v2;
%v2 = mult_P( eta, v2, w);

%% Combine P*P'
sumK = zeros(n,1);
for k = 0:(w-1)
    rs = ((k*n)+1);
    re = ((k*n)+n);
    part = v2(rs:re);
    sumK = sumK + (conj(eta(:,k+1)).*(fft(part)));
end

% P Mult
Pv = [];
Fv = sumK;
for k = 1:w
    tmp = ifft(eta(:,k).*Fv);
    Pv = [Pv ; tmp];
end

v2 = real(Pv);
%% END P*P'

v2 = mu*v2;

% v1
%v1 = Inw*v1;

v = v2+v1;
v = mult_Z( v, ZPattern, n, w );

yLim = v;