function Ax = mult_A( eta, x, n, w, mu, ZPrimePattern)

%Ax = ((mu^-1)*eye(n)-P'*Zprime*P)*x;
x1 = x;

x1 = mult_P( eta, x1, w);
x1 = mult_Z( x1, ZPrimePattern, n, w );
x1 = mult_PTranspose( eta, x1, n, w);

x = (mu^-1)*x;

Ax = x-x1;