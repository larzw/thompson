
%% Problem Parameters

%% Working Sets

n       = 524288;
m       = 21870;
w       = 3;
alpha   = 90;
a       = 81;
g       = 82;

% n       = 262144;
% m       = 43740;
% w       = 6;
% alpha	= 90;
% a       = 81;
% g       = 90;

% n       = 262144;
% m       = 87480;
% w       = 12;
% alpha	= 90;
% a       = 81;
% g       = 90;

% n       = 4194304;
% m       = 192;
% w       = 4;
% alpha	= 16;
% a       = 3;
% g       = 17;

% n       = 384;
% m       = 256;
% w       = 4;
% alpha   = 8;
% a       = 8;
% g       = 12;

%  n       = 1048576;
%  m       = 48000;
%  w       = 24;
%  alpha	 = 40;
%  a       = 50;
%  g       = 60;

%% SLOW CONVERGENCE
% n       = 8192;
% m       = 7200;
% w       = 10;
% alpha	  = 24;
% a       = 30;
% g       = 32;

% n       = 393216;
% m       = 43740;
% w       = 6;
% alpha	= 90;
% a       = 81;
% g       = 90;

%% Solver Parameters
MAX_PIX_ERR  = 2;
MAX_VH_ITERS = 20;

CG_ITERS     = 20;
CG_EPSILON   = 0.00001;
mu           = 0.1;

%% Test Data Parameters
% "Randomize" our test
SEED = 5;

F_RANGE = 255;
H_RANGE = 255;

rand('twister',SEED);

% Generate the input data vector
f = rand(m,1).*F_RANGE;

f = fix_precision(f, 7);

% Generate the principal vectors of the transfer matrix
CkV = gen_CkVectors(n, w, H_RANGE);

for i=1:w
   CkV(:,i) = fix_precision(CkV(:,i), 7);
end

% CkV(n,w) = 0;
% for i=1:w
%    CkV(:,i) = load_column(['Hmatrix_' num2str(i-1) '.txt'],n); 
% end

% Optionally generate the full matrix H from the principal vectors
%H  = gen_H(n,w,alpha,a,g);

% Precompute eta and fft(CkV(i)) from the principal vectors
Fck = precompute_Fck(CkV, w);
eta = precompute_eta(Fck, n, w, mu);

% Get the masking pattern
ZPattern = gen_ZPattern( n, a, g, alpha );

%% Precompute long-hand derived quantities
% E = gen_E(n, alpha, a, g);
% Z = gen_Z( E, m, w);
% Zprime = gen_Zprime( Z, n, w);
% 
% sH = gen_specialH( CkV, n, w, alpha );
% 
% P = gen_P(sH, w, mu);
% M = gen_M(sH, mu);
% A = ((mu^-1)*eye(n)-P'*Zprime*P);

% Encode the data vector with the transfer matrix
%x = H*f;
x = mult_H(f, Fck, ZPattern, w, n);
