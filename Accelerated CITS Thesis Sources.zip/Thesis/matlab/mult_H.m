function Hv = mult_H(v, d, ZPattern, w, n)

%Hv = H*v;

Hv = zeros(n,1);
part = Z_expand( ZPattern, v, n, w);

for i = 0:(w-1)
    rs = ((i*n)+1);
    re = ((i*n)+n);
    t = ifft(d(:,(i+1)).*fft(part(rs:re)));
    Hv = Hv + real(t);
end

