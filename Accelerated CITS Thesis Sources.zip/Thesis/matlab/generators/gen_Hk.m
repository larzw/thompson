function Hk = gen_Hk(n, a, alpha, g, H_RANGE)
%gen_Hk Create a subpartition of H

Tk0 = gen_Tk(n, a, H_RANGE);
Hk = Tk0;

for l=1:(alpha-1)
    Hk = [Hk gen_R(n, l, g)*Tk0];
end