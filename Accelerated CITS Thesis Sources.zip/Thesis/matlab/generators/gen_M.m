function M = gen_M( sH, mu )

s = size(sH,2);
M = inv((mu*eye(s)) + (sH' * sH));