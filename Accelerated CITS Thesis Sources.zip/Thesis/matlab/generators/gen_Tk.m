function Tk = gen_Tk(n, a, H_RANGE)
%gen_Tk Creates a rectangular circular matrix Tk

% Create a single vector (of length n) to expand
ck = gen_CkVectors( n, 1, H_RANGE );

% Create a circulant block from ck of width a 
for i=1:a
   Tk(:,i) = ck;
   ck = circshift(ck,1);
end