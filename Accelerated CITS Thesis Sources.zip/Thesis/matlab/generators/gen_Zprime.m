function Zprime = gen_Zprime( Z, n, w)
Zprime = (eye(n*w) - Z);
