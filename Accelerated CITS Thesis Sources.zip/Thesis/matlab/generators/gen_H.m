function H = gen_H(n, w, alpha, a, g, H_RANGE)
%gen_H Create the transfer matrix H

H = [];
for k=1:w
    H = [H gen_Hk(n, a, alpha, g, H_RANGE)];
end

