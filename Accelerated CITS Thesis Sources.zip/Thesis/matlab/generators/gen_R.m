function R = gen_R(n, l, g)
%gen_R returns R(i,j)=[lg=i-j%n]

for i=1:n
    for j=1:n
        if(l*g == mod(i-j, n))
        %if(g == mod(i-j, n))
            R(i,j) = 1;
        else
            R(i,j) = 0;
        end
    end
end