function ZPattern = gen_ZPattern( n, a, g, alpha )

ZPattern = [];

for i=1:alpha
    ZPattern = [ZPattern; ones(a,1); zeros(g-a,1)];
end

ZPattern = [ZPattern; zeros(n-(alpha*g),1)];