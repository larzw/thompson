function ZPrimePattern = gen_ZPrimePattern( n, a, g, alpha )

ZPrimePattern = [];

for i=1:alpha
    ZPrimePattern = [ZPrimePattern; zeros(a,1); ones(g-a,1)];
end

ZPrimePattern = [ZPrimePattern; ones(n-(alpha*g),1)];