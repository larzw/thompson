function Q = gen_Q( g,a )
%gen_Q Create the g x a matrix Q

Q = [ eye(a) ; zeros(g-a,a) ];