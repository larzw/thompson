function sH = gen_specialH( CkV, n, w, alpha )
%gen_specialH  Create a special n x nw transfer matrix sH

sH = [];
for i = 1:w
%    for j = 1:alpha
        for k = 0:n-1
            sH = [sH circshift(CkV(:,i),k)];
        end
%    end
end

% sH = [];
% m = size(H,2);
% Aalpha = m/w;
% for i=1:w
%     col = ((i-1)*Aalpha)+1;
%     sH = [sH gen_Ck(H(:,col))];
% end