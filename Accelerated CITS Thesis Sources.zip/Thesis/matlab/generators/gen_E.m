function E = gen_E(n, alpha, a, g)
% gen_E Generate the n x (a*alpha) matrix E

E = [ kron(eye(alpha),gen_Q(g,a)) ; zeros(n-(g*alpha),a*alpha) ];
