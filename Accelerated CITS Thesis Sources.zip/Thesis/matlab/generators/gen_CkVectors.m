function ckV = gen_CkVectors( n, w, H_RANGE )

ckV = zeros(n,w);
for i = 1:w
    for j = 1:n
        ckV(j,i) = H_RANGE*rand();
    end
end
