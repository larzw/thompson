function P = gen_P(sH, w, mu)
%gen_P Create the special n*w x n matrix P

s = size(sH,2)/w;
sumK = zeros(s);

for i = 0:(w-1)
    rs = ((i*s)+1);
    re = ((i*s)+s);
    Ck = sH(:,rs:re);
    sumK = sumK + (Ck*Ck');
end

P = ((mu^-1)*sH') * ((eye(s) + (mu^-1)*sumK)^-(1/2));