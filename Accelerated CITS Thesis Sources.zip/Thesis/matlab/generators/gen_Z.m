function Z = gen_Z( E, m, w)
Z = diag(kron(eye(w),E)*ones(m,1));