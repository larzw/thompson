function sHTv = mult_sHTranspose( d, v, w)

%sHTv = sH'*v;
sHTv = [];
Fv = ifft(v);
for i = 1:w
    t = fft(d(:,i).*Fv);
    sHTv = [sHTv; t];
end

sHTv = real(sHTv);