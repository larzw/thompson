function eta = compute_eta(sH, n, w, mu)
%compute_eta Precompute eta

s = size(sH,2)/w;

sumK = zeros(n,1);
for i = 0:(w-1)
    rs = ((i*s)+1);
    ck = sH(:, rs);
    fck = fft(ck);
    sumK = sumK + (fck.*conj(fck));
end

% Vector d
d = n+(n/mu)*sumK;

eta = [];

% Precompute ETA
for i = 0:(w-1)
    rs = ((i*s)+1);
    ck = sH(:, rs);
    ek = sqrt(n)/mu*conj(fft(ck)).*(d.^(-1/2));
    eta = [eta ek];
end
