function eta = precompute_eta(Fck, n, w, mu)

sumK = zeros(n,1);
for i = 1:w
    fck = Fck(:,i);
    fck = fck.*conj(fck);
    sumK = sumK + fck;
end

% Vector d
d = sumK*(n/mu);
d = n+d;
d = d.^(-1/2);

% Precompute ETA
eta = [];
for i = 1:w
    fck = Fck(:,i);
    ek = conj(fck).*d;
    eta = [eta ek];
end

eta = sqrt(n)/mu*eta;
